PARALLAX_CLOSURE_MVP(1).zip supplied by the user on 2026-07-24 and used as the baseline design input.
