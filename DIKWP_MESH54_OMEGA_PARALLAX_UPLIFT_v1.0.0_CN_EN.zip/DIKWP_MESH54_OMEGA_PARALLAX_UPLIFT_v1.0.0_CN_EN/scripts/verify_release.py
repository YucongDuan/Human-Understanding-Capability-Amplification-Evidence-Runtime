#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def verify(root: Path) -> dict:
    failures: list[dict] = []
    manifest_path = root / "MANIFEST.json"
    sums_path = root / "SHA256SUMS.txt"
    if not manifest_path.exists():
        failures.append({"code": "manifest.missing"})
        return {"status": "FAIL", "failures": failures}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    entries = manifest.get("files", [])
    expected_paths = {entry["path"] for entry in entries}
    for entry in entries:
        path = root / entry["path"]
        if not path.is_file():
            failures.append({"code": "file.missing", "path": entry["path"]})
            continue
        actual = sha256(path)
        if actual != entry["sha256"]:
            failures.append({"code": "file.hash", "path": entry["path"], "expected": entry["sha256"], "actual": actual})
        if path.stat().st_size != entry["size"]:
            failures.append({"code": "file.size", "path": entry["path"]})
    ignored = {"MANIFEST.json", "SHA256SUMS.txt"}
    actual_paths = {
        p.relative_to(root).as_posix() for p in root.rglob("*")
        if p.is_file() and not any(x in {"__pycache__", ".pytest_cache"} for x in p.parts) and p.suffix != ".pyc"
    }
    untracked = sorted(actual_paths - expected_paths - ignored)
    if untracked:
        failures.append({"code": "file.untracked", "paths": untracked})
    if sums_path.exists():
        for line in sums_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            expected, rel = line.split("  ", 1)
            path = root / rel
            if not path.is_file() or sha256(path) != expected:
                failures.append({"code": "sha256sums.mismatch", "path": rel})
    else:
        failures.append({"code": "sha256sums.missing"})
    tree_material = "\n".join(f"{e['sha256']}  {e['path']}" for e in sorted(entries, key=lambda x: x["path"]))
    tree_hash = hashlib.sha256(tree_material.encode("utf-8")).hexdigest()
    if tree_hash != manifest.get("tree_hash"):
        failures.append({"code": "manifest.tree_hash", "expected": manifest.get("tree_hash"), "actual": tree_hash})
    return {
        "object_type": "UPLIFTReleaseVerification54",
        "status": "PASS" if not failures else "FAIL",
        "root": str(root.resolve()),
        "manifest_files": len(entries),
        "actual_files_excluding_metadata": len(actual_paths - ignored),
        "tree_hash": tree_hash,
        "failures": failures,
    }


if __name__ == "__main__":
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    result = verify(root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 2)
