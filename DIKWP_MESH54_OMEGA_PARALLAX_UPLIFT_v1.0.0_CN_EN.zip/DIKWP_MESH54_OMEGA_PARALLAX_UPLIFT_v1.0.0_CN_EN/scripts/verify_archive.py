#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    if len(sys.argv) < 2:
        raise SystemExit("usage: verify_archive.py <release.zip>")
    archive = Path(sys.argv[1]).resolve()
    failures = []
    with zipfile.ZipFile(archive) as zf:
        bad = zf.testzip()
        if bad:
            failures.append({"code": "zip.crc", "path": bad})
        roots = sorted({name.split("/", 1)[0] for name in zf.namelist() if name and not name.startswith("/")})
        if len(roots) != 1:
            failures.append({"code": "zip.root_count", "roots": roots})
        with tempfile.TemporaryDirectory(prefix="uplift-archive-") as td:
            zf.extractall(td)
            if roots:
                root = Path(td) / roots[0]
                proc = subprocess.run([sys.executable, str(root / "scripts" / "verify_release.py"), str(root)], capture_output=True, text=True)
                try:
                    nested = json.loads(proc.stdout)
                except json.JSONDecodeError:
                    nested = {"status": "FAIL", "stdout": proc.stdout, "stderr": proc.stderr}
                if proc.returncode != 0:
                    failures.append({"code": "release.verify", "detail": nested})
            else:
                nested = {"status": "FAIL"}
    result = {
        "object_type": "UPLIFTArchiveVerification54",
        "status": "PASS" if not failures else "FAIL",
        "archive": str(archive),
        "archive_sha256": sha256(archive),
        "zip_entries": len(zipfile.ZipFile(archive).namelist()),
        "root_directories": roots,
        "nested_release_verification": nested,
        "failures": failures,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
