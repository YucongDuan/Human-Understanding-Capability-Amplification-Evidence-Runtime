#!/usr/bin/env python3
from __future__ import annotations

import base64
import csv
import hashlib
import io
import os
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAME = "dikwp_mesh54_uplift"
DIST = "dikwp_mesh54_uplift"
VERSION = "1.0.0"
DIST_INFO = f"{DIST}-{VERSION}.dist-info"
WHEEL_NAME = f"{DIST}-{VERSION}-py3-none-any.whl"
SDIST_NAME = f"{DIST}-{VERSION}.tar.gz"


def digest(data: bytes) -> str:
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode("ascii")


def metadata() -> bytes:
    return (f"""Metadata-Version: 2.1
Name: dikwp-mesh54-uplift
Version: {VERSION}
Summary: DIKWP-MESH 5.4 Omega human understanding amplification and evidence runtime
License: Apache-2.0
Requires-Python: >=3.10
Requires-Dist: networkx>=3.0
Requires-Dist: jsonschema>=4.18
Requires-Dist: cryptography>=41.0
Project-URL: Documentation, https://example.invalid/dikwp-mesh54-uplift

DIKWP-MESH 5.4 Omega PARALLAX UPLIFT is a learner-governed, multidimensional understanding evidence runtime. The current release is an E2 author-side deterministic reference implementation and does not claim human effectiveness.
""").encode("utf-8")


def build_wheel(out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / WHEEL_NAME
    files: dict[str, bytes] = {}
    package_root = ROOT / "src" / NAME
    for source in sorted(package_root.rglob("*")):
        if source.is_file() and "__pycache__" not in source.parts and source.suffix != ".pyc":
            arc = f"{NAME}/{source.relative_to(package_root).as_posix()}"
            files[arc] = source.read_bytes()
    files[f"{DIST_INFO}/METADATA"] = metadata()
    files[f"{DIST_INFO}/WHEEL"] = (
        "Wheel-Version: 1.0\n"
        "Generator: DIKWP-MESH54-UPLIFT reproducible builder 1.0\n"
        "Root-Is-Purelib: true\n"
        "Tag: py3-none-any\n"
    ).encode("utf-8")
    files[f"{DIST_INFO}/entry_points.txt"] = b"[console_scripts]\nuplift54 = dikwp_mesh54_uplift.cli:main\n"
    files[f"{DIST_INFO}/top_level.txt"] = b"dikwp_mesh54_uplift\n"
    files[f"{DIST_INFO}/licenses/LICENSE"] = (ROOT / "LICENSE").read_bytes()

    record_rows = [[name, digest(data), str(len(data))] for name, data in sorted(files.items())]
    record_rows.append([f"{DIST_INFO}/RECORD", "", ""])
    sio = io.StringIO(newline="")
    csv.writer(sio, lineterminator="\n").writerows(record_rows)
    files[f"{DIST_INFO}/RECORD"] = sio.getvalue().encode("utf-8")

    fixed = (2026, 7, 24, 0, 0, 0)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, fixed)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o644 & 0xFFFF) << 16
            zf.writestr(info, data)
    return path


def include_in_sdist(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in {".pytest_cache", "__pycache__", ".git", "dist", "outputs"} for part in rel.parts):
        return False
    if path.suffix in {".pyc", ".pyo"}:
        return False
    return True


def build_sdist(out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / SDIST_NAME
    prefix = f"{DIST}-{VERSION}"
    members: list[tuple[str, bytes, int]] = []
    for source in sorted(ROOT.rglob("*")):
        if source.is_file() and include_in_sdist(source):
            rel = source.relative_to(ROOT).as_posix()
            members.append((f"{prefix}/{rel}", source.read_bytes(), 0o644))
    members.append((f"{prefix}/PKG-INFO", metadata(), 0o644))
    with tarfile.open(path, "w:gz", format=tarfile.PAX_FORMAT) as tf:
        for name, data, mode in sorted(members):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = mode
            info.mtime = 1784851200  # 2026-07-24T00:00:00Z
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            tf.addfile(info, io.BytesIO(data))
    return path


if __name__ == "__main__":
    out = ROOT / "dist"
    wheel = build_wheel(out)
    sdist = build_sdist(out)
    print(wheel)
    print(sdist)
