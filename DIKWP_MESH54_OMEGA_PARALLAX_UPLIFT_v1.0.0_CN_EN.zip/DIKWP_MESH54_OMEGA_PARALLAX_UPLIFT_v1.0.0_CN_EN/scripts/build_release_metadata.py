#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import importlib.metadata
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

ROOT = Path(__file__).resolve().parents[1]
EXCLUDES = {"MANIFEST.json", "SHA256SUMS.txt"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def release_files() -> list[Path]:
    files = []
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT)
        if rel.as_posix() in EXCLUDES:
            continue
        if any(part in {".pytest_cache", "__pycache__", ".git"} for part in rel.parts) or p.suffix in {".pyc", ".pyo"}:
            continue
        files.append(p)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def package_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def build_sbom() -> Path:
    files = []
    for i, p in enumerate(release_files(), 1):
        rel = p.relative_to(ROOT).as_posix()
        files.append({
            "SPDXID": f"SPDXRef-File-{i}",
            "fileName": f"./{rel}",
            "checksums": [{"algorithm": "SHA256", "checksumValue": sha256(p)}],
        })
    packages = [{
        "name": "dikwp-mesh54-uplift",
        "SPDXID": "SPDXRef-Package-UPLIFT",
        "versionInfo": "1.0.0",
        "downloadLocation": "NOASSERTION",
        "filesAnalyzed": True,
        "licenseConcluded": "Apache-2.0",
        "licenseDeclared": "Apache-2.0",
        "copyrightText": "NOASSERTION",
    }]
    for name in ["networkx", "jsonschema", "cryptography"]:
        packages.append({
            "name": name,
            "SPDXID": f"SPDXRef-Package-{name}",
            "versionInfo": package_version(name),
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "licenseConcluded": "NOASSERTION",
            "licenseDeclared": "NOASSERTION",
            "copyrightText": "NOASSERTION",
        })
    relationships = [
        {"spdxElementId": "SPDXRef-DOCUMENT", "relationshipType": "DESCRIBES", "relatedSpdxElement": "SPDXRef-Package-UPLIFT"},
        *[
            {"spdxElementId": "SPDXRef-Package-UPLIFT", "relationshipType": "DEPENDS_ON", "relatedSpdxElement": f"SPDXRef-Package-{name}"}
            for name in ["networkx", "jsonschema", "cryptography"]
        ],
    ]
    for i in range(1, len(files) + 1):
        relationships.append({"spdxElementId": "SPDXRef-Package-UPLIFT", "relationshipType": "CONTAINS", "relatedSpdxElement": f"SPDXRef-File-{i}"})
    doc = {
        "spdxVersion": "SPDX-2.3",
        "dataLicense": "CC0-1.0",
        "SPDXID": "SPDXRef-DOCUMENT",
        "name": "DIKWP-MESH54-OMEGA-PARALLAX-UPLIFT-1.0.0",
        "documentNamespace": "https://example.invalid/spdx/dikwp-mesh54-uplift/1.0.0/" + hashlib.sha256(os.urandom(32)).hexdigest(),
        "creationInfo": {"created": "2026-07-24T00:00:00Z", "creators": ["Tool: UPLIFT release metadata builder 1.0"]},
        "packages": packages,
        "files": files,
        "relationships": relationships,
        "annotations": [{
            "annotationType": "OTHER",
            "annotator": "Tool: UPLIFT release metadata builder 1.0",
            "annotationDate": "2026-07-24T00:00:00Z",
            "comment": "Author-side SBOM; dependency license fields require independent verification before production use."
        }],
    }
    path = ROOT / "DIKWP_MESH54_UPLIFT_SBOM.spdx.json"
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def build_attestation(sbom: Path) -> Path:
    subjects = []
    for rel in [
        "dist/dikwp_mesh54_uplift-1.0.0-py3-none-any.whl",
        "dist/dikwp_mesh54_uplift-1.0.0.tar.gz",
        "VALIDATION_REPORT.json",
        sbom.relative_to(ROOT).as_posix(),
        "provenance/PARALLAX_CLOSURE_MVP_INPUT.sha256",
    ]:
        p = ROOT / rel
        subjects.append({"name": rel, "digest": {"sha256": sha256(p)}})
    statement = {
        "_type": "https://in-toto.io/Statement/v1",
        "subject": subjects,
        "predicateType": "https://slsa.dev/provenance/v1",
        "predicate": {
            "buildDefinition": {
                "buildType": "https://example.invalid/dikwp-mesh54-uplift/release/v1",
                "externalParameters": {"version": "1.0.0", "framework": "DIKWP-MESH 5.4 Omega", "release_date": "2026-07-24"},
                "internalParameters": {"wheel_builder": "scripts/build_wheel.py", "evidence_grade": "E2-author-side-deterministic-reference"},
                "resolvedDependencies": [{"uri": "file:provenance/PARALLAX_CLOSURE_MVP_INPUT.sha256", "digest": subjects[-1]["digest"]}],
            },
            "runDetails": {
                "builder": {"id": "DIKWP-MESH54-UPLIFT-local-reference-builder"},
                "metadata": {"invocationId": hashlib.sha256(os.urandom(32)).hexdigest(), "startedOn": "2026-07-24T00:00:00Z", "finishedOn": "2026-07-24T00:00:00Z"},
                "byproducts": [{"name": "claim_boundary", "value": "Self-attestation only; not an independent certification or identity proof."}],
            },
        },
    }
    private = Ed25519PrivateKey.generate()
    public = private.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    payload = json.dumps(statement, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    signature = private.sign(payload)
    envelope = {
        "statement": statement,
        "signature": {
            "algorithm": "Ed25519",
            "public_key_b64": base64.b64encode(public).decode("ascii"),
            "signature_b64": base64.b64encode(signature).decode("ascii"),
            "payload_sha256": hashlib.sha256(payload).hexdigest(),
            "claim_boundary": "Ephemeral self-attestation key; verifies this envelope's integrity but not author identity."
        }
    }
    path = ROOT / "DIKWP_MESH54_UPLIFT_ATTESTATION.json"
    path.write_text(json.dumps(envelope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def build_manifest() -> Path:
    entries = []
    for p in release_files():
        rel = p.relative_to(ROOT).as_posix()
        entries.append({"path": rel, "sha256": sha256(p), "size": p.stat().st_size})
    material = "\n".join(f"{e['sha256']}  {e['path']}" for e in entries)
    manifest = {
        "object_type": "UPLIFTReleaseManifest54",
        "system": "DIKWP-MESH 5.4 Ω PARALLAX UPLIFT",
        "version": "1.0.0",
        "generated_at": "2026-07-24T00:00:00Z",
        "evidence_grade": "E2-author-side-deterministic-reference",
        "file_count": len(entries),
        "tree_hash": hashlib.sha256(material.encode("utf-8")).hexdigest(),
        "files": entries,
        "exclusions": ["MANIFEST.json", "SHA256SUMS.txt", "cache/bytecode"],
    }
    path = ROOT / "MANIFEST.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def build_sums() -> Path:
    rows = []
    for p in sorted((p for p in ROOT.rglob("*") if p.is_file()), key=lambda p: p.relative_to(ROOT).as_posix()):
        rel = p.relative_to(ROOT)
        if rel.as_posix() == "SHA256SUMS.txt" or any(part in {".pytest_cache", "__pycache__"} for part in rel.parts) or p.suffix == ".pyc":
            continue
        rows.append(f"{sha256(p)}  {rel.as_posix()}")
    path = ROOT / "SHA256SUMS.txt"
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")
    return path


if __name__ == "__main__":
    sbom = build_sbom()
    attestation = build_attestation(sbom)
    manifest = build_manifest()
    sums = build_sums()
    print(sbom)
    print(attestation)
    print(manifest)
    print(sums)
