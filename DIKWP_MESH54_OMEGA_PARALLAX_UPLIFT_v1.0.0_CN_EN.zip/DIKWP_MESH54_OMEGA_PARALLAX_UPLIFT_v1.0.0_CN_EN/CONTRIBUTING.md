# Contributing

Contributions should preserve the following invariants:

- no global intelligence/personality score;
- training cannot upgrade transfer status;
- delayed status requires a real delayed session;
- open explanations remain pending until signed rubric review;
- learner covenant and lease scope are enforced before commit;
- response, nonce, lease use, score, profile, event and receipt commit atomically;
- scoring keys never appear in public catalog/API output;
- failed and residual evidence is retained.

Before submitting:

```bash
pytest -q
uplift54 conformance --example-dir examples/feedback_loops --out outputs/conformance
uplift54 artifacts-validate --root . --out outputs/ARTIFACT_VALIDATION.json
```

Add tests for any new scoring type, evidence transition, API endpoint or transaction stage. Document scientific non-claims and migration effects. Never submit real learner data or secrets.
