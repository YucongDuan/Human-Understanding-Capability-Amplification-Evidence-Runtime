# Security Policy

## Supported release

Security fixes are applied to the current 1.x reference release. This is not a hosted service and has no automatic update channel.

## Reporting

Report vulnerabilities privately to the maintainer or deployment owner before public disclosure. Include:

- affected version and file hash;
- minimal reproduction;
- whether scoring keys, learner evidence, signatures, covenant revocation, nonce uniqueness, or phase isolation are affected;
- proposed embargo period if coordination is needed.

Do not include real learner data in reports.

## High-severity conditions

- public scoring-key or hidden-form disclosure;
- unauthorized access to learner evidence;
- bypass of covenant revocation;
- nonce reuse yielding multiple accepted states;
- a returned valid receipt without committed state;
- forged or unverifiable signed review/receipt;
- undetected event-chain modification;
- remote code execution or arbitrary file access;
- training evidence being accepted as transfer or delayed evidence.

## Deployment requirements

Keep the API on loopback unless protected by TLS, strong authentication, rate limiting, tenant isolation and privacy review. Store seed, token and scoring keys outside public directories with least-privilege permissions. Use encrypted, SQLite-consistent backups. Never copy a live WAL database as the sole backup method.

## Cryptographic boundary

Ed25519 signatures provide integrity under private-key control. They do not prove reviewer identity, truth of content, legal non-repudiation, or compromise resistance. Key leakage requires revocation and a new trust root.
