from __future__ import annotations

import copy
import json
import shutil
import sqlite3

import pytest

from dikwp_mesh54_uplift.signing import verify_object_signature
from dikwp_mesh54_uplift.store import CovenantViolation, LeaseViolation, NonceConflict, StoreError, UpliftStore
from conftest import activate


def baseline_map(demo_responses):
    return {row[0]: (row[1], row[2]) for row in demo_responses["baseline"]}


def test_register_is_idempotent(engine, covenant):
    first = engine.register_pack("2026-07-24T16:00:00Z")
    second = engine.register_pack("2026-07-24T16:00:00Z")
    assert first["status"] == "REGISTERED"
    assert second["status"] == "IDEMPOTENT"


def test_covenant_rejects_hidden_persuasion(engine, covenant):
    engine.register_pack("2026-07-24T16:00:00Z")
    bad = copy.deepcopy(covenant); bad["covenant_id"] = "bad"; bad["persuasion_allowed"] = True
    with pytest.raises(CovenantViolation):
        engine.activate_covenant(bad, "2026-07-24T16:01:00Z")


def test_covenant_rejects_no_veto(engine, covenant):
    engine.register_pack("2026-07-24T16:00:00Z")
    bad = copy.deepcopy(covenant); bad["covenant_id"] = "bad"; bad["learner_veto"] = False
    with pytest.raises(CovenantViolation):
        engine.activate_covenant(bad, "2026-07-24T16:01:00Z")


def test_session_scope(engine, covenant):
    activate(engine, covenant)
    with pytest.raises(ValueError):
        engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["T01"], "2026-07-24T16:10:00Z")


def test_atomic_submit_and_signature(engine, covenant, demo_responses):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    result = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-1", submitted_at="2026-07-24T16:11:00Z")
    assert result["receipt"]["status"] == "SCORED"
    assert verify_object_signature(result["receipt"], result["signature"])
    counts = engine.store.status()["counts"]
    assert counts["responses"] == counts["receipts"] == 1
    assert counts["profiles"] == 1


def test_idempotent_retry(engine, covenant, demo_responses):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    first = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-1", submitted_at="2026-07-24T16:11:00Z")
    counts = engine.store.status()["counts"]
    second = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-1", submitted_at="2026-07-24T16:12:00Z")
    assert second["idempotent_replay"]
    assert second["receipt"]["receipt_id"] == first["receipt"]["receipt_id"]
    assert engine.store.status()["counts"] == counts


def test_nonce_conflict(engine, covenant, demo_responses):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    engine.submit(session["session_id"], "B01", answer, confidence, "nonce-1", submitted_at="2026-07-24T16:11:00Z")
    with pytest.raises(NonceConflict):
        engine.submit(session["session_id"], "B01", "流量", confidence, "nonce-1", submitted_at="2026-07-24T16:12:00Z")


@pytest.mark.parametrize("stage", ["after_response", "after_nonce", "before_commit"])
def test_crash_injection_rolls_back(engine, covenant, demo_responses, stage):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    before = engine.store.status()["counts"]
    with pytest.raises(RuntimeError):
        engine.submit(session["session_id"], "B01", answer, confidence, "nonce-crash", submitted_at="2026-07-24T16:11:00Z", failure_injection=stage)
    after = engine.store.status()["counts"]
    assert all(before[key] == after[key] for key in ("responses", "receipts", "profiles", "events"))
    result = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-crash", submitted_at="2026-07-24T16:11:00Z")
    assert result["receipt"]["status"] == "SCORED"


def test_manual_review_is_separate_signed_evidence(engine, covenant):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B10"], "2026-07-24T16:10:00Z")["session"]
    pending = engine.submit(session["session_id"], "B10", "开放解释", 0.7, "nonce-review", submitted_at="2026-07-24T16:11:00Z")
    assert pending["receipt"]["status"] == "PENDING_REVIEW"
    review = engine.review_manual_response(pending["receipt"]["response_id"], "teacher", "educator", 0.8, {"rubric": ["mechanism", "example"]}, "2026-07-24T16:12:00Z")
    assert verify_object_signature(review["review"], review["signature"])
    assert engine.profile(covenant["learner_id"])["dimensions"]["compression"]["mean_score"] == 0.8


def test_manual_review_rejects_machine_scored_task(engine, covenant, demo_responses):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    result = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-review-bad", submitted_at="2026-07-24T16:11:00Z")
    with pytest.raises(StoreError):
        engine.review_manual_response(result["receipt"]["response_id"], "teacher", "educator", 0.8, {}, "2026-07-24T16:12:00Z")


def test_plan_and_lease(engine, covenant, demo_responses):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    engine.submit(session["session_id"], "B01", answer, confidence, "nonce-plan", submitted_at="2026-07-24T16:11:00Z")
    result = engine.compile_plan(covenant["covenant_id"], "2026-07-24T17:00:00Z")
    assert result["plan"]["target_phase"] == "training"
    assert result["plan"]["leases"]


def test_out_of_scope_lease_rejected(engine, covenant, demo_responses):
    activate(engine, covenant)
    base = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    engine.submit(base["session_id"], "B01", answer, confidence, "nonce-plan", submitted_at="2026-07-24T16:11:00Z")
    plan = engine.compile_plan(covenant["covenant_id"], "2026-07-24T17:00:00Z")["plan"]
    lease = plan["leases"][0]
    outside = next(task for task in engine.pack["tasks"] if task["phase"] == "training" and task["id"] not in lease["task_ids"] and task["id"] != "T10")
    fixture = {row[0]: (row[1], row[2]) for row in demo_responses["training"]}[outside["id"]]
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "training", "T", [outside["id"]], "2026-07-24T17:10:00Z")["session"]
    with pytest.raises(LeaseViolation):
        engine.submit(session["session_id"], outside["id"], fixture[0], fixture[1], "nonce-out", lease["lease_id"], "2026-07-24T17:11:00Z")


def test_revoke_covenant_stops_sessions(engine, covenant):
    activate(engine, covenant)
    engine.store.revoke_covenant(covenant["covenant_id"], "learner veto", "2026-07-24T16:05:00Z")
    with pytest.raises(CovenantViolation):
        engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")


def test_checkpoint_and_verify(engine, covenant, demo_responses):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    engine.submit(session["session_id"], "B01", answer, confidence, "nonce-cp", submitted_at="2026-07-24T16:11:00Z")
    cp = engine.store.create_checkpoint("2026-07-24T17:00:00Z")
    assert verify_object_signature(cp["checkpoint"], cp["signature"])
    assert engine.verify()["status"] == "PASS"


def test_tamper_detected(engine, covenant, demo_responses, tmp_path, signer):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    engine.submit(session["session_id"], "B01", answer, confidence, "nonce-t", submitted_at="2026-07-24T16:11:00Z")
    tampered = tmp_path / "tampered.sqlite"
    engine.store.backup_to(tampered)
    with sqlite3.connect(tampered) as conn:
        row = conn.execute("SELECT seq,payload_json FROM events ORDER BY seq LIMIT 1").fetchone()
        payload = json.loads(row[1]); payload["tamper"] = True
        conn.execute("UPDATE events SET payload_json=? WHERE seq=?", (json.dumps(payload), row[0])); conn.commit()
    report = UpliftStore(tampered, signer, node_id="PYTEST-NODE").verify()
    assert report["status"] == "FAIL"
    assert any(item.startswith("event_payload_hash") for item in report["failures"])


def test_missing_nonce_detected_without_crash(engine, covenant, demo_responses):
    activate(engine, covenant)
    session = engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z")["session"]
    answer, confidence = baseline_map(demo_responses)["B01"]
    result = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-missing", submitted_at="2026-07-24T16:11:00Z")
    with sqlite3.connect(engine.store.database) as conn:
        conn.execute("PRAGMA foreign_keys=OFF")
        conn.execute("DELETE FROM nonces WHERE response_id=?", (result["receipt"]["response_id"],)); conn.commit()
    report = engine.verify()
    assert report["status"] == "FAIL"
    assert any(item.startswith("response_nonce_missing") for item in report["failures"])
