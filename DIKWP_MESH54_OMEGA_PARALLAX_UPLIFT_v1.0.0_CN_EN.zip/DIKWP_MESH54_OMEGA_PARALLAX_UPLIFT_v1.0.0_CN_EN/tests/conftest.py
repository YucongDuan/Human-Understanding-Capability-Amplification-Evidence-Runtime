from __future__ import annotations

import json
from pathlib import Path

import pytest

from dikwp_mesh54_uplift.engine import UpliftEngine
from dikwp_mesh54_uplift.pack import load_knowledge_pack, load_scoring_key
from dikwp_mesh54_uplift.signing import Ed25519Signer
from dikwp_mesh54_uplift.store import UpliftStore


ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "examples" / "feedback_loops"


@pytest.fixture
def pack():
    return load_knowledge_pack(EXAMPLE / "knowledge_pack.json")


@pytest.fixture
def key(pack):
    return load_scoring_key(EXAMPLE / "scoring_key.private.json", pack)


@pytest.fixture
def covenant():
    return json.loads((EXAMPLE / "understanding_covenant.json").read_text(encoding="utf-8"))


@pytest.fixture
def demo_responses():
    return json.loads((EXAMPLE / "demo_responses.json").read_text(encoding="utf-8"))


@pytest.fixture
def signer():
    return Ed25519Signer.from_seed_text("UPLIFT-PYTEST-SEED")


@pytest.fixture
def engine(tmp_path, pack, key, signer):
    store = UpliftStore(tmp_path / "runtime.sqlite", signer, node_id="PYTEST-NODE")
    return UpliftEngine(pack, key, store)


def activate(engine: UpliftEngine, covenant: dict):
    engine.register_pack(created_at="2026-07-24T16:00:00Z")
    engine.activate_covenant(covenant, created_at="2026-07-24T16:01:00Z")
