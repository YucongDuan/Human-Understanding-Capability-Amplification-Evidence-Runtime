from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request

import pytest

from dikwp_mesh54_uplift.api import MAX_BODY_BYTES, UpliftHTTPServer
from conftest import activate


TOKEN = "test-token-with-at-least-16-characters"


@pytest.fixture
def api_server(engine, covenant):
    activate(engine, covenant)
    server = UpliftHTTPServer(("127.0.0.1", 0), engine, TOKEN)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}", engine, covenant
    server.shutdown(); server.server_close(); thread.join(timeout=2)


def request(base, path, method="GET", body=None, token=TOKEN, content_type="application/json"):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(base + path, data=data, method=method)
    if token is not None:
        req.add_header("Authorization", "Bearer " + token)
    if data is not None:
        req.add_header("Content-Type", content_type)
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            return response.status, dict(response.headers), response.read()
    except urllib.error.HTTPError as error:
        return error.code, dict(error.headers), error.read()


def test_short_token_rejected(engine):
    with pytest.raises(ValueError):
        UpliftHTTPServer(("127.0.0.1", 0), engine, "short")


def test_health_is_public(api_server):
    base, _, _ = api_server
    status, headers, body = request(base, "/health", token=None)
    assert status == 200
    assert json.loads(body)["status"] == "PASS"
    assert headers["Cache-Control"] == "no-store"


def test_catalog_requires_auth_and_hides_scoring_key(api_server):
    base, _, _ = api_server
    status, _, _ = request(base, "/v1/catalog?phase=baseline&form=A", token=None)
    assert status == 401
    status, _, body = request(base, "/v1/catalog?phase=baseline&form=A")
    payload = json.loads(body)
    assert status == 200
    assert payload["tasks"]
    text = json.dumps(payload, ensure_ascii=False)
    assert '"correct"' not in text
    assert "scoring_key" not in text


def test_studio_is_single_file(api_server):
    base, _, _ = api_server
    status, headers, body = request(base, "/studio", token=None)
    text = body.decode("utf-8")
    assert status == 200
    assert "Content-Security-Policy" in text
    assert "<script src=" not in text
    assert headers["X-Frame-Options"] == "DENY"


def test_session_submit_profile_and_plan(api_server, demo_responses):
    base, _, covenant = api_server
    session_body = {
        "learner_id": covenant["learner_id"],
        "covenant_id": covenant["covenant_id"],
        "phase": "baseline",
        "form": "A",
        "task_ids": ["B01"],
        "started_at": "2026-07-24T16:10:00Z",
    }
    status, _, raw = request(base, "/v1/sessions", "POST", session_body)
    assert status == 200
    session = json.loads(raw)["session"]
    answer = {row[0]: row[1:] for row in demo_responses["baseline"]}["B01"]
    response_body = {
        "session_id": session["session_id"], "task_id": "B01", "answer": answer[0], "confidence": answer[1],
        "nonce": "api-nonce-1", "submitted_at": "2026-07-24T16:11:00Z",
    }
    status, _, raw = request(base, "/v1/responses", "POST", response_body)
    assert status == 200
    assert json.loads(raw)["receipt"]["score"] == 1.0
    status, _, raw = request(base, "/v1/profile?learner_id=" + covenant["learner_id"])
    assert status == 200
    assert json.loads(raw)["dimensions"]["reconstruction"]["n_scored"] == 1
    status, _, raw = request(base, "/v1/plans", "POST", {"covenant_id": covenant["covenant_id"], "issued_at": "2026-07-24T17:00:00Z"})
    assert status == 200
    assert json.loads(raw)["plan"]["target_phase"] == "training"


def test_wrong_content_type_rejected(api_server):
    base, _, covenant = api_server
    status, _, raw = request(base, "/v1/plans", "POST", {"covenant_id": covenant["covenant_id"]}, content_type="text/plain")
    assert status == 400
    assert "Content-Type" in json.loads(raw)["message"]


def test_invalid_token_rejected(api_server):
    base, _, _ = api_server
    status, _, raw = request(base, "/v1/status", token="wrong-token-that-is-long-enough")
    assert status == 401
    assert json.loads(raw)["status"] == "ERROR"


def test_missing_field_is_structured_error(api_server):
    base, _, _ = api_server
    status, _, raw = request(base, "/v1/sessions", "POST", {"phase": "baseline"})
    payload = json.loads(raw)
    assert status == 400
    assert payload["error_type"] == "MissingField"
