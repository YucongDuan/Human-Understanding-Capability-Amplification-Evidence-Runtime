from __future__ import annotations

import copy

import pytest

from dikwp_mesh54_uplift.pack import PackValidationError, audit_knowledge_pack, validate_pack, validate_scoring_key
from dikwp_mesh54_uplift.scoring import calibration_metrics, score_answer


def task_map(pack):
    return {t["id"]: t for t in pack["tasks"]}


def test_pack_validation_counts(pack):
    report = validate_pack(pack)
    assert report["status"] == "PASS"
    assert report["counts"]["tasks"] == 40


def test_pack_covers_all_dimensions(pack):
    assert len({t["dimension"] for t in pack["tasks"]}) == 12


def test_pack_covers_all_phases(pack):
    assert {t["phase"] for t in pack["tasks"]} == {"baseline", "training", "transfer", "delayed"}


def test_duplicate_task_rejected(pack):
    broken = copy.deepcopy(pack)
    broken["tasks"].append(copy.deepcopy(broken["tasks"][0]))
    with pytest.raises(PackValidationError):
        validate_pack(broken)


def test_unknown_concept_rejected(pack):
    broken = copy.deepcopy(pack)
    broken["tasks"][0]["concept_ids"] = ["not-a-concept"]
    with pytest.raises(PackValidationError):
        validate_pack(broken)


def test_prerequisite_cycle_rejected(pack):
    broken = copy.deepcopy(pack)
    first, second = broken["concepts"][0], broken["concepts"][1]
    first["prerequisites"] = [second["id"]]
    second["prerequisites"] = [first["id"]]
    with pytest.raises(PackValidationError):
        validate_pack(broken)


def test_scoring_key_bound_to_pack(pack, key):
    report = validate_scoring_key(key, pack)
    assert report["answer_count"] == len(pack["tasks"])


def test_scoring_key_missing_task_rejected(pack, key):
    broken = copy.deepcopy(key)
    broken["answers"].pop(next(iter(broken["answers"])))
    with pytest.raises(PackValidationError):
        validate_scoring_key(broken, pack)


def test_curriculum_audit_is_open(pack):
    audit = audit_knowledge_pack(pack)
    assert audit["status"] == "ACTIVE"
    assert audit["closure_profile"]["generative_openness"] > 0.8
    assert audit["closure_profile"]["seal_strength"] < 0.3


def test_single_choice_scoring(pack, key):
    task = task_map(pack)["B01"]
    assert score_answer(task, key["answers"]["B01"], "存量")["score"] == 1
    assert score_answer(task, key["answers"]["B01"], "流量")["score"] == 0


def test_multiselect_partial_scoring(pack, key):
    task = task_map(pack)["B05"]
    result = score_answer(task, key["answers"]["B05"], ["重复来电率上升"])
    assert 0 < result["score"] < 1


def test_numeric_partial_scoring(pack, key):
    task = task_map(pack)["X02"]
    result = score_answer(task, key["answers"]["X02"], 47)
    assert 0 < result["score"] < 1


def test_ranking_scoring(pack, key):
    task = task_map(pack)["B08"]
    correct = key["answers"]["B08"]["correct"]
    assert score_answer(task, key["answers"]["B08"], correct)["score"] == 1
    reversed_score = score_answer(task, key["answers"]["B08"], list(reversed(correct)))["score"]
    assert reversed_score < 0.5


def test_edge_set_scoring_is_order_insensitive(pack, key):
    task = task_map(pack)["B02"]
    correct = key["answers"]["B02"]["correct"]
    assert score_answer(task, key["answers"]["B02"], list(reversed(correct)))["score"] == 1


def test_classification_partial(pack, key):
    task = task_map(pack)["B06"]
    answer = {"季度成本下降": "管理层"}
    result = score_answer(task, key["answers"]["B06"], answer)
    assert 0 < result["score"] < 1


def test_manual_rubric_never_keyword_scores(pack, key):
    task = task_map(pack)["B10"]
    result = score_answer(task, key["answers"]["B10"], "包含所有关键词")
    assert result["status"] == "PENDING_REVIEW"
    assert result["score"] is None


def test_calibration_metrics():
    result = calibration_metrics(1.0, 0.8)
    assert result["brier"] == 0.04
    assert result["signed_gap"] == -0.2
