from __future__ import annotations

import base64

import pytest

from dikwp_mesh54_uplift.canonical import bounded, canonical_json, derive_id, merkle_root_hex, object_hash, parse_utc, sha256_hex
from dikwp_mesh54_uplift.signing import Ed25519Signer, verify_object_signature


def test_canonical_json_key_order():
    assert canonical_json({"z": 1, "a": 2}) == canonical_json({"a": 2, "z": 1})


def test_canonical_json_preserves_unicode():
    assert "理解" in canonical_json({"概念": "理解"})


def test_hash_is_stable_and_sensitive():
    assert object_hash({"a": 1}) == object_hash({"a": 1})
    assert object_hash({"a": 1}) != object_hash({"a": 2})


def test_derive_id_has_prefix_and_length():
    value = derive_id("task", {"a": 1})
    assert value.startswith("task-")
    assert len(value.split("-", 1)[1]) == 24


def test_parse_utc_normalizes_timezone():
    assert parse_utc("2026-07-24T09:00:00-07:00").isoformat() == "2026-07-24T16:00:00+00:00"


def test_merkle_empty_and_deterministic():
    assert merkle_root_hex([]) == sha256_hex(b"")
    leaves = [sha256_hex("a"), sha256_hex("b"), sha256_hex("c")]
    assert merkle_root_hex(leaves) == merkle_root_hex(leaves)
    assert merkle_root_hex(leaves) != merkle_root_hex(list(reversed(leaves)))


def test_bounded():
    assert bounded(-1) == 0
    assert bounded(2) == 1
    assert bounded(0.4) == 0.4


def test_sign_and_verify(signer):
    value = {"claim": "task-scoped", "score": 0.8}
    envelope = signer.sign_object(value).to_dict()
    assert verify_object_signature(value, envelope)
    assert not verify_object_signature({**value, "score": 0.9}, envelope)


def test_seed_is_deterministic():
    a = Ed25519Signer.from_seed_text("same")
    b = Ed25519Signer.from_seed_text("same")
    assert a.key_id == b.key_id
    assert a.sign_object({"x": 1}).signature_b64 == b.sign_object({"x": 1}).signature_b64


def test_private_key_round_trip(signer):
    clone = Ed25519Signer.from_private_key_b64(signer.private_key_b64())
    assert clone.key_id == signer.key_id


def test_bad_private_key_rejected():
    with pytest.raises(ValueError):
        Ed25519Signer.from_private_key_b64(base64.b64encode(b"too-short").decode())
