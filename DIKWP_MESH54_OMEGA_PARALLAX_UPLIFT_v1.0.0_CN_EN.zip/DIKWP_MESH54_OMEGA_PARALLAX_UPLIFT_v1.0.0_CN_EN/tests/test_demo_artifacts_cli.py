from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from dikwp_mesh54_uplift.artifacts import validate_artifacts
from dikwp_mesh54_uplift.conformance import run_conformance
from dikwp_mesh54_uplift.demo import run_demo


ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "examples" / "feedback_loops"


def test_full_demo_passes(tmp_path):
    summary = run_demo(EXAMPLE, tmp_path / "demo")
    assert summary["runtime_status"] == "PASS"
    assert all(value == "PASS" for value in summary["proofs"].values())
    assert summary["store_verification"]["status"] == "PASS"


def test_demo_has_holdout_and_delayed_evidence(tmp_path):
    summary = run_demo(EXAMPLE, tmp_path / "demo")
    assert summary["plans"]["after_training"]["target_phase"] == "transfer"
    assert summary["plans"]["before_delayed"]["target_phase"] == "delayed"
    assert summary["profiles"]["final"]["evidence_frontier"]["retention_claim_allowed"]


def test_demo_dashboard_is_single_file_offline(tmp_path):
    run_demo(EXAMPLE, tmp_path / "demo")
    page = (tmp_path / "demo" / "dashboard.html").read_text(encoding="utf-8")
    assert "Content-Security-Policy" in page
    assert "https://" not in page
    assert "<script src=" not in page


def test_conformance_passes(tmp_path):
    report = run_conformance(EXAMPLE, tmp_path / "conformance")
    assert report["status"] == "PASS"
    assert report["total"] >= 40


def test_release_artifact_validation_passes():
    # Canonical generated outputs are part of the checked-in delivery tree.
    report = validate_artifacts(ROOT)
    assert report["status"] == "PASS"
    assert report["schema_count"] >= 15


def test_cli_version():
    result = subprocess.run([sys.executable, "-m", "dikwp_mesh54_uplift", "--version"], cwd=ROOT, env={**__import__('os').environ, "PYTHONPATH": str(ROOT / "src")}, text=True, capture_output=True)
    assert result.returncode == 0
    assert "1.0.0" in result.stdout


def test_cli_audit_pack():
    result = subprocess.run([sys.executable, "-m", "dikwp_mesh54_uplift", "audit-pack", "--pack", str(EXAMPLE / "knowledge_pack.json")], cwd=ROOT, env={**__import__('os').environ, "PYTHONPATH": str(ROOT / "src")}, text=True, capture_output=True)
    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert payload["status"] == "ACTIVE"


def test_cli_demo(tmp_path):
    output = tmp_path / "cli-demo"
    result = subprocess.run([sys.executable, "-m", "dikwp_mesh54_uplift", "demo", "--example-dir", str(EXAMPLE), "--out", str(output)], cwd=ROOT, env={**__import__('os').environ, "PYTHONPATH": str(ROOT / "src")}, text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    assert (output / "DEMO_SUMMARY.json").exists()
    assert json.loads((output / "RUN_PROOF.json").read_text())["status"] == "PASS"
