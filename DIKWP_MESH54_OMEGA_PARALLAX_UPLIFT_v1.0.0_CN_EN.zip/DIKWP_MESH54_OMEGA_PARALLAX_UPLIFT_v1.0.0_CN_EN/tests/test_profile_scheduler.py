from __future__ import annotations

import json
from pathlib import Path

from dikwp_mesh54_uplift.profile import build_understanding_profile, learner_closure_diagnostics
from dikwp_mesh54_uplift.scheduler import compile_intervention_plan, detect_bottlenecks


ROOT = Path(__file__).resolve().parents[1]


def receipt(task_id, phase, score, confidence=0.8, when="2026-07-24T16:00:00Z"):
    return {"receipt_id": f"r-{task_id}", "response_id": f"x-{task_id}", "task_id": task_id, "phase": phase, "score": score, "confidence": confidence, "status": "SCORED", "submitted_at": when}


def test_empty_profile_is_not_scalar_judgment(pack):
    profile = build_understanding_profile(pack, [], "learner", "2026-07-24T16:00:00Z")
    assert profile["evidence_frontier"]["observed_dimension_count"] == 0
    assert "intelligence quotient" in profile["interpretation"]
    assert all(v["evidence_state"] == "UNOBSERVED" for v in profile["dimensions"].values())


def test_training_only_is_not_transfer_supported(pack):
    receipts = [receipt("T01", "training", 1.0), receipt("T02", "training", 1.0)]
    profile = build_understanding_profile(pack, receipts, "learner", "2026-07-25T16:00:00Z")
    assert not profile["evidence_frontier"]["verified_dimensions"]
    assert "run_holdout_transfer_form" in profile["open_obligations"]


def test_transfer_supports_dimension(pack):
    receipts = [receipt("T05", "training", 1.0), receipt("X01", "transfer", 1.0)]
    profile = build_understanding_profile(pack, receipts, "learner", "2026-07-26T16:00:00Z")
    assert profile["dimensions"]["transfer"]["evidence_state"] == "TRANSFER_SUPPORTED"


def test_delayed_supports_retention(pack):
    receipts = [receipt("D03", "delayed", 1.0)]
    profile = build_understanding_profile(pack, receipts, "learner", "2026-08-24T16:00:00Z")
    assert profile["dimensions"]["transfer"]["evidence_state"] == "RETENTION_SUPPORTED"
    assert profile["evidence_frontier"]["retention_claim_allowed"]


def test_overconfidence_detected(pack):
    receipts = [receipt("B01", "baseline", 0.0, 0.95), receipt("B02", "baseline", 0.0, 0.9)]
    profile = build_understanding_profile(pack, receipts, "learner", "2026-07-24T16:00:00Z")
    assert profile["metacognition"]["overconfidence_risk"] > 0.8


def test_closure_diagnostics_are_task_scoped(pack):
    receipts = [receipt("B01", "baseline", 1.0), receipt("B06", "baseline", 0.0)]
    diagnostic = learner_closure_diagnostics(pack, receipts)
    assert diagnostic["object_type"] == "LearnerClosureDiagnostics54"
    assert "diagnostic_hash" in diagnostic
    assert "do not infer identity" in diagnostic["interpretation"].lower()


def test_bottleneck_maps_overconfidence(pack):
    receipts = [receipt("B01", "baseline", 0.0, 0.95), receipt("B02", "baseline", 0.0, 0.9)]
    profile = build_understanding_profile(pack, receipts, "learner", "2026-07-24T16:00:00Z")
    closure = learner_closure_diagnostics(pack, receipts)
    codes = {b["code"] for b in detect_bottlenecks(profile, closure)}
    assert "illusion_of_fluency" in codes
    assert "retention_unverified" in codes


def test_plan_respects_covenant(pack, covenant):
    receipts = [receipt("B01", "baseline", 0.0, 0.95), receipt("B02", "baseline", 0.0, 0.9)]
    profile = build_understanding_profile(pack, receipts, covenant["learner_id"], "2026-07-24T17:00:00Z")
    closure = learner_closure_diagnostics(pack, receipts)
    plan = compile_intervention_plan(pack, profile, closure, receipts, covenant, "2026-07-24T17:00:00Z")
    allowed = set(covenant["allowed_interventions"])
    assert plan["target_phase"] == "training"
    assert all(set(step["interventions"]) <= allowed for step in plan["selected_steps"])
    assert plan["estimated_minutes"] <= covenant["max_session_minutes"]


def test_plan_advances_to_transfer(pack, covenant):
    receipts = [receipt("T01", "training", 1.0), receipt("T02", "training", 1.0)]
    profile = build_understanding_profile(pack, receipts, covenant["learner_id"], "2026-07-25T17:00:00Z")
    closure = learner_closure_diagnostics(pack, receipts)
    plan = compile_intervention_plan(pack, profile, closure, receipts, covenant, "2026-07-25T17:00:00Z")
    assert plan["target_phase"] == "transfer"


def test_plan_advances_to_delayed(pack, covenant):
    receipts = [receipt("T01", "training", 1.0), receipt("X01", "transfer", 1.0)]
    profile = build_understanding_profile(pack, receipts, covenant["learner_id"], "2026-07-26T17:00:00Z")
    closure = learner_closure_diagnostics(pack, receipts)
    plan = compile_intervention_plan(pack, profile, closure, receipts, covenant, "2026-07-26T17:00:00Z")
    assert plan["target_phase"] == "delayed"


def test_plan_lease_scope_matches_steps(pack, covenant):
    receipts = [receipt("B01", "baseline", 0.0, 0.95)]
    profile = build_understanding_profile(pack, receipts, covenant["learner_id"], "2026-07-24T17:00:00Z")
    closure = learner_closure_diagnostics(pack, receipts)
    plan = compile_intervention_plan(pack, profile, closure, receipts, covenant, "2026-07-24T17:00:00Z")
    selected = {step["task_id"] for step in plan["selected_steps"]}
    assert all(set(lease["task_ids"]) <= selected for lease in plan["leases"])
