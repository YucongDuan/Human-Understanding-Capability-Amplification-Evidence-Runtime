# Governance

## Learner constitutional rights

1. Informed purpose and data scope.
2. Refusal of any task or intervention.
3. Revocation of the entire covenant.
4. Access to task-level receipts and claim boundaries.
5. Correction or appeal of manual review.
6. Export and deletion subject to disclosed legal/research constraints.
7. No conversion of task evidence into intelligence, personality, mental-health or human-worth labels.
8. No consequential automated decision based on UPLIFT output.

## Release gates

A knowledge pack or runtime release must not be promoted when:

- transfer forms are leaked or not frozen;
- scoring keys mismatch the pack version;
- schema/conformance/integrity checks fail;
- withdrawal does not revoke active leases;
- curriculum closure audit is on HOLD without documented remediation;
- adverse outcomes exceed preregistered thresholds;
- independent reviewers cannot reproduce the evidence chain.

## Roles

- **Learner:** controls purpose, burden and veto.
- **Author:** owns content provenance and task validity.
- **Reviewer:** signs rubric evidence and discloses conflicts.
- **Operator:** protects keys, databases and backups.
- **Research lead:** preregisters claims and analysis.
- **Affected-party representative:** reviews prohibited outcomes and harm signals.
- **Independent auditor:** attempts reproduction and adversarial challenge.

## Change control

Changes to scoring, phase definitions, evidence thresholds, hash rules or prohibited uses require a new version, migration notes, tests, updated manifests and explicit rollback. Negative and failed results remain part of the evidence record.
