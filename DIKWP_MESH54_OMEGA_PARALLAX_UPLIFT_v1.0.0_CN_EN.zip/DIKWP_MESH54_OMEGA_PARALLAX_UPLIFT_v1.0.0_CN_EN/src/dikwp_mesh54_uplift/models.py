from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


UNDERSTANDING_DIMENSIONS = (
    "reconstruction",
    "mechanism",
    "prediction",
    "counterfactual",
    "transfer",
    "boundary",
    "perspective",
    "calibration",
    "revision",
    "compression",
    "residual",
    "purpose",
)

DIKWP_LAYERS = ("D", "I", "K", "W", "P")
PHASES = ("baseline", "training", "transfer", "delayed")
RESPONSE_TYPES = (
    "single_choice",
    "multi_select",
    "numeric",
    "ranking",
    "edge_set",
    "classification",
    "manual_rubric",
)


@dataclass(frozen=True)
class UnderstandingCovenant:
    covenant_id: str
    learner_id: str
    pack_id: str
    purpose: str
    allowed_domains: list[str]
    allowed_interventions: list[str]
    prohibited_outcomes: list[str]
    max_session_minutes: int = 30
    max_items_per_session: int = 8
    data_retention_days: int = 365
    external_sharing: bool = False
    persuasion_allowed: bool = False
    learner_veto: bool = True
    issued_at: str = ""
    expires_at: str = ""
    status: str = "ACTIVE"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class InterventionLease:
    lease_id: str
    covenant_id: str
    learner_id: str
    pack_id: str
    intervention: str
    task_ids: list[str]
    max_uses: int
    issued_at: str
    expires_at: str
    status: str = "ACTIVE"
    reversible: bool = True
    reason_codes: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SessionDescriptor:
    session_id: str
    learner_id: str
    pack_id: str
    covenant_id: str
    phase: str
    form: str
    task_ids: list[str]
    started_at: str
    expires_at: str
    status: str = "ACTIVE"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
