from __future__ import annotations

import hmac
import json
import secrets
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .engine import UpliftEngine
from .store import UpliftStore


MAX_BODY_BYTES = 1024 * 1024


STUDIO_HTML = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src data:; base-uri 'none'; form-action 'none'">
<title>PARALLAX UPLIFT · Learner Studio</title>
<style>
:root{--bg:#071019;--panel:#101d29;--line:#29475d;--text:#eaf2f7;--muted:#90a7b8;--accent:#72e3c2;--accent2:#7ab7ff;--warn:#ffcb77;--bad:#ff8691}*{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#071019,#0a1824);color:var(--text);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}.wrap{max-width:1120px;margin:auto;padding:24px}.top{display:grid;grid-template-columns:1fr auto;gap:18px;align-items:end;border-bottom:1px solid var(--line);padding-bottom:18px}.eyebrow{font-size:11px;letter-spacing:.18em;color:var(--accent);text-transform:uppercase;font-weight:800}h1{font-size:clamp(28px,5vw,48px);line-height:1.05;margin:5px 0}.muted{color:var(--muted)}.grid{display:grid;gap:16px}.two{grid-template-columns:.8fr 1.2fr}.panel{background:rgba(16,29,41,.96);border:1px solid var(--line);border-radius:16px;padding:18px;margin-top:16px}label{display:block;margin:9px 0 5px;color:var(--muted)}input,select,textarea,button{font:inherit}input,select,textarea{width:100%;background:#07131e;border:1px solid var(--line);border-radius:10px;color:var(--text);padding:10px}textarea{min-height:110px}button{border:1px solid var(--accent);background:#0b2a2b;color:var(--accent);font-weight:800;border-radius:10px;padding:10px 14px;cursor:pointer;margin:8px 6px 0 0}button.secondary{border-color:var(--accent2);color:var(--accent2);background:#10243a}button:disabled{opacity:.4;cursor:not-allowed}.task{border:1px solid var(--line);border-radius:12px;padding:14px;margin:10px 0;background:#091722}.task.active{border-color:var(--accent)}.pill{display:inline-block;border:1px solid var(--line);border-radius:99px;padding:2px 8px;margin:2px;color:var(--muted);font-size:12px}.result{white-space:pre-wrap;background:#06101a;border:1px solid var(--line);border-radius:10px;padding:12px;max-height:360px;overflow:auto}.score{font-size:28px;font-weight:900;color:var(--accent)}.warning{color:var(--warn)}.error{color:var(--bad)}.bar{height:6px;background:#06101a;border-radius:99px;overflow:hidden}.bar span{display:block;height:100%;background:linear-gradient(90deg,var(--accent2),var(--accent))}@media(max-width:800px){.two,.top{grid-template-columns:1fr}}</style></head>
<body><main class="wrap"><header class="top"><div><div class="eyebrow">DIKWP-MESH 5.4 Ω · PARALLAX UPLIFT</div><h1>理解能力提升工作台</h1><div class="muted">先预测信心，再作答；训练、迁移和延迟保持分别记录。你可以随时停止或撤销契约。</div></div><div id="health" class="pill">offline</div></header>
<section class="grid two"><article class="panel"><h2>会话控制</h2><label>API 令牌（仅保存在本页内存）</label><input id="token" type="password" autocomplete="off"><label>阶段</label><select id="phase"><option>baseline</option><option>training</option><option>transfer</option><option>delayed</option></select><label>表单</label><input id="form" value="A"><button onclick="loadTasks()">载入任务</button><button class="secondary" onclick="createSession()">创建会话</button><button class="secondary" onclick="compilePlan()">生成下一轮计划</button><p id="sessionInfo" class="muted">尚未创建会话。</p><div id="taskList"></div></article>
<article class="panel"><h2 id="taskTitle">选择一个任务</h2><div id="taskMeta"></div><p id="prompt" class="muted">系统不会把训练题表现冒充迁移能力。</p><label>答案（JSON；字符串需写成 "答案"）</label><textarea id="answer" placeholder='"存量"'></textarea><label>作答前信心：<span id="confidenceText">0.50</span></label><input id="confidence" type="range" min="0" max="1" step="0.01" value="0.5" oninput="confidenceText.textContent=Number(this.value).toFixed(2)"><button id="submitBtn" onclick="submitResponse()" disabled>原子提交回答</button><div id="responseResult" class="result muted">等待回答。</div></article></section>
<section class="grid two"><article class="panel"><h2>理解证据画像</h2><button onclick="loadProfile()">刷新画像</button><div id="profile"></div></article><article class="panel"><h2>下一轮证据计划</h2><div id="plan" class="result muted">尚未生成。</div></article></section>
<section class="panel"><h2>使用边界</h2><p class="warning">本系统不能用于 IQ、人格、心理健康、招生、就业或隐蔽说服判断。开放解释题需要披露的人工量表复核；训练提升不等于迁移，迁移不等于长期保持。</p></section></main>
<script>
let catalog=null, currentTask=null, session=null, lastPlan=null;
const learnerId='learner-demo-001', covenantId='covenant-demo-learner-feedback-v1';
function headers(){return {'Authorization':'Bearer '+document.getElementById('token').value,'Content-Type':'application/json'}}
async function api(path,options={}){options.headers={...(options.headers||{}),...headers()};const r=await fetch(path,options);const t=await r.text();let x;try{x=JSON.parse(t)}catch{x={raw:t}}if(!r.ok)throw new Error(x.message||x.error||r.status);return x}
async function health(){try{const r=await fetch('/health');healthEl=document.getElementById('health');healthEl.textContent=(await r.json()).status}catch{}}
async function loadTasks(){try{catalog=await api('/v1/catalog?phase='+encodeURIComponent(phase.value)+'&form='+encodeURIComponent(form.value));taskList.innerHTML='';catalog.tasks.forEach(t=>{let d=document.createElement('div');d.className='task';d.textContent=t.id+' · '+t.dimension+' · '+t.response_type;d.onclick=()=>selectTask(t,d);taskList.appendChild(d)});sessionInfo.textContent=catalog.tasks.length+' 个任务已载入。'}catch(e){sessionInfo.innerHTML='<span class="error">'+e.message+'</span>'}}
function selectTask(t,node){currentTask=t;document.querySelectorAll('.task').forEach(x=>x.classList.remove('active'));node.classList.add('active');taskTitle.textContent=t.id+' · '+t.dimension;taskMeta.innerHTML=['DIKWP '+t.dikwp_layer,t.phase,t.form,t.response_type,'难度 '+t.difficulty].map(x=>'<span class="pill">'+x+'</span>').join('');prompt.textContent=t.prompt_cn||t.prompt_en;answer.value='';submitBtn.disabled=!session||!session.task_ids.includes(t.id)}
async function createSession(){try{let ids=catalog?catalog.tasks.map(t=>t.id):[];let body={learner_id:learnerId,covenant_id:covenantId,phase:phase.value,form:form.value,task_ids:ids,duration_minutes:120};let x=await api('/v1/sessions',{method:'POST',body:JSON.stringify(body)});session=x.session;sessionInfo.textContent='会话 '+session.session_id+' · '+session.task_ids.length+' 题';submitBtn.disabled=!currentTask||!session.task_ids.includes(currentTask.id)}catch(e){sessionInfo.innerHTML='<span class="error">'+e.message+'</span>'}}
async function submitResponse(){try{let parsed=JSON.parse(answer.value);let nonce=crypto.randomUUID();let body={session_id:session.session_id,task_id:currentTask.id,answer:parsed,confidence:Number(confidence.value),nonce};let x=await api('/v1/responses',{method:'POST',body:JSON.stringify(body)});let r=x.receipt;responseResult.innerHTML='<div class="score">'+(r.score===null?'待人工复核':Math.round(r.score*100)+'%')+'</div>状态 '+r.status+'\n证据回执 '+r.receipt_id+'\n'+r.claim_boundary;await loadProfile()}catch(e){responseResult.innerHTML='<span class="error">'+e.message+'</span>'}}
async function loadProfile(){try{let p=await api('/v1/profile?learner_id='+encodeURIComponent(learnerId));let rows=Object.entries(p.dimensions).map(([k,v])=>'<div><b>'+k+'</b> · '+v.evidence_state+' · '+(v.mean_score===null?'—':Math.round(v.mean_score*100)+'%')+'<div class="bar"><span style="width:'+((v.mean_score||0)*100)+'%"></span></div></div>').join('');profile.innerHTML=rows+'<p class="muted">Brier '+(p.metacognition.global_brier??'—')+' · 已支持维度 '+p.evidence_frontier.verified_count+'</p>'}catch(e){profile.innerHTML='<span class="error">'+e.message+'</span>'}}
async function compilePlan(){try{let x=await api('/v1/plans',{method:'POST',body:JSON.stringify({covenant_id:covenantId})});lastPlan=x.plan;plan.textContent=JSON.stringify({target_phase:lastPlan.target_phase,bottlenecks:lastPlan.bottlenecks.slice(0,6),selected_steps:lastPlan.selected_steps},null,2)}catch(e){plan.innerHTML='<span class="error">'+e.message+'</span>'}}
health();
</script></body></html>'''


def _public_catalog(engine: UpliftEngine, phase: str | None = None, form: str | None = None) -> dict[str, Any]:
    tasks = []
    for task in engine.pack["tasks"]:
        if phase and task["phase"] != phase:
            continue
        if form and task["form"] != form:
            continue
        tasks.append(
            {
                "id": task["id"],
                "dimension": task["dimension"],
                "dikwp_layer": task["dikwp_layer"],
                "phase": task["phase"],
                "form": task["form"],
                "response_type": task["response_type"],
                "difficulty": task.get("difficulty", 0.5),
                "prompt_cn": task.get("prompt_cn"),
                "prompt_en": task.get("prompt_en"),
                "choices": task.get("choices"),
                "confidence_required": task.get("confidence_required", True),
                "allows_insufficient_information": task.get("allows_insufficient_information", False),
            }
        )
    return {
        "pack_id": engine.pack["id"],
        "pack_version": engine.pack["version"],
        "title": engine.pack["title"],
        "purpose": engine.pack["purpose"],
        "tasks": tasks,
        "claim_boundary": "The catalog exposes prompts and metadata only; private scoring keys remain server-side.",
    }


class UpliftHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], engine: UpliftEngine, token: str):
        if not token or len(token) < 16:
            raise ValueError("API bearer token must contain at least 16 characters")
        self.engine = engine
        self.token = token
        super().__init__(address, UpliftRequestHandler)


class UpliftRequestHandler(BaseHTTPRequestHandler):
    server: UpliftHTTPServer
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def _send(self, status: int, value: Any, content_type: str = "application/json; charset=utf-8") -> None:
        if isinstance(value, (dict, list)):
            body = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")
        elif isinstance(value, str):
            body = value.encode("utf-8")
        else:
            body = bytes(value)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return False
        return hmac.compare_digest(header[7:], self.server.token)

    def _require_auth(self) -> bool:
        if self._authorized():
            return True
        self._send(401, {"status": "ERROR", "message": "missing or invalid bearer token"})
        return False

    def _json_body(self) -> dict[str, Any]:
        content_type = self.headers.get("Content-Type", "")
        if "application/json" not in content_type:
            raise ValueError("Content-Type must be application/json")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("invalid Content-Length") from exc
        if length <= 0 or length > MAX_BODY_BYTES:
            raise ValueError(f"body size must be within 1..{MAX_BODY_BYTES} bytes")
        value = json.loads(self.rfile.read(length))
        if not isinstance(value, dict):
            raise ValueError("JSON body must be an object")
        return value

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/health":
            self._send(200, {"status": "PASS", "system": "DIKWP-MESH 5.4 Ω PARALLAX UPLIFT"})
            return
        if parsed.path in {"/", "/studio"}:
            self._send(200, STUDIO_HTML, "text/html; charset=utf-8")
            return
        if not self._require_auth():
            return
        query = urllib.parse.parse_qs(parsed.query)
        try:
            if parsed.path == "/v1/catalog":
                self._send(200, _public_catalog(self.server.engine, query.get("phase", [None])[0], query.get("form", [None])[0]))
            elif parsed.path == "/v1/status":
                self._send(200, self.server.engine.store.status())
            elif parsed.path == "/v1/verify":
                self._send(200, self.server.engine.verify())
            elif parsed.path == "/v1/profile":
                learner = query.get("learner_id", [None])[0]
                if not learner:
                    raise ValueError("learner_id is required")
                profile = self.server.engine.profile(learner)
                self._send(200 if profile else 404, profile or {"status": "NOT_FOUND", "message": "profile not found"})
            elif parsed.path == "/v1/plan":
                learner = query.get("learner_id", [None])[0]
                if not learner:
                    raise ValueError("learner_id is required")
                plan = self.server.engine.plan(learner)
                self._send(200 if plan else 404, plan or {"status": "NOT_FOUND", "message": "plan not found"})
            else:
                self._send(404, {"status": "NOT_FOUND"})
        except Exception as error:
            self._send(400, {"status": "ERROR", "error_type": type(error).__name__, "message": str(error)})

    def do_POST(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        if not self._require_auth():
            return
        try:
            body = self._json_body()
            if parsed.path == "/v1/sessions":
                result = self.server.engine.create_session(
                    body["learner_id"], body["covenant_id"], body["phase"], body["form"], body.get("task_ids"),
                    body.get("started_at"), int(body.get("duration_minutes", 90)), body.get("metadata"),
                )
            elif parsed.path == "/v1/responses":
                result = self.server.engine.submit(
                    body["session_id"], body["task_id"], body.get("answer"), body.get("confidence"), body["nonce"],
                    body.get("lease_id"), body.get("submitted_at"),
                )
            elif parsed.path == "/v1/reviews":
                result = self.server.engine.review_manual_response(
                    body["response_id"], body["reviewer_id"], body["reviewer_role"], float(body["score"]),
                    body.get("rubric_evidence", {}), body.get("created_at"),
                )
            elif parsed.path == "/v1/plans":
                result = self.server.engine.compile_plan(body["covenant_id"], body.get("issued_at"))
            elif parsed.path == "/v1/checkpoints":
                result = self.server.engine.store.create_checkpoint(body.get("created_at"))
            else:
                self._send(404, {"status": "NOT_FOUND"})
                return
            self._send(200, result)
        except KeyError as error:
            self._send(400, {"status": "ERROR", "error_type": "MissingField", "message": f"missing field {error.args[0]}"})
        except Exception as error:
            self._send(400, {"status": "ERROR", "error_type": type(error).__name__, "message": str(error)})


def serve(engine: UpliftEngine, host: str, port: int, token: str) -> None:
    server = UpliftHTTPServer((host, port), engine, token)
    try:
        print(json.dumps({"status": "SERVING", "url": f"http://{host}:{server.server_port}/studio", "token_hint": "read from configured file/environment"}, ensure_ascii=False))
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


def generate_token() -> str:
    return secrets.token_urlsafe(32)
