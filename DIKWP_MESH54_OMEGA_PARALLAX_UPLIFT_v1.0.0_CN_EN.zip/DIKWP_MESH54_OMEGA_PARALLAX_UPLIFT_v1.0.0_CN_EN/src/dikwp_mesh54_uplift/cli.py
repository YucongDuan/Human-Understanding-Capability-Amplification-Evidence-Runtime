from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from . import __version__
from .api import serve
from .artifacts import validate_artifacts
from .conformance import run_conformance
from .demo import run_demo
from .engine import UpliftEngine
from .resources import bundled_example_dir
from .pack import audit_knowledge_pack, load_knowledge_pack, load_scoring_key
from .signing import Ed25519Signer
from .store import UpliftStore


def _dump(value: Any, output: str | None = None) -> None:
    text = json.dumps(value, ensure_ascii=False, indent=2)
    if output:
        path = Path(output)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    print(text)


def _signer(args: argparse.Namespace) -> Ed25519Signer:
    if getattr(args, "private_key_file", None):
        value = Path(args.private_key_file).read_text(encoding="utf-8").strip()
        return Ed25519Signer.from_private_key_b64(value)
    if getattr(args, "seed_file", None):
        value = Path(args.seed_file).read_text(encoding="utf-8").strip()
        return Ed25519Signer.from_seed_text(value)
    env_seed = os.environ.get("UPLIFT54_SIGNING_SEED")
    if env_seed:
        return Ed25519Signer.from_seed_text(env_seed)
    if getattr(args, "seed", None):
        return Ed25519Signer.from_seed_text(args.seed)
    raise ValueError("provide --seed-file, --private-key-file, or UPLIFT54_SIGNING_SEED")


def _engine(args: argparse.Namespace) -> UpliftEngine:
    signer = _signer(args)
    store = UpliftStore(args.db, signer, node_id=getattr(args, "node_id", "UPLIFT54-LOCAL"))
    pack = load_knowledge_pack(args.pack)
    key = load_scoring_key(args.key, pack)
    return UpliftEngine(pack, key, store)


def _add_crypto(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--seed-file", help="UTF-8 file containing a local signing seed")
    parser.add_argument("--private-key-file", help="file containing a raw Ed25519 private key in base64")
    parser.add_argument("--seed", help="development-only seed; prefer --seed-file or environment")
    parser.add_argument("--node-id", default="UPLIFT54-LOCAL")


def _add_runtime(parser: argparse.ArgumentParser, require_key: bool = True) -> None:
    parser.add_argument("--db", required=True)
    parser.add_argument("--pack", required=True)
    if require_key:
        parser.add_argument("--key", required=True)
    _add_crypto(parser)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="uplift54",
        description="DIKWP-MESH 5.4 Ω PARALLAX UPLIFT: human-understanding evidence and training runtime",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    audit = sub.add_parser("audit-pack", help="validate a knowledge pack and audit representational closure")
    audit.add_argument("--pack", required=True)
    audit.add_argument("--out")

    demo = sub.add_parser("demo", help="run the deterministic four-phase synthetic lifecycle")
    demo.add_argument("--example-dir", help="defaults to bundled deterministic example")
    demo.add_argument("--out", default="outputs/demo")
    demo.add_argument("--seed", default="DIKWP-MESH54-UPLIFT-DEMO-KEY")

    conf = sub.add_parser("conformance", help="run self-contained conformance checks")
    conf.add_argument("--example-dir", help="defaults to bundled deterministic example")
    conf.add_argument("--out", default="outputs/conformance")

    artifacts = sub.add_parser("artifacts-validate", help="validate schemas and release samples")
    artifacts.add_argument("--root", default=".")
    artifacts.add_argument("--out", default="outputs/ARTIFACT_VALIDATION.json")

    register = sub.add_parser("register", help="register a pack and its private-key hash")
    _add_runtime(register)
    register.add_argument("--created-at")

    covenant = sub.add_parser("activate-covenant", help="activate a learner-controlled understanding covenant")
    _add_runtime(covenant)
    covenant.add_argument("--covenant", required=True)
    covenant.add_argument("--created-at")

    revoke = sub.add_parser("revoke-covenant", help="revoke a covenant and all active intervention leases")
    revoke.add_argument("--db", required=True)
    _add_crypto(revoke)
    revoke.add_argument("--covenant-id", required=True)
    revoke.add_argument("--reason", required=True)
    revoke.add_argument("--revoked-at")

    session = sub.add_parser("session", help="create a scoped assessment or training session")
    _add_runtime(session)
    session.add_argument("--learner-id", required=True)
    session.add_argument("--covenant-id", required=True)
    session.add_argument("--phase", required=True, choices=["baseline", "training", "transfer", "delayed"])
    session.add_argument("--form", required=True)
    session.add_argument("--task-id", action="append", dest="task_ids")
    session.add_argument("--started-at")
    session.add_argument("--duration-minutes", type=int, default=90)

    submit = sub.add_parser("submit", help="atomically submit, score, profile, and receipt one response")
    _add_runtime(submit)
    submit.add_argument("--session-id", required=True)
    submit.add_argument("--task-id", required=True)
    submit.add_argument("--answer-json", required=True, help="JSON value, e.g. '\"存量\"' or '[1,2]'")
    submit.add_argument("--confidence", type=float)
    submit.add_argument("--nonce", required=True)
    submit.add_argument("--lease-id")
    submit.add_argument("--submitted-at")

    review = sub.add_parser("review", help="append a signed manual-rubric attestation")
    _add_runtime(review)
    review.add_argument("--response-id", required=True)
    review.add_argument("--reviewer-id", required=True)
    review.add_argument("--reviewer-role", required=True)
    review.add_argument("--score", required=True, type=float)
    review.add_argument("--rubric-evidence-json", required=True)
    review.add_argument("--created-at")

    plan = sub.add_parser("plan", help="compile and atomically commit the next intervention plan and leases")
    _add_runtime(plan)
    plan.add_argument("--covenant-id", required=True)
    plan.add_argument("--issued-at")

    profile = sub.add_parser("profile", help="read the latest multidimensional evidence profile")
    _add_runtime(profile)
    profile.add_argument("--learner-id", required=True)

    verify = sub.add_parser("verify", help="verify the SQLite store, signatures, hashes, leases, and checkpoints")
    verify.add_argument("--db", required=True)
    _add_crypto(verify)

    checkpoint = sub.add_parser("checkpoint", help="create a signed Merkle transparency checkpoint")
    checkpoint.add_argument("--db", required=True)
    _add_crypto(checkpoint)
    checkpoint.add_argument("--created-at")

    status = sub.add_parser("status", help="show durable runtime counts and event head")
    status.add_argument("--db", required=True)
    _add_crypto(status)

    serve_parser = sub.add_parser("serve", help="serve the authenticated local learner studio and JSON API")
    _add_runtime(serve_parser)
    serve_parser.add_argument("--covenant", required=True)
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8765)
    serve_parser.add_argument("--token-file")
    serve_parser.add_argument("--token", help="development only; prefer --token-file or UPLIFT54_API_TOKEN")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "audit-pack":
            result = audit_knowledge_pack(load_knowledge_pack(args.pack))
            _dump(result, args.out)
            return 0 if result["status"] != "HOLD" else 2
        if args.command == "demo":
            result = run_demo(args.example_dir or str(bundled_example_dir()), args.out, seed_text=args.seed)
            _dump({"status": result["runtime_status"], "summary_hash": result["summary_hash"], "output": str(Path(args.out).resolve())})
            return 0 if result["runtime_status"] == "PASS" else 2
        if args.command == "conformance":
            result = run_conformance(args.example_dir or str(bundled_example_dir()), args.out)
            _dump(result)
            return 0 if result["status"] == "PASS" else 2
        if args.command == "artifacts-validate":
            result = validate_artifacts(args.root, args.out)
            _dump(result)
            return 0 if result["status"] == "PASS" else 2
        if args.command in {"verify", "checkpoint", "status", "revoke-covenant"}:
            store = UpliftStore(args.db, _signer(args), node_id=args.node_id)
            if args.command == "verify":
                result = store.verify()
            elif args.command == "checkpoint":
                result = store.create_checkpoint(args.created_at)
            elif args.command == "status":
                result = store.status()
            else:
                result = store.revoke_covenant(args.covenant_id, args.reason, args.revoked_at)
            _dump(result)
            return 0 if result.get("status", "PASS") != "FAIL" else 2

        engine = _engine(args)
        if args.command == "serve":
            engine.register_pack()
            covenant_payload = json.loads(Path(args.covenant).read_text(encoding="utf-8"))
            engine.activate_covenant(covenant_payload)
            token = (Path(args.token_file).read_text(encoding="utf-8").strip() if args.token_file else None) or os.environ.get("UPLIFT54_API_TOKEN") or args.token
            if not token:
                raise ValueError("provide --token-file or UPLIFT54_API_TOKEN")
            serve(engine, args.host, args.port, token)
            return 0
        if args.command == "register":
            result = engine.register_pack(args.created_at)
        elif args.command == "activate-covenant":
            covenant = json.loads(Path(args.covenant).read_text(encoding="utf-8"))
            result = engine.activate_covenant(covenant, args.created_at)
        elif args.command == "session":
            result = engine.create_session(
                args.learner_id, args.covenant_id, args.phase, args.form, args.task_ids,
                args.started_at, args.duration_minutes,
            )
        elif args.command == "submit":
            result = engine.submit(
                args.session_id, args.task_id, json.loads(args.answer_json), args.confidence,
                args.nonce, args.lease_id, args.submitted_at,
            )
        elif args.command == "review":
            result = engine.review_manual_response(
                args.response_id, args.reviewer_id, args.reviewer_role, args.score,
                json.loads(args.rubric_evidence_json), args.created_at,
            )
        elif args.command == "plan":
            result = engine.compile_plan(args.covenant_id, args.issued_at)
        elif args.command == "profile":
            result = engine.profile(args.learner_id)
            if result is None:
                raise ValueError("no profile found")
        else:  # pragma: no cover
            parser.error(f"unsupported command {args.command}")
            return 2
        _dump(result)
        return 0
    except (ValueError, RuntimeError, json.JSONDecodeError, OSError) as error:
        print(json.dumps({"status": "ERROR", "error_type": type(error).__name__, "message": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
