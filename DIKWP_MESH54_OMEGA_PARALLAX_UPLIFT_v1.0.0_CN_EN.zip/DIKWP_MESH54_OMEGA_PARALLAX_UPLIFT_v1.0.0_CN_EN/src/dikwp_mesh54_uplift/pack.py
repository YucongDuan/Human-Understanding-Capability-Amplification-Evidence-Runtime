from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

import networkx as nx

from .canonical import bounded, object_hash
from .models import DIKWP_LAYERS, PHASES, RESPONSE_TYPES, UNDERSTANDING_DIMENSIONS


class PackValidationError(ValueError):
    pass


def load_json(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_knowledge_pack(path: str | Path) -> dict[str, Any]:
    pack = load_json(path)
    validate_pack(pack)
    return pack


def load_scoring_key(path: str | Path, pack: dict[str, Any] | None = None) -> dict[str, Any]:
    key = load_json(path)
    validate_scoring_key(key, pack)
    return key


def _require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def validate_pack(pack: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    _require(isinstance(pack, dict), "pack must be an object", errors)
    for field in ("id", "title", "version", "purpose", "concepts", "relations", "tasks", "sources"):
        _require(field in pack, f"missing required field: {field}", errors)
    if errors:
        raise PackValidationError("; ".join(errors))

    concepts = pack.get("concepts", [])
    tasks = pack.get("tasks", [])
    sources = pack.get("sources", [])
    relations = pack.get("relations", [])
    _require(isinstance(concepts, list) and concepts, "concepts must be a non-empty array", errors)
    _require(isinstance(tasks, list) and tasks, "tasks must be a non-empty array", errors)
    _require(isinstance(sources, list) and sources, "sources must be a non-empty array", errors)
    _require(isinstance(relations, list), "relations must be an array", errors)

    concept_ids = [str(c.get("id", "")) for c in concepts]
    task_ids = [str(t.get("id", "")) for t in tasks]
    source_ids = [str(s.get("id", "")) for s in sources]
    _require(all(concept_ids), "every concept requires an id", errors)
    _require(all(task_ids), "every task requires an id", errors)
    _require(all(source_ids), "every source requires an id", errors)
    _require(len(concept_ids) == len(set(concept_ids)), "concept ids must be unique", errors)
    _require(len(task_ids) == len(set(task_ids)), "task ids must be unique", errors)
    _require(len(source_ids) == len(set(source_ids)), "source ids must be unique", errors)
    cset, sset = set(concept_ids), set(source_ids)

    for c in concepts:
        cid = c.get("id", "<unknown>")
        _require(c.get("dikwp_layer") in DIKWP_LAYERS, f"concept {cid}: invalid dikwp_layer", errors)
        for p in c.get("prerequisites", []):
            _require(p in cset, f"concept {cid}: unknown prerequisite {p}", errors)
        for sid in c.get("source_ids", []):
            _require(sid in sset, f"concept {cid}: unknown source {sid}", errors)

    for r in relations:
        rid = r.get("id", "<unknown>")
        _require(r.get("source") in cset, f"relation {rid}: unknown source concept", errors)
        _require(r.get("target") in cset, f"relation {rid}: unknown target concept", errors)
        _require(bool(r.get("relation")), f"relation {rid}: missing relation label", errors)

    for t in tasks:
        tid = t.get("id", "<unknown>")
        _require(t.get("dimension") in UNDERSTANDING_DIMENSIONS, f"task {tid}: invalid dimension", errors)
        _require(t.get("dikwp_layer") in DIKWP_LAYERS, f"task {tid}: invalid dikwp_layer", errors)
        _require(t.get("phase") in PHASES, f"task {tid}: invalid phase", errors)
        _require(t.get("response_type") in RESPONSE_TYPES, f"task {tid}: invalid response_type", errors)
        _require(0 <= float(t.get("difficulty", 0.5)) <= 1, f"task {tid}: difficulty outside [0,1]", errors)
        _require(bool(t.get("form")), f"task {tid}: missing form", errors)
        _require(bool(t.get("prompt_cn") or t.get("prompt_en")), f"task {tid}: missing prompt", errors)
        refs = t.get("concept_ids", [])
        _require(isinstance(refs, list) and refs, f"task {tid}: concept_ids must be non-empty", errors)
        for cid in refs:
            _require(cid in cset, f"task {tid}: unknown concept {cid}", errors)
        for sid in t.get("source_ids", []):
            _require(sid in sset, f"task {tid}: unknown source {sid}", errors)
        conf_required = t.get("confidence_required", True)
        _require(isinstance(conf_required, bool), f"task {tid}: confidence_required must be boolean", errors)

    # Graph-level authoring checks.
    graph = nx.DiGraph()
    graph.add_nodes_from(cset)
    for rel in relations:
        graph.add_edge(rel.get("source"), rel.get("target"))
    cycles = list(nx.simple_cycles(graph))
    prereq_graph = nx.DiGraph()
    prereq_graph.add_nodes_from(cset)
    for c in concepts:
        for prerequisite in c.get("prerequisites", []):
            prereq_graph.add_edge(prerequisite, c["id"])
    _require(nx.is_directed_acyclic_graph(prereq_graph), "concept prerequisite graph must be acyclic", errors)

    if errors:
        raise PackValidationError("; ".join(errors))

    return {
        "status": "PASS",
        "pack_id": pack["id"],
        "pack_hash": object_hash(pack),
        "counts": {
            "concepts": len(concepts),
            "relations": len(relations),
            "tasks": len(tasks),
            "sources": len(sources),
            "concept_cycles": len(cycles),
        },
    }


def validate_scoring_key(key: dict[str, Any], pack: dict[str, Any] | None = None) -> dict[str, Any]:
    errors: list[str] = []
    for field in ("pack_id", "pack_version", "answers"):
        _require(field in key, f"scoring key missing {field}", errors)
    answers = key.get("answers", {})
    _require(isinstance(answers, dict) and answers, "answers must be a non-empty object", errors)
    if pack is not None:
        _require(key.get("pack_id") == pack.get("id"), "scoring key pack_id mismatch", errors)
        _require(str(key.get("pack_version")) == str(pack.get("version")), "scoring key version mismatch", errors)
        task_ids = {t["id"] for t in pack.get("tasks", [])}
        missing = task_ids - set(answers)
        extra = set(answers) - task_ids
        _require(not missing, f"scoring key missing tasks: {sorted(missing)}", errors)
        _require(not extra, f"scoring key has unknown tasks: {sorted(extra)}", errors)
        for task in pack.get("tasks", []):
            entry = answers.get(task["id"], {})
            _require(entry.get("response_type") == task.get("response_type"), f"task {task['id']}: response type mismatch in key", errors)
    if errors:
        raise PackValidationError("; ".join(errors))
    return {
        "status": "PASS",
        "key_hash": object_hash(key),
        "answer_count": len(answers),
    }


def _normalized_entropy(values: list[str]) -> float:
    if not values:
        return 0.0
    counts = Counter(values)
    if len(counts) == 1:
        return 0.0
    total = sum(counts.values())
    import math

    entropy = -sum((count / total) * math.log(count / total) for count in counts.values())
    return entropy / math.log(len(counts))


def _hhi(values: list[str]) -> float:
    if not values:
        return 1.0
    counts = Counter(values)
    total = sum(counts.values())
    return sum((count / total) ** 2 for count in counts.values())


def audit_knowledge_pack(pack: dict[str, Any]) -> dict[str, Any]:
    """PARALLAX-derived curriculum closure audit.

    This audits the *training representation*, not a learner's worth or intelligence.
    """
    validate_pack(pack)
    tasks = pack["tasks"]
    concepts = pack["concepts"]
    sources = pack["sources"]

    charts = [str(t.get("chart", "default")) for t in tasks]
    scales = [str(t.get("scale", "meso")) for t in tasks]
    modalities = [str(t.get("modality", "symbolic")) for t in tasks]
    source_refs = [sid for t in tasks for sid in t.get("source_ids", [])]
    dimensions = [t["dimension"] for t in tasks]
    phases = [t["phase"] for t in tasks]

    observer_monopoly = _hhi(charts)
    source_monopoly = _hhi(source_refs) if source_refs else 1.0
    scale_lock = 1.0 - _normalized_entropy(scales)
    modality_lock = 1.0 - _normalized_entropy(modalities)
    dimension_lock = 1.0 - _normalized_entropy(dimensions)

    transfer_coverage = sum(1 for p in phases if p == "transfer") / len(tasks)
    delayed_coverage = sum(1 for p in phases if p == "delayed") / len(tasks)
    counterexample_coverage = sum(
        1 for t in tasks if t["dimension"] in {"boundary", "counterfactual"} or "counterexample_hunt" in t.get("intervention_tags", [])
    ) / len(tasks)
    residual_coverage = sum(
        1 for t in tasks if t["dimension"] == "residual" or t.get("allows_insufficient_information", False)
    ) / len(tasks)
    purpose_coverage = sum(1 for t in tasks if t["dimension"] == "purpose" or t["dikwp_layer"] == "P") / len(tasks)
    protected_count = len(pack.get("protected_relations", []))
    unknown_count = len(pack.get("unknowns", []))
    source_diversity = 1.0 - source_monopoly

    seal_strength = bounded(
        0.18 * observer_monopoly
        + 0.16 * source_monopoly
        + 0.13 * scale_lock
        + 0.13 * modality_lock
        + 0.10 * dimension_lock
        + 0.12 * (1.0 - min(1.0, transfer_coverage * 4))
        + 0.10 * (1.0 - min(1.0, counterexample_coverage * 4))
        + 0.08 * (1.0 - min(1.0, residual_coverage * 6))
    )
    capture_risk = bounded(
        0.34 * observer_monopoly
        + 0.30 * source_monopoly
        + 0.16 * dimension_lock
        + 0.10 * (1.0 - min(1.0, protected_count / 3))
        + 0.10 * (1.0 - min(1.0, purpose_coverage * 5))
    )
    generative_openness = bounded(
        0.22 * (1.0 - observer_monopoly)
        + 0.18 * source_diversity
        + 0.14 * (1.0 - scale_lock)
        + 0.14 * (1.0 - modality_lock)
        + 0.14 * min(1.0, transfer_coverage * 4)
        + 0.10 * min(1.0, counterexample_coverage * 4)
        + 0.08 * min(1.0, (residual_coverage * 5 + unknown_count / 4))
    )

    obligations: list[str] = []
    if len(sources) < 2 or source_diversity < 0.35:
        obligations.append("add_independent_sources")
    if transfer_coverage < 0.10:
        obligations.append("add_holdout_transfer_items")
    if delayed_coverage < 0.05:
        obligations.append("add_delayed_retention_form")
    if counterexample_coverage < 0.10:
        obligations.append("add_counterexamples_and_boundary_tests")
    if residual_coverage < 0.05:
        obligations.append("add_unknown_or_insufficient_information_items")
    if len(set(dimensions)) < 7:
        obligations.append("expand_understanding_dimensions")
    if len(set(charts)) < 2:
        obligations.append("add_observer_charts")
    if len(set(scales)) < 2:
        obligations.append("add_scale_variation")
    if len(set(modalities)) < 2:
        obligations.append("add_modality_variation")

    if seal_strength > 0.66 or capture_risk > 0.68:
        status = "HOLD"
    elif obligations:
        status = "REVIEW"
    else:
        status = "ACTIVE"

    report = {
        "object_type": "CurriculumClosureAudit54",
        "pack_id": pack["id"],
        "pack_hash": object_hash(pack),
        "status": status,
        "closure_profile": {
            "seal_strength": round(seal_strength, 4),
            "capture_risk": round(capture_risk, 4),
            "generative_openness": round(generative_openness, 4),
        },
        "diagnostics": {
            "observer_monopoly": round(observer_monopoly, 4),
            "source_monopoly": round(source_monopoly, 4),
            "scale_lock": round(scale_lock, 4),
            "modality_lock": round(modality_lock, 4),
            "dimension_lock": round(dimension_lock, 4),
            "transfer_coverage": round(transfer_coverage, 4),
            "delayed_coverage": round(delayed_coverage, 4),
            "counterexample_coverage": round(counterexample_coverage, 4),
            "residual_coverage": round(residual_coverage, 4),
            "purpose_coverage": round(purpose_coverage, 4),
        },
        "open_obligations": obligations,
        "interpretation": "This audit evaluates representational closure of the curriculum, not the learner's intelligence or value.",
    }
    report["audit_hash"] = object_hash(report)
    return report
