from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .canonical import canonical_bytes, sha256_hex


@dataclass(frozen=True)
class SignatureEnvelope:
    algorithm: str
    key_id: str
    public_key_b64: str
    signature_b64: str

    def to_dict(self) -> dict[str, str]:
        return {
            "algorithm": self.algorithm,
            "key_id": self.key_id,
            "public_key_b64": self.public_key_b64,
            "signature_b64": self.signature_b64,
        }


class Ed25519Signer:
    """Small local signer. Seed handling is deliberately explicit and auditable."""

    algorithm = "Ed25519"

    def __init__(self, private_key: Ed25519PrivateKey):
        self._private_key = private_key
        self._public_key = private_key.public_key()
        public_raw = self._public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        self.public_key_b64 = base64.b64encode(public_raw).decode("ascii")
        self.key_id = f"ed25519:{sha256_hex(public_raw)[:24]}"

    @classmethod
    def from_seed_text(cls, seed: str) -> "Ed25519Signer":
        raw = hashlib.sha256(seed.encode("utf-8")).digest()
        return cls(Ed25519PrivateKey.from_private_bytes(raw))

    @classmethod
    def generate(cls) -> "Ed25519Signer":
        return cls(Ed25519PrivateKey.generate())

    def private_key_b64(self) -> str:
        raw = self._private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        return base64.b64encode(raw).decode("ascii")

    @classmethod
    def from_private_key_b64(cls, value: str) -> "Ed25519Signer":
        raw = base64.b64decode(value)
        if len(raw) != 32:
            raise ValueError("Ed25519 private key must be exactly 32 bytes")
        return cls(Ed25519PrivateKey.from_private_bytes(raw))

    def sign_object(self, value: Any) -> SignatureEnvelope:
        signature = self._private_key.sign(canonical_bytes(value))
        return SignatureEnvelope(
            algorithm=self.algorithm,
            key_id=self.key_id,
            public_key_b64=self.public_key_b64,
            signature_b64=base64.b64encode(signature).decode("ascii"),
        )


def verify_object_signature(value: Any, envelope: dict[str, str] | SignatureEnvelope) -> bool:
    if isinstance(envelope, SignatureEnvelope):
        envelope = envelope.to_dict()
    if envelope.get("algorithm") != "Ed25519":
        return False
    try:
        public = Ed25519PublicKey.from_public_bytes(base64.b64decode(envelope["public_key_b64"]))
        public.verify(base64.b64decode(envelope["signature_b64"]), canonical_bytes(value))
        expected_key_id = f"ed25519:{sha256_hex(base64.b64decode(envelope['public_key_b64']))[:24]}"
        return envelope.get("key_id") == expected_key_id
    except (InvalidSignature, ValueError, KeyError):
        return False
