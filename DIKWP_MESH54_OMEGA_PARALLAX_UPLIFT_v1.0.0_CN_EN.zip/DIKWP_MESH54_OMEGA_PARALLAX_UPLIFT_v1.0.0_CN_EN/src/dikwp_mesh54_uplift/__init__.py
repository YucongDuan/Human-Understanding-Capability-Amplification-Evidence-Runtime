"""DIKWP-MESH 5.4 Ω PARALLAX UPLIFT."""

__version__ = "1.0.0"
EVIDENCE_GRADE = "E2-author-side-deterministic-reference"
SYSTEM_NAME = "DIKWP-MESH 5.4 Ω PARALLAX UPLIFT"

from .engine import UpliftEngine
from .pack import load_knowledge_pack, load_scoring_key, validate_pack
from .profile import build_understanding_profile
from .scheduler import compile_intervention_plan
from .store import UpliftStore

__all__ = [
    "UpliftEngine",
    "UpliftStore",
    "load_knowledge_pack",
    "load_scoring_key",
    "validate_pack",
    "build_understanding_profile",
    "compile_intervention_plan",
]
