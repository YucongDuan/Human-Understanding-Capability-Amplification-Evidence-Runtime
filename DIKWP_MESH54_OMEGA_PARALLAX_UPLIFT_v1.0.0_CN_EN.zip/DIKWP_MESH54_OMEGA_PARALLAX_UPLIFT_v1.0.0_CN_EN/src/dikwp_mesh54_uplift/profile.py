from __future__ import annotations

import math
from collections import defaultdict
from statistics import mean
from typing import Any

from .canonical import bounded, object_hash
from .models import UNDERSTANDING_DIMENSIONS


def _safe_mean(values: list[float]) -> float | None:
    return mean(values) if values else None


def _wilson(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float | None, float | None]:
    if n <= 0:
        return None, None
    phat = successes / n
    denom = 1 + (z * z) / n
    center = (phat + (z * z) / (2 * n)) / denom
    margin = z * math.sqrt((phat * (1 - phat) + (z * z) / (4 * n)) / n) / denom
    return bounded(center - margin), bounded(center + margin)


def _evidence_state(entries: list[dict[str, Any]]) -> str:
    scored = [e for e in entries if e.get("score") is not None]
    if not scored:
        return "UNOBSERVED"
    delayed = [e for e in scored if e.get("phase") == "delayed"]
    transfer = [e for e in scored if e.get("phase") == "transfer"]
    all_scores = [float(e["score"]) for e in scored]
    if delayed and mean(float(e["score"]) for e in delayed) >= 0.75:
        return "RETENTION_SUPPORTED"
    if transfer and mean(float(e["score"]) for e in transfer) >= 0.75:
        return "TRANSFER_SUPPORTED"
    if len(scored) >= 2 and mean(all_scores) >= 0.65:
        return "PROVISIONAL"
    return "EMERGING"


def _phase_summary(entries: list[dict[str, Any]], phase: str) -> dict[str, Any]:
    selected = [e for e in entries if e.get("phase") == phase and e.get("score") is not None]
    scores = [float(e["score"]) for e in selected]
    return {
        "n": len(scores),
        "mean_score": round(mean(scores), 4) if scores else None,
        "fully_supported": sum(1 for s in scores if s >= 0.8),
    }


def build_understanding_profile(
    pack: dict[str, Any],
    receipts: list[dict[str, Any]],
    learner_id: str,
    as_of: str,
) -> dict[str, Any]:
    task_by_id = {task["id"]: task for task in pack["tasks"]}
    evidence: list[dict[str, Any]] = []
    for receipt in receipts:
        task = task_by_id.get(receipt.get("task_id"))
        if task is None:
            continue
        score = receipt.get("score")
        confidence = receipt.get("confidence")
        evidence.append(
            {
                "task_id": task["id"],
                "dimension": task["dimension"],
                "dikwp_layer": task["dikwp_layer"],
                "phase": task["phase"],
                "form": task["form"],
                "chart": task.get("chart", "default"),
                "scale": task.get("scale", "meso"),
                "modality": task.get("modality", "symbolic"),
                "difficulty": float(task.get("difficulty", 0.5)),
                "score": score,
                "confidence": confidence,
                "submitted_at": receipt.get("submitted_at"),
                "status": receipt.get("status", "UNKNOWN"),
                "allows_insufficient_information": bool(task.get("allows_insufficient_information", False)),
            }
        )

    by_dimension: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_layer: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in evidence:
        by_dimension[item["dimension"]].append(item)
        by_layer[item["dikwp_layer"]].append(item)

    dimensions: dict[str, Any] = {}
    for dimension in UNDERSTANDING_DIMENSIONS:
        entries = by_dimension.get(dimension, [])
        scored = [e for e in entries if e.get("score") is not None]
        scores = [float(e["score"]) for e in scored]
        confidences = [float(e["confidence"]) for e in scored if e.get("confidence") is not None]
        paired = [
            (float(e["score"]), float(e["confidence"]))
            for e in scored
            if e.get("confidence") is not None
        ]
        successes = sum(1 for s in scores if s >= 0.8)
        low, high = _wilson(successes, len(scores))
        briers = [(confidence - score) ** 2 for score, confidence in paired]
        signed_gaps = [confidence - score for score, confidence in paired]
        transfer_scores = [float(e["score"]) for e in scored if e["phase"] == "transfer"]
        delayed_scores = [float(e["score"]) for e in scored if e["phase"] == "delayed"]
        dimensions[dimension] = {
            "evidence_state": _evidence_state(entries),
            "n_scored": len(scores),
            "mean_score": round(mean(scores), 4) if scores else None,
            "transfer_score": round(mean(transfer_scores), 4) if transfer_scores else None,
            "delayed_score": round(mean(delayed_scores), 4) if delayed_scores else None,
            "mean_confidence": round(mean(confidences), 4) if confidences else None,
            "brier": round(mean(briers), 4) if briers else None,
            "signed_calibration_gap": round(mean(signed_gaps), 4) if signed_gaps else None,
            "success_wilson_95": [round(low, 4), round(high, 4)] if low is not None else [None, None],
            "phases": {phase: _phase_summary(entries, phase) for phase in ("baseline", "training", "transfer", "delayed")},
        }

    layers: dict[str, Any] = {}
    for layer in ("D", "I", "K", "W", "P"):
        entries = [e for e in by_layer.get(layer, []) if e.get("score") is not None]
        scores = [float(e["score"]) for e in entries]
        holdout = [float(e["score"]) for e in entries if e["phase"] in {"transfer", "delayed"}]
        layers[layer] = {
            "n_scored": len(scores),
            "mean_score": round(mean(scores), 4) if scores else None,
            "holdout_score": round(mean(holdout), 4) if holdout else None,
        }

    all_scored = [e for e in evidence if e.get("score") is not None]
    paired = [
        (float(e["score"]), float(e["confidence"]))
        for e in all_scored
        if e.get("confidence") is not None
    ]
    global_brier = mean((c - s) ** 2 for s, c in paired) if paired else None
    global_signed_gap = mean(c - s for s, c in paired) if paired else None

    verified_dimensions = [
        name for name, value in dimensions.items() if value["evidence_state"] in {"TRANSFER_SUPPORTED", "RETENTION_SUPPORTED"}
    ]
    observed_scores = [value["mean_score"] for value in dimensions.values() if value["mean_score"] is not None]
    bottleneck_floor = min(observed_scores) if observed_scores else None

    profile = {
        "object_type": "UnderstandingProfile54",
        "learner_id": learner_id,
        "pack_id": pack["id"],
        "pack_version": pack["version"],
        "pack_hash": object_hash(pack),
        "as_of": as_of,
        "dimensions": dimensions,
        "dikwp_layers": layers,
        "metacognition": {
            "paired_observations": len(paired),
            "global_brier": round(global_brier, 4) if global_brier is not None else None,
            "global_signed_gap": round(global_signed_gap, 4) if global_signed_gap is not None else None,
            "overconfidence_risk": round(max(0.0, global_signed_gap), 4) if global_signed_gap is not None else None,
            "underconfidence_risk": round(max(0.0, -global_signed_gap), 4) if global_signed_gap is not None else None,
        },
        "evidence_frontier": {
            "verified_dimensions": verified_dimensions,
            "verified_count": len(verified_dimensions),
            "observed_dimension_count": len(observed_scores),
            "bottleneck_floor": round(bottleneck_floor, 4) if bottleneck_floor is not None else None,
            "retention_claim_allowed": any(v["evidence_state"] == "RETENTION_SUPPORTED" for v in dimensions.values()),
        },
        "open_obligations": [],
        "interpretation": (
            "This is a multidimensional evidence profile. It is not an intelligence quotient, personality diagnosis, "
            "or final judgment of the learner. Training-item performance alone does not verify transfer."
        ),
    }

    if not any(e["phase"] == "transfer" for e in all_scored):
        profile["open_obligations"].append("run_holdout_transfer_form")
    if not any(e["phase"] == "delayed" for e in all_scored):
        profile["open_obligations"].append("run_delayed_retention_form")
    if len(paired) < 5:
        profile["open_obligations"].append("collect_more_confidence_predictions")
    if any(v["n_scored"] == 0 for v in dimensions.values()):
        profile["open_obligations"].append("increase_dimension_coverage")

    profile["profile_hash"] = object_hash(profile)
    return profile


def learner_closure_diagnostics(pack: dict[str, Any], receipts: list[dict[str, Any]]) -> dict[str, Any]:
    task_by_id = {task["id"]: task for task in pack["tasks"]}
    rows = []
    for r in receipts:
        task = task_by_id.get(r.get("task_id"))
        if task and r.get("score") is not None:
            rows.append((task, float(r["score"]), r.get("confidence")))

    def avg(where) -> float | None:
        values = [score for task, score, _ in rows if where(task)]
        return mean(values) if values else None

    training = avg(lambda t: t["phase"] == "training")
    transfer = avg(lambda t: t["phase"] == "transfer")
    example_lock = bounded((training or 0.0) - (transfer or 0.0)) if training is not None and transfer is not None else None

    paired = [(score, float(conf)) for _, score, conf in rows if conf is not None]
    overconfidence = bounded(mean(conf - score for score, conf in paired)) if paired else None

    charts: dict[str, list[float]] = defaultdict(list)
    scales: dict[str, list[float]] = defaultdict(list)
    modalities: dict[str, list[float]] = defaultdict(list)
    for task, score, _ in rows:
        charts[str(task.get("chart", "default"))].append(score)
        scales[str(task.get("scale", "meso"))].append(score)
        modalities[str(task.get("modality", "symbolic"))].append(score)

    def performance_lock(groups: dict[str, list[float]]) -> float | None:
        means = [mean(v) for v in groups.values() if v]
        if len(means) < 2:
            return None
        return bounded(max(means) - min(means))

    residual_score = avg(lambda t: t["dimension"] == "residual" or t.get("allows_insufficient_information", False))
    revision_score = avg(lambda t: t["dimension"] == "revision")
    purpose_score = avg(lambda t: t["dimension"] == "purpose")
    mechanism = avg(lambda t: t["dimension"] == "mechanism")
    reconstruction = avg(lambda t: t["dimension"] == "reconstruction")

    diagnostics = {
        "object_type": "LearnerClosureDiagnostics54",
        "pack_id": pack["id"],
        "observed_response_count": len(rows),
        "example_lock": round(example_lock, 4) if example_lock is not None else None,
        "confidence_lock": round(overconfidence, 4) if overconfidence is not None else None,
        "observer_chart_lock": round(performance_lock(charts), 4) if performance_lock(charts) is not None else None,
        "scale_lock": round(performance_lock(scales), 4) if performance_lock(scales) is not None else None,
        "modality_lock": round(performance_lock(modalities), 4) if performance_lock(modalities) is not None else None,
        "unknown_suppression": round(1.0 - residual_score, 4) if residual_score is not None else None,
        "revision_lock": round(1.0 - revision_score, 4) if revision_score is not None else None,
        "purpose_lock": round(1.0 - purpose_score, 4) if purpose_score is not None else None,
        "verbal_shell_risk": (
            round(bounded((reconstruction or 0.0) - (mechanism or 0.0)), 4)
            if reconstruction is not None and mechanism is not None
            else None
        ),
        "interpretation": (
            "These diagnostics describe observed task-performance patterns only. They do not infer identity, mental health, "
            "motivation, or stable cognitive traits."
        ),
    }
    diagnostics["diagnostic_hash"] = object_hash(diagnostics)
    return diagnostics
