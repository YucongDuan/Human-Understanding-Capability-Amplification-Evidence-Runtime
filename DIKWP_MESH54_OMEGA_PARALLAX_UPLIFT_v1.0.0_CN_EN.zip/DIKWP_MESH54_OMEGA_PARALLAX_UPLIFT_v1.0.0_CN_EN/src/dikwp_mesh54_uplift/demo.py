from __future__ import annotations

import copy
import json
import shutil
import sqlite3
from pathlib import Path
from typing import Any

from .canonical import object_hash, parse_utc
from .engine import UpliftEngine
from .pack import audit_knowledge_pack, load_knowledge_pack, load_scoring_key
from .reports import build_dashboard
from .signing import Ed25519Signer
from .store import NonceConflict, UpliftStore


MANUAL_RESPONSES: dict[str, tuple[str, float, float, dict[str, Any]]] = {
    "B10": (
        "反馈回路是变量之间首尾相连的影响链；环路会使变化自我增强或受到抵消。例：工作负荷增加错误，错误增加返工，返工又增加工作负荷。",
        0.90,
        0.35,
        {"mechanism_named": True, "causal_chain_complete": False, "boundary_acknowledged": False, "review_mode": "synthetic-demo"},
    ),
    "T10": (
        "我会先区分存量与流量，再画出影响方向与时滞；随后改变一条边做反事实，检查系统边界外的代价，并把不能识别的部分保留为残差。",
        0.76,
        0.84,
        {"mechanism_named": True, "counterfactual_used": True, "residual_preserved": True, "review_mode": "synthetic-demo"},
    ),
    "X10": (
        "在医院床位例中，缩短住院日可能改善表面周转，却把照护负担转移给家庭并提高再入院。可迁移的骨架是：代理指标被目标化—边界外代价上升—延迟反馈被忽略。",
        0.72,
        0.88,
        {"new_domain": True, "structural_analogy": True, "boundary_cost": True, "review_mode": "synthetic-demo"},
    ),
    "D06": (
        "一个月后仍可重建：先辨别存量/流量，再闭合反馈环；用反事实和留出情境检验机制；若观测不足就保留未知，不把代理指标当真实目的。",
        0.69,
        0.82,
        {"delayed_reconstruction": True, "mechanism": True, "uncertainty_acknowledged": True, "review_mode": "synthetic-demo"},
    ),
}


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _iso_add_minutes(timestamp: str, minutes: int) -> str:
    from datetime import timedelta

    return (parse_utc(timestamp) + timedelta(minutes=minutes)).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _lease_for_task(plan: dict[str, Any] | None, task_id: str) -> str | None:
    if not plan:
        return None
    candidates = [lease for lease in plan.get("leases", []) if task_id in lease.get("task_ids", [])]
    candidates.sort(key=lambda lease: (lease.get("intervention", ""), lease.get("lease_id", "")))
    return candidates[0]["lease_id"] if candidates else None


def _response_map(rows: list[list[Any]]) -> dict[str, tuple[Any, float]]:
    return {str(task_id): (answer, float(confidence)) for task_id, answer, confidence in rows}


def _run_phase(
    engine: UpliftEngine,
    covenant: dict[str, Any],
    phase: str,
    form: str,
    task_ids: list[str],
    responses: dict[str, tuple[Any, float]],
    started_at: str,
    plan: dict[str, Any] | None,
    reviewer_id: str = "synthetic-independent-rubric-node",
) -> dict[str, Any]:
    session_result = engine.create_session(
        learner_id=covenant["learner_id"],
        covenant_id=covenant["covenant_id"],
        phase=phase,
        form=form,
        task_ids=task_ids,
        started_at=started_at,
        duration_minutes=180,
        metadata={"demo": True, "synthetic_learner": True, "plan_id": plan.get("plan_id") if plan else None},
    )
    session = session_result["session"]
    receipts: list[dict[str, Any]] = []
    reviews: list[dict[str, Any]] = []
    for index, task_id in enumerate(task_ids, start=1):
        when = _iso_add_minutes(started_at, index)
        lease_id = _lease_for_task(plan, task_id)
        if task_id in responses:
            answer, confidence = responses[task_id]
            manual_review = None
        elif task_id in MANUAL_RESPONSES:
            answer, confidence, review_score, rubric = MANUAL_RESPONSES[task_id]
            manual_review = (review_score, rubric)
        else:
            continue
        receipt = engine.submit(
            session_id=session["session_id"],
            task_id=task_id,
            answer=answer,
            confidence=confidence,
            nonce=f"demo-{phase.lower()}-{task_id.lower()}-v1",
            lease_id=lease_id,
            submitted_at=when,
        )
        receipts.append(receipt)
        if manual_review is not None:
            review_score, rubric = manual_review
            review = engine.review_manual_response(
                response_id=receipt["receipt"]["response_id"],
                reviewer_id=reviewer_id,
                reviewer_role="rubric-reviewer-synthetic-demo",
                score=review_score,
                rubric_evidence=rubric,
                created_at=_iso_add_minutes(when, 1),
            )
            reviews.append(review)
    return {"session": session, "receipts": receipts, "reviews": reviews}


def run_demo(example_dir: str | Path, output_dir: str | Path, seed_text: str = "DIKWP-MESH54-UPLIFT-DEMO-KEY") -> dict[str, Any]:
    """Run a deterministic synthetic lifecycle.

    This proves software and evidence mechanics only. It does not prove that a real
    person improved, because all answers and rubric attestations are synthetic fixtures.
    """
    example_dir = Path(example_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    database = output_dir / "uplift_demo.sqlite"
    if database.exists():
        database.unlink()

    pack = load_knowledge_pack(example_dir / "knowledge_pack.json")
    key = load_scoring_key(example_dir / "scoring_key.private.json", pack)
    covenant = json.loads((example_dir / "understanding_covenant.json").read_text(encoding="utf-8"))
    response_fixture = json.loads((example_dir / "demo_responses.json").read_text(encoding="utf-8"))
    response_maps = {phase: _response_map(rows) for phase, rows in response_fixture.items()}

    signer = Ed25519Signer.from_seed_text(seed_text)
    store = UpliftStore(database, signer, node_id="UPLIFT-DEMO-NODE-01")
    engine = UpliftEngine(pack, key, store)
    audit = audit_knowledge_pack(pack)
    registration = engine.register_pack(created_at="2026-07-24T16:00:00Z")
    covenant_result = engine.activate_covenant(covenant, created_at="2026-07-24T16:01:00Z")

    baseline_tasks = [task["id"] for task in pack["tasks"] if task["phase"] == "baseline" and task["form"] == "A"]
    baseline_run = _run_phase(
        engine, covenant, "baseline", "A", baseline_tasks, response_maps["baseline"], "2026-07-24T16:10:00Z", None
    )

    # Exact replay returns the same signed receipt and does not consume state twice.
    first_receipt = baseline_run["receipts"][0]
    first_task = first_receipt["receipt"]["task_id"]
    first_answer, first_confidence = response_maps["baseline"][first_task]
    replay = engine.submit(
        session_id=baseline_run["session"]["session_id"],
        task_id=first_task,
        answer=first_answer,
        confidence=first_confidence,
        nonce=f"demo-baseline-{first_task.lower()}-v1",
        submitted_at="2026-07-24T16:11:00Z",
    )
    try:
        engine.submit(
            session_id=baseline_run["session"]["session_id"],
            task_id=first_task,
            answer="conflicting-answer",
            confidence=first_confidence,
            nonce=f"demo-baseline-{first_task.lower()}-v1",
            submitted_at="2026-07-24T16:12:00Z",
        )
        conflict_result = "FAILED_TO_REJECT"
    except NonceConflict:
        conflict_result = "REJECTED_NONCE_CONFLICT"

    baseline_profile = copy.deepcopy(engine.profile(covenant["learner_id"]))
    baseline_plan_result = engine.compile_plan(covenant["covenant_id"], issued_at="2026-07-24T18:00:00Z")
    baseline_plan = baseline_plan_result["plan"]

    training_task_ids = [step["task_id"] for step in baseline_plan["selected_steps"]]
    training_run = _run_phase(
        engine, covenant, "training", "T", training_task_ids, response_maps["training"], "2026-07-25T16:00:00Z", baseline_plan
    )
    training_profile = copy.deepcopy(engine.profile(covenant["learner_id"]))
    transfer_plan_result = engine.compile_plan(covenant["covenant_id"], issued_at="2026-07-25T18:30:00Z")
    transfer_plan = transfer_plan_result["plan"]

    transfer_task_ids = [step["task_id"] for step in transfer_plan["selected_steps"]]
    transfer_run = _run_phase(
        engine, covenant, "transfer", "B", transfer_task_ids, response_maps["transfer"], "2026-07-26T16:00:00Z", transfer_plan
    )
    transfer_profile = copy.deepcopy(engine.profile(covenant["learner_id"]))

    # Delayed evidence is deliberately scheduled 29 days later in the synthetic trace.
    delayed_plan_result = engine.compile_plan(covenant["covenant_id"], issued_at="2026-08-24T15:00:00Z")
    delayed_plan = delayed_plan_result["plan"]
    delayed_task_ids = [step["task_id"] for step in delayed_plan["selected_steps"]]
    delayed_run = _run_phase(
        engine, covenant, "delayed", "D", delayed_task_ids, response_maps["delayed"], "2026-08-24T16:00:00Z", delayed_plan
    )
    final_profile = copy.deepcopy(engine.profile(covenant["learner_id"]))
    final_plan_result = engine.compile_plan(covenant["covenant_id"], issued_at="2026-08-24T18:30:00Z")
    final_plan = final_plan_result["plan"]

    checkpoint = store.create_checkpoint(created_at="2026-08-24T18:31:00Z")
    verification = store.verify()
    status = store.status()

    # Crash atomicity probe in an isolated database.
    crash_db = output_dir / "crash_probe.sqlite"
    if crash_db.exists():
        crash_db.unlink()
    crash_store = UpliftStore(crash_db, signer, node_id="UPLIFT-CRASH-PROBE")
    crash_engine = UpliftEngine(pack, key, crash_store)
    crash_engine.register_pack(created_at="2026-07-24T16:00:00Z")
    crash_engine.activate_covenant(covenant, created_at="2026-07-24T16:01:00Z")
    crash_session = crash_engine.create_session(
        covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T17:00:00Z", 90
    )["session"]
    crash_before = crash_store.status()["counts"]
    try:
        crash_engine.submit(
            crash_session["session_id"], "B01", response_maps["baseline"]["B01"][0], response_maps["baseline"]["B01"][1],
            "crash-probe-nonce", submitted_at="2026-07-24T17:01:00Z", failure_injection="after_nonce"
        )
        crash_injected = "FAILED_TO_INJECT"
    except RuntimeError:
        crash_injected = "INJECTED_AND_ROLLED_BACK"
    crash_after = crash_store.status()["counts"]
    crash_retry = crash_engine.submit(
        crash_session["session_id"], "B01", response_maps["baseline"]["B01"][0], response_maps["baseline"]["B01"][1],
        "crash-probe-nonce", submitted_at="2026-07-24T17:01:00Z"
    )
    crash_verification = crash_store.verify()
    unchanged_keys = ("responses", "receipts", "profiles", "events")
    crash_rollback_ok = all(crash_before[key] == crash_after[key] for key in unchanged_keys)

    # Tamper a copy and prove the verifier fails closed without damaging the good store.
    tampered_db = output_dir / "tampered_probe.sqlite"
    store.backup_to(tampered_db)
    tamper_signer = Ed25519Signer.from_seed_text(seed_text)
    with sqlite3.connect(tampered_db) as conn:
        row = conn.execute("SELECT seq,payload_json FROM events ORDER BY seq LIMIT 1").fetchone()
        payload = json.loads(row[1])
        payload["tampered"] = True
        conn.execute("UPDATE events SET payload_json=? WHERE seq=?", (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")), row[0]))
        conn.commit()
    tampered_verification = UpliftStore(tampered_db, tamper_signer, node_id="UPLIFT-DEMO-NODE-01").verify()

    proofs = {
        "idempotent_replay": "PASS" if replay.get("idempotent_replay") and replay["receipt"]["receipt_id"] == first_receipt["receipt"]["receipt_id"] else "FAIL",
        "nonce_conflict": "PASS" if conflict_result == "REJECTED_NONCE_CONFLICT" else "FAIL",
        "crash_rollback": "PASS" if crash_injected == "INJECTED_AND_ROLLED_BACK" and crash_rollback_ok and crash_retry["receipt"]["status"] == "SCORED" and crash_verification["status"] == "PASS" else "FAIL",
        "tamper_detection": "PASS" if tampered_verification["status"] == "FAIL" and verification["status"] == "PASS" else "FAIL",
        "manual_review_chain": "PASS" if sum(len(run["reviews"]) for run in (baseline_run, training_run, transfer_run, delayed_run)) >= 3 else "FAIL",
        "holdout_separation": "PASS" if transfer_plan["target_phase"] == "transfer" and delayed_plan["target_phase"] == "delayed" else "FAIL",
    }
    runtime_status = "PASS" if verification["status"] == "PASS" and all(value == "PASS" for value in proofs.values()) else "FAIL"

    phase_runs = {
        "baseline": {"session": baseline_run["session"], "receipt_count": len(baseline_run["receipts"]), "review_count": len(baseline_run["reviews"])},
        "training": {"session": training_run["session"], "receipt_count": len(training_run["receipts"]), "review_count": len(training_run["reviews"])},
        "transfer": {"session": transfer_run["session"], "receipt_count": len(transfer_run["receipts"]), "review_count": len(transfer_run["reviews"])},
        "delayed": {"session": delayed_run["session"], "receipt_count": len(delayed_run["receipts"]), "review_count": len(delayed_run["reviews"])},
    }
    summary = {
        "object_type": "PARALLAXUPLIFTDemoSummary54",
        "system": "DIKWP-MESH 5.4 Ω PARALLAX UPLIFT",
        "version": "1.0.0",
        "runtime_status": runtime_status,
        "evidence_grade": "E2-author-side-deterministic-synthetic-reference",
        "claim_boundary": (
            "This deterministic trace validates software mechanics, assessment separation, scoring, leases, signatures, "
            "atomic persistence, and tamper detection. Synthetic answers do not demonstrate improvement in a real human."
        ),
        "pack_id": pack["id"],
        "pack_hash": object_hash(pack),
        "scoring_key_hash": object_hash(key),
        "pack_audit": audit,
        "registration": registration,
        "covenant_activation": covenant_result,
        "phase_runs": phase_runs,
        "profiles": {
            "baseline": baseline_profile,
            "training": training_profile,
            "transfer": transfer_profile,
            "final": final_profile,
        },
        "plans": {
            "after_baseline": baseline_plan,
            "after_training": transfer_plan,
            "before_delayed": delayed_plan,
            "final": final_plan,
        },
        "proofs": proofs,
        "proof_details": {
            "nonce_conflict_result": conflict_result,
            "crash_injection": crash_injected,
            "crash_counts_before": crash_before,
            "crash_counts_after": crash_after,
            "crash_verification": crash_verification,
            "tampered_verification": tampered_verification,
        },
        "checkpoint": checkpoint,
        "store_status": status,
        "store_verification": verification,
        "science_boundary": [
            "No real learner participated in this fixture.",
            "Training gains alone never authorize a transfer claim.",
            "Transfer claims require unseen-form evidence; retention claims require delayed evidence.",
            "Manual-rubric scores require disclosed reviewer attestations and remain task-scoped.",
            "The system must not be used for IQ, personality, mental-health, admissions, employment, or covert persuasion judgments.",
        ],
    }
    summary["summary_hash"] = object_hash(summary)

    _write_json(output_dir / "DEMO_SUMMARY.json", summary)
    _write_json(output_dir / "PACK_AUDIT.json", audit)
    _write_json(output_dir / "STORE_STATUS.json", status)
    _write_json(output_dir / "STORE_VERIFICATION.json", verification)
    _write_json(output_dir / "TRANSPARENCY_CHECKPOINT.json", checkpoint)
    _write_json(output_dir / "RUN_PROOF.json", {"object_type": "UPLIFTRunProof54", "status": runtime_status, "proofs": proofs, "summary_hash": summary["summary_hash"]})
    _write_json(output_dir / "SESSION_SAMPLE.json", baseline_run["session"])
    _write_json(output_dir / "RECEIPT_SAMPLE.json", baseline_run["receipts"][0])
    _write_json(output_dir / "REVIEW_SAMPLE.json", baseline_run["reviews"][0])
    _write_json(output_dir / "LEASE_SAMPLE.json", baseline_plan["leases"][0])
    for name, profile in summary["profiles"].items():
        _write_json(output_dir / f"PROFILE_{name.upper()}.json", profile)
    for name, plan in summary["plans"].items():
        _write_json(output_dir / f"PLAN_{name.upper()}.json", plan)
    build_dashboard(summary, output_dir / "dashboard.html")
    return summary
