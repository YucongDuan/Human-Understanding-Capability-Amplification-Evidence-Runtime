from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any

from .canonical import canonical_json, derive_id, merkle_root_hex, object_hash, parse_utc, utc_now
from .pack import audit_knowledge_pack, validate_pack
from .profile import build_understanding_profile, learner_closure_diagnostics
from .scheduler import compile_intervention_plan
from .scoring import calibration_metrics, score_answer
from .signing import Ed25519Signer, verify_object_signature


class StoreError(RuntimeError):
    pass


class NonceConflict(StoreError):
    pass


class CovenantViolation(StoreError):
    pass


class LeaseViolation(StoreError):
    pass


class UpliftStore:
    """Single-node Ω-style atomic evidence store for understanding events."""

    def __init__(self, database: str | Path, signer: Ed25519Signer, node_id: str = "UPLIFT-NODE-01"):
        self.database = Path(database)
        self.database.parent.mkdir(parents=True, exist_ok=True)
        self.signer = signer
        self.node_id = node_id
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.database, timeout=30, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def initialize(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS packs (
                    pack_id TEXT NOT NULL,
                    version TEXT NOT NULL,
                    pack_hash TEXT NOT NULL,
                    key_hash TEXT NOT NULL,
                    audit_status TEXT NOT NULL,
                    audit_json TEXT NOT NULL,
                    pack_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(pack_id, version)
                );
                CREATE TABLE IF NOT EXISTS covenants (
                    covenant_id TEXT PRIMARY KEY,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    payload_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    covenant_id TEXT NOT NULL,
                    phase TEXT NOT NULL,
                    form TEXT NOT NULL,
                    status TEXT NOT NULL,
                    task_ids_json TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    FOREIGN KEY(covenant_id) REFERENCES covenants(covenant_id)
                );
                CREATE TABLE IF NOT EXISTS plans (
                    plan_id TEXT PRIMARY KEY,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    covenant_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    plan_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS leases (
                    lease_id TEXT PRIMARY KEY,
                    plan_id TEXT NOT NULL,
                    covenant_id TEXT NOT NULL,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    intervention TEXT NOT NULL,
                    task_ids_json TEXT NOT NULL,
                    max_uses INTEGER NOT NULL,
                    uses INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    lease_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    FOREIGN KEY(plan_id) REFERENCES plans(plan_id)
                );
                CREATE TABLE IF NOT EXISTS responses (
                    response_id TEXT PRIMARY KEY,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    phase TEXT NOT NULL,
                    nonce TEXT NOT NULL UNIQUE,
                    lease_id TEXT,
                    answer_json TEXT NOT NULL,
                    confidence REAL,
                    response_hash TEXT NOT NULL,
                    score_json TEXT NOT NULL,
                    score REAL,
                    status TEXT NOT NULL,
                    submitted_at TEXT NOT NULL,
                    FOREIGN KEY(session_id) REFERENCES sessions(session_id),
                    FOREIGN KEY(lease_id) REFERENCES leases(lease_id)
                );
                CREATE TABLE IF NOT EXISTS receipts (
                    receipt_id TEXT PRIMARY KEY,
                    response_id TEXT NOT NULL UNIQUE,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    phase TEXT NOT NULL,
                    score REAL,
                    confidence REAL,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    receipt_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(response_id) REFERENCES responses(response_id)
                );
                CREATE TABLE IF NOT EXISTS reviews (
                    review_id TEXT PRIMARY KEY,
                    response_id TEXT NOT NULL UNIQUE,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    reviewer_id TEXT NOT NULL,
                    reviewer_role TEXT NOT NULL,
                    score REAL NOT NULL,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    review_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(response_id) REFERENCES responses(response_id)
                );
                CREATE TABLE IF NOT EXISTS profiles (
                    profile_id TEXT PRIMARY KEY,
                    learner_id TEXT NOT NULL,
                    pack_id TEXT NOT NULL,
                    response_id TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    profile_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(response_id) REFERENCES responses(response_id)
                );
                CREATE TABLE IF NOT EXISTS nonces (
                    nonce TEXT PRIMARY KEY,
                    submission_hash TEXT NOT NULL,
                    response_id TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(response_id) REFERENCES responses(response_id)
                );
                CREATE TABLE IF NOT EXISTS events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    payload_hash TEXT NOT NULL,
                    prev_hash TEXT NOT NULL,
                    event_hash TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS checkpoints (
                    checkpoint_id TEXT PRIMARY KEY,
                    tree_size INTEGER NOT NULL,
                    merkle_root TEXT NOT NULL,
                    head_hash TEXT NOT NULL,
                    previous_checkpoint_hash TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    checkpoint_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_receipts_learner_pack ON receipts(learner_id, pack_id, created_at);
                CREATE INDEX IF NOT EXISTS idx_profiles_learner_pack ON profiles(learner_id, pack_id, created_at);
                CREATE INDEX IF NOT EXISTS idx_reviews_learner_pack ON reviews(learner_id, pack_id, created_at);
                CREATE INDEX IF NOT EXISTS idx_events_hash ON events(event_hash);
                """
            )
            conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('schema_version','1')")
            conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('node_id',?)", (self.node_id,))
            conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('node_key_id',?)", (self.signer.key_id,))

    @staticmethod
    def _decode(row: sqlite3.Row | None, field: str = "payload_json") -> dict[str, Any] | None:
        return json.loads(row[field]) if row is not None else None

    def _append_event(
        self,
        conn: sqlite3.Connection,
        event_type: str,
        payload: dict[str, Any],
        created_at: str,
    ) -> tuple[int, str]:
        last = conn.execute("SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        seq = (int(last["seq"]) + 1) if last else 1
        prev_hash = str(last["event_hash"]) if last else "0" * 64
        payload_hash = object_hash(payload)
        event_core = {
            "seq": seq,
            "event_type": event_type,
            "payload_hash": payload_hash,
            "prev_hash": prev_hash,
            "created_at": created_at,
        }
        event_hash = object_hash(event_core)
        conn.execute(
            "INSERT INTO events(seq,event_type,payload_json,payload_hash,prev_hash,event_hash,created_at) VALUES(?,?,?,?,?,?,?)",
            (seq, event_type, canonical_json(payload), payload_hash, prev_hash, event_hash, created_at),
        )
        return seq, event_hash

    def register_pack(
        self,
        pack: dict[str, Any],
        key_hash: str,
        audit: dict[str, Any] | None = None,
        created_at: str | None = None,
    ) -> dict[str, Any]:
        created_at = created_at or utc_now()
        validate_pack(pack)
        audit = audit or audit_knowledge_pack(pack)
        pack_hash = object_hash(pack)
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            existing = conn.execute(
                "SELECT pack_hash,key_hash,audit_json FROM packs WHERE pack_id=? AND version=?",
                (pack["id"], str(pack["version"])),
            ).fetchone()
            if existing:
                if existing["pack_hash"] != pack_hash or existing["key_hash"] != key_hash:
                    conn.rollback()
                    raise StoreError("pack id/version already registered with different content")
                conn.commit()
                return {
                    "status": "IDEMPOTENT",
                    "pack_id": pack["id"],
                    "pack_hash": pack_hash,
                    "audit": json.loads(existing["audit_json"]),
                }
            conn.execute(
                "INSERT INTO packs(pack_id,version,pack_hash,key_hash,audit_status,audit_json,pack_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (
                    pack["id"],
                    str(pack["version"]),
                    pack_hash,
                    key_hash,
                    audit["status"],
                    canonical_json(audit),
                    canonical_json(pack),
                    created_at,
                ),
            )
            seq, event_hash = self._append_event(
                conn,
                "PACK_REGISTERED",
                {"pack_id": pack["id"], "version": str(pack["version"]), "pack_hash": pack_hash, "key_hash": key_hash, "audit_hash": audit["audit_hash"], "audit_status": audit["status"]},
                created_at,
            )
            conn.commit()
        return {"status": "REGISTERED", "pack_id": pack["id"], "pack_hash": pack_hash, "audit": audit, "event_seq": seq, "event_hash": event_hash}

    def activate_covenant(self, covenant: dict[str, Any], created_at: str | None = None) -> dict[str, Any]:
        created_at = created_at or utc_now()
        required = {"covenant_id", "learner_id", "pack_id", "purpose", "allowed_interventions", "expires_at", "status"}
        missing = required - set(covenant)
        if missing:
            raise CovenantViolation(f"covenant missing fields: {sorted(missing)}")
        if covenant.get("persuasion_allowed", False):
            raise CovenantViolation("UPLIFT refuses hidden or generalized persuasion authority")
        if not covenant.get("learner_veto", True):
            raise CovenantViolation("learner veto must remain enabled")
        if parse_utc(covenant["expires_at"]) <= parse_utc(created_at):
            raise CovenantViolation("covenant already expired")
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            pack_row = conn.execute("SELECT audit_status FROM packs WHERE pack_id=? ORDER BY created_at DESC LIMIT 1", (covenant["pack_id"],)).fetchone()
            if pack_row is None:
                conn.rollback()
                raise CovenantViolation("pack is not registered")
            if pack_row["audit_status"] == "HOLD":
                conn.rollback()
                raise CovenantViolation("curriculum closure audit is HOLD")
            payload_hash = object_hash(covenant)
            existing = conn.execute("SELECT payload_hash,payload_json FROM covenants WHERE covenant_id=?", (covenant["covenant_id"],)).fetchone()
            if existing:
                if existing["payload_hash"] != payload_hash:
                    conn.rollback()
                    raise CovenantViolation("covenant id already exists with different content")
                conn.commit()
                return {"status": "IDEMPOTENT", "covenant": json.loads(existing["payload_json"])}
            conn.execute(
                "INSERT INTO covenants(covenant_id,learner_id,pack_id,status,expires_at,payload_json,payload_hash,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (
                    covenant["covenant_id"], covenant["learner_id"], covenant["pack_id"], covenant["status"], covenant["expires_at"],
                    canonical_json(covenant), payload_hash, created_at,
                ),
            )
            seq, event_hash = self._append_event(conn, "COVENANT_ACTIVATED", {"covenant_id": covenant["covenant_id"], "payload_hash": payload_hash}, created_at)
            conn.commit()
        return {"status": "ACTIVE", "covenant": covenant, "event_seq": seq, "event_hash": event_hash}

    def revoke_covenant(self, covenant_id: str, reason: str, revoked_at: str | None = None) -> dict[str, Any]:
        revoked_at = revoked_at or utc_now()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT status FROM covenants WHERE covenant_id=?", (covenant_id,)).fetchone()
            if not row:
                conn.rollback()
                raise CovenantViolation("unknown covenant")
            conn.execute("UPDATE covenants SET status='REVOKED' WHERE covenant_id=?", (covenant_id,))
            conn.execute("UPDATE leases SET status='REVOKED' WHERE covenant_id=? AND status='ACTIVE'", (covenant_id,))
            seq, event_hash = self._append_event(conn, "COVENANT_REVOKED", {"covenant_id": covenant_id, "reason": reason}, revoked_at)
            conn.commit()
        return {"status": "REVOKED", "covenant_id": covenant_id, "event_seq": seq, "event_hash": event_hash}

    def create_session(self, session: dict[str, Any], created_at: str | None = None) -> dict[str, Any]:
        created_at = created_at or session.get("started_at") or utc_now()
        required = {"session_id", "learner_id", "pack_id", "covenant_id", "phase", "form", "task_ids", "expires_at", "status"}
        missing = required - set(session)
        if missing:
            raise StoreError(f"session missing fields: {sorted(missing)}")
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            covenant = conn.execute("SELECT * FROM covenants WHERE covenant_id=?", (session["covenant_id"],)).fetchone()
            if covenant is None:
                conn.rollback()
                raise CovenantViolation("unknown covenant")
            if covenant["status"] != "ACTIVE" or parse_utc(covenant["expires_at"]) <= parse_utc(created_at):
                conn.rollback()
                raise CovenantViolation("covenant is not active")
            if covenant["learner_id"] != session["learner_id"] or covenant["pack_id"] != session["pack_id"]:
                conn.rollback()
                raise CovenantViolation("session scope differs from covenant")
            existing = conn.execute("SELECT payload_json FROM sessions WHERE session_id=?", (session["session_id"],)).fetchone()
            if existing:
                existing_obj = json.loads(existing["payload_json"])
                if object_hash(existing_obj) != object_hash(session):
                    conn.rollback()
                    raise StoreError("session id already exists with different content")
                conn.commit()
                return {"status": "IDEMPOTENT", "session": existing_obj}
            conn.execute(
                "INSERT INTO sessions(session_id,learner_id,pack_id,covenant_id,phase,form,status,task_ids_json,payload_json,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (
                    session["session_id"], session["learner_id"], session["pack_id"], session["covenant_id"], session["phase"], session["form"], session["status"],
                    canonical_json(session["task_ids"]), canonical_json(session), created_at, session["expires_at"],
                ),
            )
            seq, event_hash = self._append_event(conn, "SESSION_CREATED", {"session_id": session["session_id"], "session_hash": object_hash(session)}, created_at)
            conn.commit()
        return {"status": "ACTIVE", "session": session, "event_seq": seq, "event_hash": event_hash}

    def _receipt_rows(self, conn: sqlite3.Connection, learner_id: str, pack_id: str) -> list[dict[str, Any]]:
        rows = conn.execute(
            "SELECT payload_json FROM receipts WHERE learner_id=? AND pack_id=? ORDER BY created_at, receipt_id",
            (learner_id, pack_id),
        ).fetchall()
        receipts = []
        for row in rows:
            payload = json.loads(row["payload_json"])
            core = payload["receipt"]
            effective_score = core["score"]
            effective_status = core["status"]
            review_id = None
            review_row = conn.execute(
                "SELECT review_id,score,status FROM reviews WHERE response_id=?",
                (core["response_id"],),
            ).fetchone()
            if review_row is not None:
                effective_score = float(review_row["score"])
                effective_status = str(review_row["status"])
                review_id = str(review_row["review_id"])
            receipts.append(
                {
                    "receipt_id": core["receipt_id"],
                    "response_id": core["response_id"],
                    "task_id": core["task_id"],
                    "phase": core["phase"],
                    "score": effective_score,
                    "confidence": core["confidence"],
                    "status": effective_status,
                    "submitted_at": core["submitted_at"],
                    "review_id": review_id,
                }
            )
        return receipts

    def submit_response(
        self,
        pack: dict[str, Any],
        scoring_key: dict[str, Any],
        session_id: str,
        task_id: str,
        answer: Any,
        confidence: float | None,
        nonce: str,
        lease_id: str | None = None,
        submitted_at: str | None = None,
        failure_injection: str | None = None,
    ) -> dict[str, Any]:
        submitted_at = submitted_at or utc_now()
        validate_pack(pack)
        task_by_id = {task["id"]: task for task in pack["tasks"]}
        task = task_by_id.get(task_id)
        if task is None:
            raise StoreError("unknown task")
        if task.get("confidence_required", True) and confidence is None:
            raise StoreError("confidence prediction is required before feedback")
        if confidence is not None and not 0 <= float(confidence) <= 1:
            raise StoreError("confidence must be within [0,1]")
        key_entry = scoring_key.get("answers", {}).get(task_id)
        if key_entry is None:
            raise StoreError("scoring key lacks task")
        score_result = score_answer(task, key_entry, answer)
        submission_core = {
            "session_id": session_id,
            "task_id": task_id,
            "answer": answer,
            "confidence": confidence,
            "nonce": nonce,
            "lease_id": lease_id,
        }
        submission_hash = object_hash(submission_core)
        response_id = derive_id("response", submission_core)

        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            nonce_row = conn.execute("SELECT submission_hash,response_id FROM nonces WHERE nonce=?", (nonce,)).fetchone()
            if nonce_row:
                if nonce_row["submission_hash"] != submission_hash:
                    conn.rollback()
                    raise NonceConflict("nonce already bound to a different response")
                receipt_row = conn.execute("SELECT payload_json FROM receipts WHERE response_id=?", (nonce_row["response_id"],)).fetchone()
                if receipt_row is None:
                    conn.rollback()
                    raise StoreError("idempotent response exists without receipt")
                conn.commit()
                existing = json.loads(receipt_row["payload_json"])
                existing["idempotent_replay"] = True
                return existing

            session = conn.execute("SELECT * FROM sessions WHERE session_id=?", (session_id,)).fetchone()
            if session is None:
                conn.rollback()
                raise StoreError("unknown session")
            if session["status"] != "ACTIVE" or parse_utc(session["expires_at"]) <= parse_utc(submitted_at):
                conn.rollback()
                raise StoreError("session is not active")
            if task_id not in json.loads(session["task_ids_json"]):
                conn.rollback()
                raise StoreError("task is outside session scope")
            if task["phase"] != session["phase"] or task["form"] != session["form"]:
                conn.rollback()
                raise StoreError("task phase/form differs from session")

            covenant = conn.execute("SELECT * FROM covenants WHERE covenant_id=?", (session["covenant_id"],)).fetchone()
            if covenant is None or covenant["status"] != "ACTIVE" or parse_utc(covenant["expires_at"]) <= parse_utc(submitted_at):
                conn.rollback()
                raise CovenantViolation("covenant inactive or expired")
            if covenant["learner_id"] != session["learner_id"] or covenant["pack_id"] != session["pack_id"]:
                conn.rollback()
                raise CovenantViolation("session/covenant scope mismatch")

            lease_use_after: int | None = None
            if lease_id is not None:
                lease = conn.execute("SELECT * FROM leases WHERE lease_id=?", (lease_id,)).fetchone()
                if lease is None:
                    conn.rollback()
                    raise LeaseViolation("unknown lease")
                if lease["status"] != "ACTIVE" or parse_utc(lease["expires_at"]) <= parse_utc(submitted_at):
                    conn.rollback()
                    raise LeaseViolation("lease inactive or expired")
                if lease["learner_id"] != session["learner_id"] or lease["pack_id"] != session["pack_id"] or lease["covenant_id"] != session["covenant_id"]:
                    conn.rollback()
                    raise LeaseViolation("lease scope mismatch")
                if task_id not in json.loads(lease["task_ids_json"]):
                    conn.rollback()
                    raise LeaseViolation("task is outside lease scope")
                if int(lease["uses"]) >= int(lease["max_uses"]):
                    conn.rollback()
                    raise LeaseViolation("lease quota exhausted")
                lease_use_after = int(lease["uses"]) + 1
                conn.execute("UPDATE leases SET uses=? WHERE lease_id=?", (lease_use_after, lease_id))

            response_hash = object_hash({**submission_core, "submitted_at": submitted_at, "score_hash": score_result["score_hash"]})
            conn.execute(
                "INSERT INTO responses(response_id,learner_id,pack_id,session_id,task_id,phase,nonce,lease_id,answer_json,confidence,response_hash,score_json,score,status,submitted_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    response_id, session["learner_id"], session["pack_id"], session_id, task_id, task["phase"], nonce, lease_id,
                    canonical_json(answer), confidence, response_hash, canonical_json(score_result), score_result["score"], score_result["status"], submitted_at,
                ),
            )
            if failure_injection == "after_response":
                raise RuntimeError("injected failure after response insert")
            conn.execute("INSERT INTO nonces(nonce,submission_hash,response_id,created_at) VALUES(?,?,?,?)", (nonce, submission_hash, response_id, submitted_at))
            if failure_injection == "after_nonce":
                raise RuntimeError("injected failure after nonce insert")

            provisional_receipt = {
                "receipt_id": "PENDING",
                "response_id": response_id,
                "task_id": task_id,
                "phase": task["phase"],
                "score": score_result["score"],
                "confidence": confidence,
                "status": score_result["status"],
                "submitted_at": submitted_at,
            }
            prior_receipts = self._receipt_rows(conn, session["learner_id"], session["pack_id"])
            profile_input = prior_receipts + [provisional_receipt]
            profile = build_understanding_profile(pack, profile_input, session["learner_id"], submitted_at)
            profile_id = derive_id("profile", {"learner_id": session["learner_id"], "pack_id": session["pack_id"], "response_id": response_id, "profile_hash": profile["profile_hash"]})
            conn.execute(
                "INSERT INTO profiles(profile_id,learner_id,pack_id,response_id,payload_json,profile_hash,created_at) VALUES(?,?,?,?,?,?,?)",
                (profile_id, session["learner_id"], session["pack_id"], response_id, canonical_json(profile), profile["profile_hash"], submitted_at),
            )

            event_payload = {
                "response_id": response_id,
                "learner_id": session["learner_id"],
                "pack_id": session["pack_id"],
                "session_id": session_id,
                "task_id": task_id,
                "phase": task["phase"],
                "nonce_hash": object_hash(nonce),
                "response_hash": response_hash,
                "score_hash": score_result["score_hash"],
                "profile_hash": profile["profile_hash"],
                "lease_id": lease_id,
                "lease_use_after": lease_use_after,
            }
            event_seq, event_hash = self._append_event(conn, "RESPONSE_SCORED", event_payload, submitted_at)
            state_root = object_hash(
                {
                    "event_hash": event_hash,
                    "response_id": response_id,
                    "profile_hash": profile["profile_hash"],
                    "lease_id": lease_id,
                    "lease_use_after": lease_use_after,
                }
            )
            receipt_core = {
                "object_type": "UnderstandingEvidenceReceipt54",
                "receipt_id": derive_id("receipt", {"response_id": response_id, "event_hash": event_hash}),
                "response_id": response_id,
                "learner_id": session["learner_id"],
                "pack_id": session["pack_id"],
                "pack_hash": object_hash(pack),
                "session_id": session_id,
                "task_id": task_id,
                "dimension": task["dimension"],
                "dikwp_layer": task["dikwp_layer"],
                "phase": task["phase"],
                "form": task["form"],
                "status": score_result["status"],
                "score": score_result["score"],
                "score_hash": score_result["score_hash"],
                "confidence": confidence,
                "calibration": calibration_metrics(score_result["score"], confidence),
                "response_hash": response_hash,
                "profile_id": profile_id,
                "profile_hash": profile["profile_hash"],
                "nonce_hash": object_hash(nonce),
                "lease_id": lease_id,
                "lease_use_after": lease_use_after,
                "event_seq": event_seq,
                "event_hash": event_hash,
                "state_root": state_root,
                "node_id": self.node_id,
                "submitted_at": submitted_at,
                "evidence_grade": "E2-author-side-structured-observation",
                "claim_boundary": "A scored response is evidence for this task under this pack and form; it is not a general intelligence judgment.",
            }
            signature = self.signer.sign_object(receipt_core).to_dict()
            receipt_payload = {"receipt": receipt_core, "signature": signature, "idempotent_replay": False}
            receipt_hash = object_hash(receipt_payload)
            conn.execute(
                "INSERT INTO receipts(receipt_id,response_id,learner_id,pack_id,task_id,phase,score,confidence,status,payload_json,receipt_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    receipt_core["receipt_id"], response_id, session["learner_id"], session["pack_id"], task_id, task["phase"], score_result["score"], confidence,
                    score_result["status"], canonical_json(receipt_payload), receipt_hash, submitted_at,
                ),
            )
            if failure_injection == "before_commit":
                raise RuntimeError("injected failure before commit")
            conn.commit()
            return receipt_payload
        except Exception:
            if conn.in_transaction:
                conn.rollback()
            raise
        finally:
            conn.close()

    def attest_manual_review(
        self,
        pack: dict[str, Any],
        response_id: str,
        reviewer_id: str,
        reviewer_role: str,
        score: float,
        rubric_evidence: dict[str, Any],
        created_at: str | None = None,
    ) -> dict[str, Any]:
        """Append a signed rubric attestation without rewriting the original receipt.

        The original machine receipt remains immutable. The current profile overlays the
        attested score and preserves the review as a separately signed evidence object.
        """
        created_at = created_at or utc_now()
        if not 0 <= float(score) <= 1:
            raise StoreError("manual review score must be within [0,1]")
        if not reviewer_id or not reviewer_role:
            raise StoreError("reviewer identity and role are required")
        task_by_id = {task["id"]: task for task in pack["tasks"]}
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            response = conn.execute("SELECT * FROM responses WHERE response_id=?", (response_id,)).fetchone()
            if response is None:
                conn.rollback()
                raise StoreError("unknown response")
            task = task_by_id.get(response["task_id"])
            if task is None or task.get("response_type") != "manual_rubric":
                conn.rollback()
                raise StoreError("response is not a manual-rubric task")
            existing = conn.execute("SELECT payload_json FROM reviews WHERE response_id=?", (response_id,)).fetchone()
            review_core = {
                "object_type": "ManualUnderstandingReview54",
                "response_id": response_id,
                "learner_id": response["learner_id"],
                "pack_id": response["pack_id"],
                "task_id": response["task_id"],
                "reviewer_id": reviewer_id,
                "reviewer_role": reviewer_role,
                "score": round(float(score), 4),
                "rubric_evidence": rubric_evidence,
                "created_at": created_at,
                "claim_boundary": "This attestation scores only the disclosed rubric for this response; it is not a general learner judgment.",
            }
            review_id = derive_id("review", review_core)
            signature = self.signer.sign_object(review_core).to_dict()
            review_payload = {"review_id": review_id, "review": review_core, "signature": signature}
            review_hash = object_hash(review_payload)
            if existing is not None:
                prior = json.loads(existing["payload_json"])
                if object_hash(prior) != review_hash:
                    conn.rollback()
                    raise StoreError("manual response already has a different review")
                conn.commit()
                prior["idempotent_replay"] = True
                return prior

            conn.execute(
                "INSERT INTO reviews(review_id,response_id,learner_id,pack_id,task_id,reviewer_id,reviewer_role,score,status,payload_json,review_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (review_id, response_id, response["learner_id"], response["pack_id"], response["task_id"], reviewer_id, reviewer_role, float(score), "REVIEWED", canonical_json(review_payload), review_hash, created_at),
            )
            receipts = self._receipt_rows(conn, response["learner_id"], response["pack_id"])
            profile = build_understanding_profile(pack, receipts, response["learner_id"], created_at)
            profile_id = derive_id("profile", {"review_id": review_id, "profile_hash": profile["profile_hash"]})
            conn.execute(
                "INSERT INTO profiles(profile_id,learner_id,pack_id,response_id,payload_json,profile_hash,created_at) VALUES(?,?,?,?,?,?,?)",
                (profile_id, response["learner_id"], response["pack_id"], response_id, canonical_json(profile), profile["profile_hash"], created_at),
            )
            seq, event_hash = self._append_event(
                conn,
                "MANUAL_REVIEW_ATTESTED",
                {"review_id": review_id, "review_hash": review_hash, "response_id": response_id, "profile_hash": profile["profile_hash"]},
                created_at,
            )
            if event_hash is None:  # pragma: no cover - defensive
                raise StoreError("event append failed")
            conn.commit()
            return {**review_payload, "profile_id": profile_id, "profile_hash": profile["profile_hash"], "event_seq": seq, "event_hash": event_hash, "idempotent_replay": False}
        except Exception:
            if conn.in_transaction:
                conn.rollback()
            raise
        finally:
            conn.close()

    def list_receipts(self, learner_id: str, pack_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            return self._receipt_rows(conn, learner_id, pack_id)

    def latest_profile(self, learner_id: str, pack_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT payload_json FROM profiles WHERE learner_id=? AND pack_id=? ORDER BY created_at DESC, rowid DESC LIMIT 1",
                (learner_id, pack_id),
            ).fetchone()
            return json.loads(row["payload_json"]) if row else None

    def get_covenant(self, covenant_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT payload_json,status FROM covenants WHERE covenant_id=?", (covenant_id,)).fetchone()
            if not row:
                raise CovenantViolation("unknown covenant")
            value = json.loads(row["payload_json"])
            value["status"] = row["status"]
            return value

    def compile_and_commit_plan(
        self,
        pack: dict[str, Any],
        covenant_id: str,
        issued_at: str | None = None,
    ) -> dict[str, Any]:
        issued_at = issued_at or utc_now()
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            covenant_row = conn.execute("SELECT * FROM covenants WHERE covenant_id=?", (covenant_id,)).fetchone()
            if covenant_row is None or covenant_row["status"] != "ACTIVE" or parse_utc(covenant_row["expires_at"]) <= parse_utc(issued_at):
                conn.rollback()
                raise CovenantViolation("covenant inactive or expired")
            covenant = json.loads(covenant_row["payload_json"])
            receipts = self._receipt_rows(conn, covenant["learner_id"], covenant["pack_id"])
            profile = build_understanding_profile(pack, receipts, covenant["learner_id"], issued_at)
            closure = learner_closure_diagnostics(pack, receipts)
            plan = compile_intervention_plan(pack, profile, closure, receipts, covenant, issued_at)

            conn.execute("UPDATE plans SET status='SUPERSEDED' WHERE learner_id=? AND pack_id=? AND status='ACTIVE'", (covenant["learner_id"], covenant["pack_id"]))
            conn.execute("UPDATE leases SET status='SUPERSEDED' WHERE learner_id=? AND pack_id=? AND status='ACTIVE'", (covenant["learner_id"], covenant["pack_id"]))
            conn.execute(
                "INSERT INTO plans(plan_id,learner_id,pack_id,covenant_id,status,payload_json,plan_hash,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (plan["plan_id"], covenant["learner_id"], covenant["pack_id"], covenant_id, "ACTIVE", canonical_json(plan), plan["plan_hash"], issued_at, plan["expires_at"]),
            )
            for lease in plan.get("leases", []):
                lease_hash = object_hash(lease)
                conn.execute(
                    "INSERT INTO leases(lease_id,plan_id,covenant_id,learner_id,pack_id,intervention,task_ids_json,max_uses,uses,status,payload_json,lease_hash,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        lease["lease_id"], plan["plan_id"], covenant_id, covenant["learner_id"], covenant["pack_id"], lease["intervention"],
                        canonical_json(lease["task_ids"]), int(lease["max_uses"]), 0, "ACTIVE", canonical_json(lease), lease_hash, issued_at, lease["expires_at"],
                    ),
                )
            seq, event_hash = self._append_event(
                conn,
                "PLAN_COMMITTED",
                {"plan_id": plan["plan_id"], "plan_hash": plan["plan_hash"], "lease_ids": [x["lease_id"] for x in plan.get("leases", [])], "profile_hash": profile["profile_hash"], "diagnostic_hash": closure["diagnostic_hash"]},
                issued_at,
            )
            conn.commit()
            return {"plan": plan, "profile": profile, "closure": closure, "event_seq": seq, "event_hash": event_hash}
        except Exception:
            if conn.in_transaction:
                conn.rollback()
            raise
        finally:
            conn.close()

    def latest_plan(self, learner_id: str, pack_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT payload_json,status FROM plans WHERE learner_id=? AND pack_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1",
                (learner_id, pack_id),
            ).fetchone()
            if not row:
                return None
            value = json.loads(row["payload_json"])
            value["status"] = row["status"]
            return value

    def create_checkpoint(self, created_at: str | None = None) -> dict[str, Any]:
        created_at = created_at or utc_now()
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            events = conn.execute("SELECT event_hash FROM events ORDER BY seq").fetchall()
            hashes = [row["event_hash"] for row in events]
            head_hash = hashes[-1] if hashes else "0" * 64
            previous = conn.execute("SELECT checkpoint_hash FROM checkpoints ORDER BY created_at DESC,rowid DESC LIMIT 1").fetchone()
            previous_hash = previous["checkpoint_hash"] if previous else "0" * 64
            core = {
                "object_type": "UnderstandingTransparencyCheckpoint54",
                "node_id": self.node_id,
                "tree_size": len(hashes),
                "merkle_root": merkle_root_hex(hashes),
                "head_hash": head_hash,
                "previous_checkpoint_hash": previous_hash,
                "created_at": created_at,
                "evidence_grade": "E2-local-signed-checkpoint",
            }
            checkpoint_id = derive_id("checkpoint", core)
            signature = self.signer.sign_object(core).to_dict()
            payload = {"checkpoint_id": checkpoint_id, "checkpoint": core, "signature": signature}
            checkpoint_hash = object_hash(payload)
            conn.execute(
                "INSERT INTO checkpoints(checkpoint_id,tree_size,merkle_root,head_hash,previous_checkpoint_hash,payload_json,checkpoint_hash,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (checkpoint_id, len(hashes), core["merkle_root"], head_hash, previous_hash, canonical_json(payload), checkpoint_hash, created_at),
            )
            conn.commit()
            return payload
        except Exception:
            if conn.in_transaction:
                conn.rollback()
            raise
        finally:
            conn.close()

    def status(self) -> dict[str, Any]:
        with self._connect() as conn:
            counts = {}
            for table in ("packs", "covenants", "sessions", "plans", "leases", "responses", "receipts", "reviews", "profiles", "events", "checkpoints"):
                counts[table] = int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
            head = conn.execute("SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
            return {
                "node_id": self.node_id,
                "node_key_id": self.signer.key_id,
                "database": str(self.database),
                "counts": counts,
                "event_head": {"seq": int(head["seq"]), "event_hash": head["event_hash"]} if head else {"seq": 0, "event_hash": "0" * 64},
            }

    def verify(self) -> dict[str, Any]:
        failures: list[str] = []
        with self._connect() as conn:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            if integrity != "ok":
                failures.append(f"sqlite_integrity:{integrity}")

            previous = "0" * 64
            event_hashes: list[str] = []
            for row in conn.execute("SELECT * FROM events ORDER BY seq"):
                payload = json.loads(row["payload_json"])
                if object_hash(payload) != row["payload_hash"]:
                    failures.append(f"event_payload_hash:{row['seq']}")
                expected = object_hash({"seq": int(row["seq"]), "event_type": row["event_type"], "payload_hash": row["payload_hash"], "prev_hash": previous, "created_at": row["created_at"]})
                if row["prev_hash"] != previous:
                    failures.append(f"event_prev_hash:{row['seq']}")
                if row["event_hash"] != expected:
                    failures.append(f"event_hash:{row['seq']}")
                previous = row["event_hash"]
                event_hashes.append(row["event_hash"])

            for row in conn.execute("SELECT * FROM responses"):
                score_result = json.loads(row["score_json"])
                nonce_row = conn.execute("SELECT nonce FROM nonces WHERE response_id=?", (row["response_id"],)).fetchone()
                if nonce_row is None:
                    failures.append(f"response_nonce_missing:{row['response_id']}")
                    continue
                response_core = {
                    "session_id": row["session_id"],
                    "task_id": row["task_id"],
                    "answer": json.loads(row["answer_json"]),
                    "confidence": row["confidence"],
                    "nonce": nonce_row["nonce"],
                    "lease_id": row["lease_id"],
                    "submitted_at": row["submitted_at"],
                    "score_hash": score_result["score_hash"],
                }
                if object_hash(response_core) != row["response_hash"]:
                    failures.append(f"response_hash:{row['response_id']}")

            for row in conn.execute("SELECT * FROM receipts"):
                payload = json.loads(row["payload_json"])
                if object_hash(payload) != row["receipt_hash"]:
                    failures.append(f"receipt_hash:{row['receipt_id']}")
                if not verify_object_signature(payload["receipt"], payload["signature"]):
                    failures.append(f"receipt_signature:{row['receipt_id']}")
                if payload["receipt"]["response_id"] != row["response_id"]:
                    failures.append(f"receipt_response_binding:{row['receipt_id']}")

            for row in conn.execute("SELECT * FROM reviews"):
                payload = json.loads(row["payload_json"])
                if object_hash(payload) != row["review_hash"]:
                    failures.append(f"review_hash:{row['review_id']}")
                if not verify_object_signature(payload["review"], payload["signature"]):
                    failures.append(f"review_signature:{row['review_id']}")
                if payload["review"]["response_id"] != row["response_id"]:
                    failures.append(f"review_response_binding:{row['review_id']}")
                response = conn.execute("SELECT task_id,status FROM responses WHERE response_id=?", (row["response_id"],)).fetchone()
                if response is None:
                    failures.append(f"review_response_missing:{row['review_id']}")
                elif response["task_id"] != row["task_id"]:
                    failures.append(f"review_task_binding:{row['review_id']}")

            nonce_count = conn.execute("SELECT COUNT(*) FROM nonces").fetchone()[0]
            response_count = conn.execute("SELECT COUNT(*) FROM responses").fetchone()[0]
            receipt_count = conn.execute("SELECT COUNT(*) FROM receipts").fetchone()[0]
            if nonce_count != response_count or response_count != receipt_count:
                failures.append("nonce_response_receipt_count_mismatch")

            for lease in conn.execute("SELECT * FROM leases"):
                used = conn.execute("SELECT COUNT(*) FROM responses WHERE lease_id=?", (lease["lease_id"],)).fetchone()[0]
                if int(lease["uses"]) != int(used):
                    failures.append(f"lease_use_count:{lease['lease_id']}")
                if int(lease["uses"]) > int(lease["max_uses"]):
                    failures.append(f"lease_overuse:{lease['lease_id']}")
                payload = json.loads(lease["payload_json"])
                if object_hash(payload) != lease["lease_hash"]:
                    failures.append(f"lease_hash:{lease['lease_id']}")

            for row in conn.execute("SELECT * FROM profiles"):
                payload = json.loads(row["payload_json"])
                if payload.get("profile_hash") != row["profile_hash"]:
                    failures.append(f"profile_hash_field:{row['profile_id']}")
                core = dict(payload)
                stored = core.pop("profile_hash", None)
                if stored != object_hash(core):
                    failures.append(f"profile_hash:{row['profile_id']}")

            for row in conn.execute("SELECT * FROM plans"):
                payload = json.loads(row["payload_json"])
                core = dict(payload)
                stored = core.pop("plan_hash", None)
                if stored != row["plan_hash"] or stored != object_hash(core):
                    failures.append(f"plan_hash:{row['plan_id']}")

            previous_checkpoint = "0" * 64
            for row in conn.execute("SELECT * FROM checkpoints ORDER BY created_at,rowid"):
                payload = json.loads(row["payload_json"])
                if object_hash(payload) != row["checkpoint_hash"]:
                    failures.append(f"checkpoint_hash:{row['checkpoint_id']}")
                if payload["checkpoint"]["previous_checkpoint_hash"] != previous_checkpoint:
                    failures.append(f"checkpoint_prev:{row['checkpoint_id']}")
                if not verify_object_signature(payload["checkpoint"], payload["signature"]):
                    failures.append(f"checkpoint_signature:{row['checkpoint_id']}")
                tree_size = int(payload["checkpoint"]["tree_size"])
                if tree_size > len(event_hashes):
                    failures.append(f"checkpoint_tree_size:{row['checkpoint_id']}")
                else:
                    if payload["checkpoint"]["merkle_root"] != merkle_root_hex(event_hashes[:tree_size]):
                        failures.append(f"checkpoint_merkle:{row['checkpoint_id']}")
                previous_checkpoint = row["checkpoint_hash"]

            status = self.status()
            report_core = {
                "object_type": "UnderstandingStoreVerification54",
                "status": "PASS" if not failures else "FAIL",
                "sqlite_integrity": integrity,
                "failures": failures,
                "counts": status["counts"],
                "event_head": status["event_head"],
                "merkle_root": merkle_root_hex(event_hashes),
                "node_id": self.node_id,
                "node_key_id": self.signer.key_id,
            }
            report_core["report_hash"] = object_hash(report_core)
            return report_core

    def backup_to(self, destination: str | Path) -> Path:
        """Create a transactionally consistent SQLite backup, including WAL state."""
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            destination.unlink()
        source = self._connect()
        target = sqlite3.connect(destination)
        try:
            source.backup(target)
            target.commit()
        finally:
            target.close()
            source.close()
        return destination

    def forensic_export(self, output_dir: str | Path) -> dict[str, Any]:
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)
        status = self.status()
        verification = self.verify()
        checkpoint = self.create_checkpoint()
        for name, value in (("store_status.json", status), ("store_verification.json", verification), ("checkpoint.json", checkpoint)):
            (output / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"status": status, "verification": verification, "checkpoint": checkpoint}
