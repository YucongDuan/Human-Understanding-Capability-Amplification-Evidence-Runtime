from __future__ import annotations

from datetime import timedelta
from pathlib import Path
from typing import Any

from .canonical import derive_id, parse_utc, utc_now
from .pack import audit_knowledge_pack, load_knowledge_pack, load_scoring_key
from .store import UpliftStore


class UpliftEngine:
    """High-level façade around a knowledge pack and the Ω evidence store."""

    def __init__(
        self,
        pack: dict[str, Any],
        scoring_key: dict[str, Any],
        store: UpliftStore,
    ) -> None:
        self.pack = pack
        self.scoring_key = scoring_key
        self.store = store
        self.task_by_id = {task["id"]: task for task in pack["tasks"]}

    @classmethod
    def from_paths(
        cls,
        pack_path: str | Path,
        key_path: str | Path,
        store: UpliftStore,
    ) -> "UpliftEngine":
        pack = load_knowledge_pack(pack_path)
        key = load_scoring_key(key_path, pack)
        return cls(pack, key, store)

    def register_pack(self, created_at: str | None = None) -> dict[str, Any]:
        audit = audit_knowledge_pack(self.pack)
        return self.store.register_pack(
            self.pack,
            key_hash=self._key_hash(),
            audit=audit,
            created_at=created_at,
        )

    def _key_hash(self) -> str:
        from .canonical import object_hash

        return object_hash(self.scoring_key)

    def activate_covenant(self, covenant: dict[str, Any], created_at: str | None = None) -> dict[str, Any]:
        return self.store.activate_covenant(covenant, created_at=created_at)

    def create_session(
        self,
        learner_id: str,
        covenant_id: str,
        phase: str,
        form: str,
        task_ids: list[str] | None = None,
        started_at: str | None = None,
        duration_minutes: int = 90,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        started_at = started_at or utc_now()
        eligible = [
            task["id"]
            for task in self.pack["tasks"]
            if task["phase"] == phase and task["form"] == form
        ]
        selected = task_ids or eligible
        unknown = set(selected) - set(eligible)
        if unknown:
            raise ValueError(f"tasks outside phase/form scope: {sorted(unknown)}")
        expires_at = (
            parse_utc(started_at) + timedelta(minutes=duration_minutes)
        ).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        core = {
            "learner_id": learner_id,
            "pack_id": self.pack["id"],
            "covenant_id": covenant_id,
            "phase": phase,
            "form": form,
            "task_ids": selected,
            "started_at": started_at,
            "expires_at": expires_at,
            "status": "ACTIVE",
            "metadata": metadata or {},
        }
        session = {"session_id": derive_id("session", core), **core}
        return self.store.create_session(session, created_at=started_at)

    def submit(
        self,
        session_id: str,
        task_id: str,
        answer: Any,
        confidence: float | None,
        nonce: str,
        lease_id: str | None = None,
        submitted_at: str | None = None,
        failure_injection: str | None = None,
    ) -> dict[str, Any]:
        return self.store.submit_response(
            pack=self.pack,
            scoring_key=self.scoring_key,
            session_id=session_id,
            task_id=task_id,
            answer=answer,
            confidence=confidence,
            nonce=nonce,
            lease_id=lease_id,
            submitted_at=submitted_at,
            failure_injection=failure_injection,
        )

    def review_manual_response(
        self,
        response_id: str,
        reviewer_id: str,
        reviewer_role: str,
        score: float,
        rubric_evidence: dict[str, Any],
        created_at: str | None = None,
    ) -> dict[str, Any]:
        return self.store.attest_manual_review(
            pack=self.pack,
            response_id=response_id,
            reviewer_id=reviewer_id,
            reviewer_role=reviewer_role,
            score=score,
            rubric_evidence=rubric_evidence,
            created_at=created_at,
        )

    def compile_plan(self, covenant_id: str, issued_at: str | None = None) -> dict[str, Any]:
        return self.store.compile_and_commit_plan(self.pack, covenant_id, issued_at=issued_at)

    def profile(self, learner_id: str) -> dict[str, Any] | None:
        return self.store.latest_profile(learner_id, self.pack["id"])

    def plan(self, learner_id: str) -> dict[str, Any] | None:
        return self.store.latest_plan(learner_id, self.pack["id"])

    def verify(self) -> dict[str, Any]:
        return self.store.verify()
