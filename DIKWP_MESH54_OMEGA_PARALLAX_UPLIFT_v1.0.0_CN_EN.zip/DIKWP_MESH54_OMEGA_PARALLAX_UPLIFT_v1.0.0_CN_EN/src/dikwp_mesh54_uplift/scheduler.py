from __future__ import annotations

from collections import defaultdict
from datetime import timedelta
from typing import Any

from .canonical import derive_id, object_hash, parse_utc


INTERVENTION_MAP = {
    "illusion_of_fluency": ["confidence_forecast", "delayed_retrieval"],
    "verbal_shell": ["causal_simulation", "self_explanation"],
    "mechanism_without_transfer": ["analogy_transfer", "contrastive_case"],
    "counterfactual_brittleness": ["counterfactual_probe"],
    "boundary_overreach": ["counterexample_hunt"],
    "single_chart_lock": ["observer_rotation"],
    "scale_lock": ["scale_sweep"],
    "modality_lock": ["modality_shift"],
    "residual_suppression": ["unknown_reserve"],
    "revision_resistance": ["error_revision"],
    "purpose_misalignment": ["purpose_recontract"],
    "compression_weakness": ["teach_back"],
    "retention_unverified": ["spaced_revisit"],
}

DIMENSION_INTERVENTIONS = {
    "reconstruction": ["delayed_retrieval"],
    "mechanism": ["causal_simulation", "self_explanation"],
    "prediction": ["causal_simulation"],
    "counterfactual": ["counterfactual_probe"],
    "transfer": ["analogy_transfer", "contrastive_case"],
    "boundary": ["counterexample_hunt"],
    "perspective": ["observer_rotation", "scale_sweep"],
    "calibration": ["confidence_forecast"],
    "revision": ["error_revision"],
    "compression": ["teach_back"],
    "residual": ["unknown_reserve"],
    "purpose": ["purpose_recontract"],
}


def detect_bottlenecks(profile: dict[str, Any], closure: dict[str, Any]) -> list[dict[str, Any]]:
    dims = profile["dimensions"]
    bottlenecks: list[dict[str, Any]] = []

    def dim_score(name: str) -> float | None:
        value = dims[name]
        return value.get("transfer_score") if value.get("transfer_score") is not None else value.get("mean_score")

    def add(code: str, severity: float, evidence: dict[str, Any]) -> None:
        if severity > 0.05:
            bottlenecks.append(
                {
                    "code": code,
                    "severity": round(min(1.0, max(0.0, severity)), 4),
                    "evidence": evidence,
                    "candidate_interventions": INTERVENTION_MAP[code],
                }
            )

    gap = profile["metacognition"].get("global_signed_gap")
    if gap is not None:
        add("illusion_of_fluency", max(0.0, float(gap)), {"global_signed_gap": gap})

    reconstruction = dim_score("reconstruction")
    mechanism = dim_score("mechanism")
    transfer = dim_score("transfer")
    if reconstruction is not None and mechanism is not None:
        add("verbal_shell", max(0.0, reconstruction - mechanism), {"reconstruction": reconstruction, "mechanism": mechanism})
    if mechanism is not None and transfer is not None:
        add("mechanism_without_transfer", max(0.0, mechanism - transfer), {"mechanism": mechanism, "transfer": transfer})

    for code, dim in (
        ("counterfactual_brittleness", "counterfactual"),
        ("boundary_overreach", "boundary"),
        ("revision_resistance", "revision"),
        ("purpose_misalignment", "purpose"),
        ("compression_weakness", "compression"),
        ("residual_suppression", "residual"),
    ):
        score = dim_score(dim)
        if score is not None:
            add(code, 1.0 - score, {dim: score})

    for code, key in (
        ("single_chart_lock", "observer_chart_lock"),
        ("scale_lock", "scale_lock"),
        ("modality_lock", "modality_lock"),
    ):
        value = closure.get(key)
        if value is not None:
            add(code, float(value), {key: value})

    if not profile["evidence_frontier"].get("retention_claim_allowed"):
        add("retention_unverified", 0.55, {"delayed_evidence": False})

    # Add low dimensions not already represented.
    represented = {b["code"] for b in bottlenecks}
    for dimension, value in dims.items():
        score = value.get("transfer_score") if value.get("transfer_score") is not None else value.get("mean_score")
        if score is not None and score < 0.65:
            interventions = DIMENSION_INTERVENTIONS.get(dimension, [])
            code = f"dimension_gap:{dimension}"
            if code not in represented:
                bottlenecks.append(
                    {
                        "code": code,
                        "severity": round(1.0 - float(score), 4),
                        "evidence": {dimension: score},
                        "candidate_interventions": interventions,
                    }
                )

    bottlenecks.sort(key=lambda x: (-x["severity"], x["code"]))
    return bottlenecks


def _attempt_map(receipts: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for receipt in receipts:
        result[str(receipt.get("task_id"))].append(receipt)
    return result


def _task_priority(
    task: dict[str, Any],
    interventions: set[str],
    attempts: dict[str, list[dict[str, Any]]],
    target_phase: str,
) -> float:
    score = 0.0
    tags = set(task.get("intervention_tags", []))
    score += 2.5 * len(tags & interventions)
    score += 0.8 if task["phase"] == target_phase else 0.0
    prior = attempts.get(task["id"], [])
    if not prior:
        score += 1.5
    else:
        scored = [float(r["score"]) for r in prior if r.get("score") is not None]
        if scored:
            score += 1.0 - min(scored[-1], 1.0)
        score -= min(1.0, len(prior) * 0.2)
    score += float(task.get("difficulty", 0.5)) * 0.15
    return score


def compile_intervention_plan(
    pack: dict[str, Any],
    profile: dict[str, Any],
    closure: dict[str, Any],
    receipts: list[dict[str, Any]],
    covenant: dict[str, Any],
    issued_at: str,
) -> dict[str, Any]:
    bottlenecks = detect_bottlenecks(profile, closure)
    allowed = set(covenant.get("allowed_interventions", []))
    desired: list[str] = []
    for bottleneck in bottlenecks:
        for intervention in bottleneck.get("candidate_interventions", []):
            if intervention in allowed and intervention not in desired:
                desired.append(intervention)

    # Decide whether the next admissible evidence should be practice or holdout transfer.
    training_entries = [r for r in receipts if r.get("phase") == "training" and r.get("score") is not None]
    transfer_entries = [r for r in receipts if r.get("phase") == "transfer" and r.get("score") is not None]
    training_mean = sum(float(r["score"]) for r in training_entries) / len(training_entries) if training_entries else 0.0
    if training_entries and training_mean >= 0.72 and not transfer_entries:
        target_phase = "transfer"
    elif transfer_entries and not profile["evidence_frontier"].get("retention_claim_allowed"):
        target_phase = "delayed"
    else:
        target_phase = "training"

    attempts = _attempt_map(receipts)
    candidate_tasks = [
        task
        for task in pack["tasks"]
        if task["phase"] == target_phase
        and (not task.get("intervention_tags") or set(task.get("intervention_tags", [])) & set(desired))
    ]
    if not candidate_tasks:
        candidate_tasks = [task for task in pack["tasks"] if task["phase"] == target_phase]
    if not candidate_tasks and target_phase == "delayed":
        target_phase = "training"
        candidate_tasks = [task for task in pack["tasks"] if task["phase"] == target_phase]

    ranked = sorted(
        candidate_tasks,
        key=lambda task: (
            -_task_priority(task, set(desired), attempts, target_phase),
            task["dimension"],
            task["id"],
        ),
    )

    max_items = int(covenant.get("max_items_per_session", 8))
    max_minutes = int(covenant.get("max_session_minutes", 30))
    selected: list[dict[str, Any]] = []
    used_minutes = 0
    last_dimension: str | None = None
    pool = ranked[:]
    while pool and len(selected) < max_items:
        index = next((i for i, task in enumerate(pool) if task["dimension"] != last_dimension), 0)
        task = pool.pop(index)
        minutes = int(task.get("estimated_minutes", 3))
        if selected and used_minutes + minutes > max_minutes:
            continue
        task_tags = [tag for tag in task.get("intervention_tags", []) if tag in allowed]
        selected.append(
            {
                "task_id": task["id"],
                "dimension": task["dimension"],
                "phase": task["phase"],
                "form": task["form"],
                "estimated_minutes": minutes,
                "interventions": task_tags,
                "reason_codes": [
                    b["code"]
                    for b in bottlenecks
                    if set(b.get("candidate_interventions", [])) & set(task_tags)
                ][:3],
            }
        )
        used_minutes += minutes
        last_dimension = task["dimension"]

    expires_at = (parse_utc(issued_at) + timedelta(days=14)).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    plan_core = {
        "object_type": "InterventionPlan54",
        "learner_id": profile["learner_id"],
        "pack_id": pack["id"],
        "covenant_id": covenant["covenant_id"],
        "issued_at": issued_at,
        "expires_at": expires_at,
        "target_phase": target_phase,
        "bottlenecks": bottlenecks,
        "selected_steps": selected,
        "estimated_minutes": used_minutes,
        "max_items": max_items,
        "allowed_interventions": sorted(allowed),
        "stop_conditions": [
            "learner_veto",
            "covenant_expired_or_revoked",
            "session_time_budget_exhausted",
            "unresolved_distress_or_high_stakes_domain_requires_human_review",
        ],
        "claim_boundary": "This plan selects evidence-producing learning actions; it does not claim the learner has improved until holdout and delayed evidence support that claim.",
    }
    plan_id = derive_id("plan", plan_core)
    plan = {"plan_id": plan_id, **plan_core}

    leases = []
    by_intervention: dict[str, list[str]] = defaultdict(list)
    for step in selected:
        for intervention in step["interventions"]:
            by_intervention[intervention].append(step["task_id"])
    for intervention, task_ids in sorted(by_intervention.items()):
        lease_core = {
            "covenant_id": covenant["covenant_id"],
            "learner_id": profile["learner_id"],
            "pack_id": pack["id"],
            "intervention": intervention,
            "task_ids": sorted(set(task_ids)),
            "max_uses": len(set(task_ids)),
            "issued_at": issued_at,
            "expires_at": expires_at,
            "status": "ACTIVE",
            "reversible": True,
            "reason_codes": sorted({code for step in selected for code in step["reason_codes"] if intervention in step["interventions"]}),
        }
        leases.append({"lease_id": derive_id("lease", lease_core), **lease_core})
    plan["leases"] = leases
    plan["plan_hash"] = object_hash(plan)
    return plan
