from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any


DIMENSION_LABELS = {
    "reconstruction": "重建 / Reconstruction",
    "mechanism": "机制 / Mechanism",
    "prediction": "预测 / Prediction",
    "counterfactual": "反事实 / Counterfactual",
    "transfer": "迁移 / Transfer",
    "boundary": "边界 / Boundary",
    "perspective": "视角 / Perspective",
    "calibration": "校准 / Calibration",
    "revision": "修订 / Revision",
    "compression": "压缩讲解 / Compression",
    "residual": "未知残差 / Residual",
    "purpose": "目的 / Purpose",
}


def _pct(value: float | None) -> str:
    return "—" if value is None else f"{value * 100:.1f}%"


def _bar(value: float | None) -> str:
    width = 0 if value is None else max(0, min(100, value * 100))
    return f'<div class="bar"><span style="width:{width:.1f}%"></span></div>'


def build_dashboard(summary: dict[str, Any], output: str | Path) -> Path:
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    final_profile = summary["profiles"]["final"]
    baseline_profile = summary["profiles"]["baseline"]
    final_plan = summary["plans"].get("final") or {}
    audit = summary["pack_audit"]
    verification = summary["store_verification"]
    status = summary["runtime_status"]

    dimension_rows = []
    for key, value in final_profile["dimensions"].items():
        base = baseline_profile["dimensions"].get(key, {})
        current = value.get("transfer_score")
        if current is None:
            current = value.get("delayed_score")
        if current is None:
            current = value.get("mean_score")
        before = base.get("mean_score")
        delta = None if current is None or before is None else current - before
        dimension_rows.append(
            f"""
            <tr>
              <td><strong>{html.escape(DIMENSION_LABELS.get(key, key))}</strong><small>{html.escape(value['evidence_state'])}</small></td>
              <td>{_pct(before)}{_bar(before)}</td>
              <td>{_pct(current)}{_bar(current)}</td>
              <td class="delta {'pos' if delta is not None and delta > 0 else 'neg' if delta is not None and delta < 0 else ''}">{'—' if delta is None else f'{delta*100:+.1f} pp'}</td>
              <td>{value['n_scored']}</td>
            </tr>
            """
        )

    layer_cards = []
    for layer, value in final_profile["dikwp_layers"].items():
        layer_cards.append(
            f"""
            <article class="layer-card">
              <div class="layer-name">{layer}</div>
              <div class="layer-score">{_pct(value.get('holdout_score') if value.get('holdout_score') is not None else value.get('mean_score'))}</div>
              <div class="muted">n={value.get('n_scored',0)} · holdout={_pct(value.get('holdout_score'))}</div>
            </article>
            """
        )

    bottleneck_items = []
    for item in final_plan.get("bottlenecks", [])[:8]:
        bottleneck_items.append(
            f"<li><span>{html.escape(item['code'])}</span><b>{item['severity']:.2f}</b></li>"
        )
    if not bottleneck_items:
        bottleneck_items.append("<li><span>no committed next-plan bottlenecks</span><b>—</b></li>")

    step_items = []
    for step in final_plan.get("selected_steps", [])[:12]:
        tags = ", ".join(step.get("interventions", [])) or "assessment"
        step_items.append(
            f"<li><strong>{html.escape(step['task_id'])}</strong><span>{html.escape(step['dimension'])} · {html.escape(tags)}</span></li>"
        )
    if not step_items:
        step_items.append("<li><strong>—</strong><span>No next plan committed.</span></li>")

    raw_json = html.escape(json.dumps(summary, ensure_ascii=False, indent=2))
    page = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'">
<title>PARALLAX UPLIFT · Understanding Evidence Studio</title>
<style>
:root{{--bg:#081018;--panel:#0e1a25;--panel2:#132332;--text:#eaf2f8;--muted:#91a6b7;--line:#244155;--accent:#75e6c1;--accent2:#6eb7ff;--warn:#ffca6e;--bad:#ff7e8a;--good:#75e6c1}}
*{{box-sizing:border-box}} body{{margin:0;background:radial-gradient(circle at 10% 0%,#12324a 0,transparent 35%),var(--bg);color:var(--text);font:15px/1.55 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}}
a{{color:var(--accent2)}} .wrap{{max-width:1240px;margin:auto;padding:28px 22px 64px}}
header{{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:end;border-bottom:1px solid var(--line);padding-bottom:24px}}
.eyebrow{{letter-spacing:.18em;text-transform:uppercase;color:var(--accent);font-size:12px;font-weight:700}} h1{{font-size:clamp(28px,5vw,54px);line-height:1.05;margin:8px 0 10px}} h2{{margin:0 0 16px;font-size:23px}} h3{{margin:0 0 8px}}
.subtitle{{color:var(--muted);max-width:780px;font-size:17px}} .status{{padding:11px 14px;border:1px solid var(--accent);color:var(--accent);border-radius:999px;font-weight:800;white-space:nowrap}}
.grid{{display:grid;gap:16px}} .cards{{grid-template-columns:repeat(6,minmax(0,1fr));margin:24px 0}} .card,.panel{{background:linear-gradient(180deg,rgba(19,35,50,.96),rgba(14,26,37,.96));border:1px solid var(--line);border-radius:16px;box-shadow:0 12px 30px rgba(0,0,0,.18)}}
.card{{padding:16px}} .card small,.muted,small{{display:block;color:var(--muted)}} .card b{{font-size:25px;display:block;margin-top:7px}} .panel{{padding:20px;margin:18px 0}}
.two{{grid-template-columns:1.25fr .75fr}} .layers{{grid-template-columns:repeat(5,1fr)}} .layer-card{{background:#0a1520;border:1px solid var(--line);border-radius:14px;padding:15px;text-align:center}} .layer-name{{font-size:12px;color:var(--accent);letter-spacing:.18em}} .layer-score{{font-size:26px;font-weight:800;margin:4px}}
table{{width:100%;border-collapse:collapse}} th,td{{text-align:left;border-bottom:1px solid var(--line);padding:12px 10px;vertical-align:middle}} th{{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.08em}} td small{{font-size:11px;margin-top:2px}} .bar{{height:5px;background:#0a131c;border-radius:99px;overflow:hidden;margin-top:6px;min-width:90px}} .bar span{{display:block;height:100%;background:linear-gradient(90deg,var(--accent2),var(--accent))}}
.delta{{font-variant-numeric:tabular-nums}} .delta.pos{{color:var(--good)}} .delta.neg{{color:var(--bad)}} ul{{margin:0;padding:0;list-style:none}} .rank li{{display:flex;justify-content:space-between;border-bottom:1px solid var(--line);padding:9px 0}} .rank b{{color:var(--warn)}} .steps li{{padding:10px 0;border-bottom:1px solid var(--line)}} .steps span{{display:block;color:var(--muted)}}
.boundary{{border-left:4px solid var(--warn);padding-left:15px;color:#d7e1e9}} details{{margin-top:16px}} summary{{cursor:pointer;color:var(--accent2)}} pre{{white-space:pre-wrap;word-break:break-word;background:#061019;border:1px solid var(--line);padding:16px;border-radius:12px;max-height:620px;overflow:auto;color:#cfe0ed}}
footer{{color:var(--muted);border-top:1px solid var(--line);padding-top:18px;margin-top:30px}}
@media(max-width:1000px){{.cards{{grid-template-columns:repeat(3,1fr)}}.two{{grid-template-columns:1fr}}}} @media(max-width:650px){{header{{grid-template-columns:1fr}}.cards{{grid-template-columns:repeat(2,1fr)}}.layers{{grid-template-columns:repeat(2,1fr)}}table{{font-size:12px}}th:nth-child(5),td:nth-child(5){{display:none}}}}
</style>
</head>
<body><main class="wrap">
<header><div><div class="eyebrow">DIKWP-MESH 5.4 Ω · PARALLAX UPLIFT</div><h1>人类理解证据工作室</h1><div class="subtitle">把“感觉懂了”转换为可重建、可解释、可预测、可反事实、可迁移、可校准、可修订且能承认未知的证据链。</div></div><div class="status">{html.escape(status)}</div></header>
<section class="grid cards">
  <div class="card"><small>课程开放门</small><b>{html.escape(audit['status'])}</b><small>seal {audit['closure_profile']['seal_strength']:.3f}</small></div>
  <div class="card"><small>已提交回答</small><b>{summary['store_status']['counts']['responses']}</b><small>atomic receipts</small></div>
  <div class="card"><small>迁移/保持支持维度</small><b>{final_profile['evidence_frontier']['verified_count']}</b><small>of {len(final_profile['dimensions'])}</small></div>
  <div class="card"><small>全局 Brier</small><b>{'—' if final_profile['metacognition']['global_brier'] is None else f"{final_profile['metacognition']['global_brier']:.3f}"}</b><small>lower is better</small></div>
  <div class="card"><small>证据账本</small><b>{html.escape(verification['status'])}</b><small>{summary['store_status']['counts']['events']} events</small></div>
  <div class="card"><small>证据等级</small><b>E2</b><small>author-side deterministic</small></div>
</section>
<section class="panel"><h2>理解维度：基线与最终证据</h2><div style="overflow:auto"><table><thead><tr><th>维度</th><th>基线</th><th>最终/留出</th><th>变化</th><th>n</th></tr></thead><tbody>{''.join(dimension_rows)}</tbody></table></div></section>
<section class="panel"><h2>DIKWP 资源层</h2><div class="grid layers">{''.join(layer_cards)}</div></section>
<section class="grid two">
  <article class="panel"><h2>下一轮瓶颈与干预</h2><ul class="rank">{''.join(bottleneck_items)}</ul></article>
  <article class="panel"><h2>下一轮计划</h2><ul class="steps">{''.join(step_items)}</ul></article>
</section>
<section class="grid two">
  <article class="panel"><h2>Ω 原子提交</h2><p><code>COMMIT(response + score receipt + profile snapshot + evidence event) OR COMMIT NOTHING</code></p><p class="muted">nonce、租约使用、签名回执和哈希链事件在同一 SQLite 事务中提交；精确重试返回同一回执，冲突重用被拒绝。</p><ul class="rank"><li><span>幂等重试</span><b>{html.escape(summary['proofs']['idempotent_replay'])}</b></li><li><span>nonce 冲突</span><b>{html.escape(summary['proofs']['nonce_conflict'])}</b></li><li><span>崩溃回滚</span><b>{html.escape(summary['proofs']['crash_rollback'])}</b></li><li><span>篡改检测</span><b>{html.escape(summary['proofs']['tamper_detection'])}</b></li></ul></article>
  <article class="panel"><h2>科学边界</h2><p class="boundary">合成演示验证的是软件状态机、评分与证据完整性，不证明任何真实学习者已经提升，也不构成智力、人格、心理健康、就业或招生判断。迁移必须由未见过的留出题支持，保持必须由真实延迟复测支持。</p></article>
</section>
<details><summary>机器可读完整证据 / Full machine-readable evidence</summary><pre>{raw_json}</pre></details>
<footer>Generated by DIKWP-MESH 5.4 Ω PARALLAX UPLIFT · offline single-file studio · no external scripts.</footer>
</main></body></html>"""
    output.write_text(page, encoding="utf-8")
    return output
