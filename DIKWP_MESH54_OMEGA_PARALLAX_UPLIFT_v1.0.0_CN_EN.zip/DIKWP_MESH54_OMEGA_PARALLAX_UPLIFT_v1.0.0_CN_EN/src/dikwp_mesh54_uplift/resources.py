from __future__ import annotations

from importlib import resources
from pathlib import Path


def bundled_example_dir() -> Path:
    """Return the installed deterministic example directory.

    Standard wheel installations are unpacked to a real filesystem, so this
    path can be passed directly to the runtime. Source checkouts may still use
    an explicit --example-dir.
    """
    return Path(str(resources.files("dikwp_mesh54_uplift").joinpath("resources/examples/feedback_loops")))


def bundled_schema_dir() -> Path:
    return Path(str(resources.files("dikwp_mesh54_uplift").joinpath("resources/schemas")))


def bundled_studio_path() -> Path:
    return Path(str(resources.files("dikwp_mesh54_uplift").joinpath("resources/studio/index.html")))
