from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from referencing import Registry, Resource

from .canonical import object_hash


SCHEMA_SAMPLE_MAP = {
    "knowledge_pack.schema.json": "examples/feedback_loops/knowledge_pack.json",
    "scoring_key.schema.json": "examples/feedback_loops/scoring_key.private.json",
    "understanding_covenant.schema.json": "examples/feedback_loops/understanding_covenant.json",
    "curriculum_audit.schema.json": "outputs/demo/PACK_AUDIT.json",
    "session.schema.json": "outputs/demo/SESSION_SAMPLE.json",
    "receipt.schema.json": "outputs/demo/RECEIPT_SAMPLE.json",
    "manual_review.schema.json": "outputs/demo/REVIEW_SAMPLE.json",
    "profile.schema.json": "outputs/demo/PROFILE_FINAL.json",
    "lease.schema.json": "outputs/demo/LEASE_SAMPLE.json",
    "plan.schema.json": "outputs/demo/PLAN_FINAL.json",
    "checkpoint.schema.json": "outputs/demo/TRANSPARENCY_CHECKPOINT.json",
    "store_verification.schema.json": "outputs/demo/STORE_VERIFICATION.json",
    "demo_summary.schema.json": "outputs/demo/DEMO_SUMMARY.json",
    "conformance_report.schema.json": "outputs/conformance/CONFORMANCE_REPORT.json",
    "run_proof.schema.json": "outputs/demo/RUN_PROOF.json",
}


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_artifacts(root: str | Path, output: str | Path | None = None) -> dict[str, Any]:
    root = Path(root)
    schema_dir = root / "schemas"
    schemas = {path.name: _load(path) for path in sorted(schema_dir.glob("*.schema.json"))}
    resources = []
    for name, schema in schemas.items():
        uri = schema.get("$id", f"https://dikwp.example/schemas/{name}")
        resources.append((uri, Resource.from_contents(schema)))
    registry = Registry().with_resources(resources)

    checks: list[dict[str, Any]] = []
    for schema_name, sample_rel in SCHEMA_SAMPLE_MAP.items():
        schema = schemas.get(schema_name)
        sample_path = root / sample_rel
        if schema is None:
            checks.append({"schema": schema_name, "sample": sample_rel, "status": "FAIL", "error": "schema missing"})
            continue
        if not sample_path.exists():
            checks.append({"schema": schema_name, "sample": sample_rel, "status": "FAIL", "error": "sample missing"})
            continue
        sample = _load(sample_path)
        errors = sorted(Draft202012Validator(schema, registry=registry).iter_errors(sample), key=lambda e: list(e.path))
        checks.append(
            {
                "schema": schema_name,
                "sample": sample_rel,
                "status": "PASS" if not errors else "FAIL",
                "errors": [f"{'/'.join(str(x) for x in error.path)}: {error.message}" for error in errors],
                "sample_hash": object_hash(sample),
                "schema_hash": object_hash(schema),
            }
        )

    # Every schema must have a declared $id and compile successfully.
    for name, schema in schemas.items():
        try:
            Draft202012Validator.check_schema(schema)
            compiled = True
            error = None
        except Exception as exc:  # pragma: no cover - diagnostic
            compiled = False
            error = str(exc)
        checks.append({"schema": name, "sample": None, "status": "PASS" if compiled else "FAIL", "errors": [] if compiled else [error]})

    failed = [check for check in checks if check["status"] != "PASS"]
    report = {
        "object_type": "UPLIFTArtifactValidation54",
        "status": "PASS" if not failed else "FAIL",
        "schema_count": len(schemas),
        "sample_validation_count": len(SCHEMA_SAMPLE_MAP),
        "passed": len(checks) - len(failed),
        "failed": len(failed),
        "total": len(checks),
        "checks": checks,
        "claim_boundary": "Schema validity establishes structural conformance, not semantic truth or learning effectiveness.",
    }
    report["report_hash"] = object_hash(report)
    if output is not None:
        output = Path(output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
