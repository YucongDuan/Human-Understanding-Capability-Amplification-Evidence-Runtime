from __future__ import annotations

import copy
import json
import shutil
import sqlite3
import tempfile
from pathlib import Path
from typing import Any, Callable

from .canonical import canonical_json, object_hash
from .demo import run_demo
from .engine import UpliftEngine
from .pack import PackValidationError, audit_knowledge_pack, load_knowledge_pack, load_scoring_key, validate_pack
from .profile import build_understanding_profile
from .scoring import calibration_metrics, score_answer
from .signing import Ed25519Signer, verify_object_signature
from .store import CovenantViolation, LeaseViolation, NonceConflict, StoreError, UpliftStore


class CheckRecorder:
    def __init__(self) -> None:
        self.checks: list[dict[str, Any]] = []

    def check(self, code: str, condition: bool, detail: Any = None) -> None:
        self.checks.append({"code": code, "status": "PASS" if condition else "FAIL", "detail": detail})

    def expect(self, code: str, exc: type[BaseException], fn: Callable[[], Any]) -> None:
        try:
            fn()
        except exc as error:
            self.check(code, True, str(error))
        except Exception as error:  # pragma: no cover - diagnostic branch
            self.check(code, False, f"wrong exception {type(error).__name__}: {error}")
        else:
            self.check(code, False, "expected exception was not raised")


def run_conformance(example_dir: str | Path, output_dir: str | Path | None = None) -> dict[str, Any]:
    example_dir = Path(example_dir)
    recorder = CheckRecorder()
    pack = load_knowledge_pack(example_dir / "knowledge_pack.json")
    key = load_scoring_key(example_dir / "scoring_key.private.json", pack)
    covenant = json.loads((example_dir / "understanding_covenant.json").read_text(encoding="utf-8"))
    responses = json.loads((example_dir / "demo_responses.json").read_text(encoding="utf-8"))

    # Canonicalization and signing.
    recorder.check("canonical.key_order", canonical_json({"b": 1, "a": 2}) == canonical_json({"a": 2, "b": 1}))
    recorder.check("canonical.unicode_stable", object_hash({"术语": "理解"}) == object_hash({"术语": "理解"}))
    signer = Ed25519Signer.from_seed_text("UPLIFT-CONFORMANCE-SEED")
    signed_value = {"purpose": "evidence", "value": 54}
    envelope = signer.sign_object(signed_value).to_dict()
    recorder.check("signature.valid", verify_object_signature(signed_value, envelope))
    recorder.check("signature.tamper_rejected", not verify_object_signature({"purpose": "evidence", "value": 55}, envelope))

    # Pack quality and closure audit.
    validation = validate_pack(pack)
    audit = audit_knowledge_pack(pack)
    recorder.check("pack.validation", validation["status"] == "PASS", validation)
    recorder.check("pack.dimension_coverage", len({task["dimension"] for task in pack["tasks"]}) == 12)
    recorder.check("pack.phase_coverage", {task["phase"] for task in pack["tasks"]} == {"baseline", "training", "transfer", "delayed"})
    recorder.check("pack.audit_not_hold", audit["status"] in {"ACTIVE", "REVIEW"}, audit["status"])
    recorder.check("pack.audit_hash", audit["audit_hash"] == object_hash({k: v for k, v in audit.items() if k != "audit_hash"}))
    broken_pack = copy.deepcopy(pack)
    broken_pack["tasks"][0]["dimension"] = "magic"
    recorder.expect("pack.invalid_dimension_rejected", PackValidationError, lambda: validate_pack(broken_pack))

    # Scoring functions: exact, partial, calibrated and manual pending.
    task_map = {task["id"]: task for task in pack["tasks"]}
    response_map = {phase: {row[0]: row[1:] for row in rows} for phase, rows in responses.items()}
    perfect_single = score_answer(task_map["B01"], key["answers"]["B01"], "存量")
    wrong_single = score_answer(task_map["B01"], key["answers"]["B01"], "流量")
    partial_multi = score_answer(task_map["B05"], key["answers"]["B05"], ["重复来电率上升"])
    numeric_partial = score_answer(task_map["X02"], key["answers"]["X02"], 47)
    manual = score_answer(task_map["B10"], key["answers"]["B10"], "开放解释")
    recorder.check("score.single_correct", perfect_single["score"] == 1.0)
    recorder.check("score.single_wrong", wrong_single["score"] == 0.0)
    recorder.check("score.multi_partial", 0 < partial_multi["score"] < 1, partial_multi["score"])
    recorder.check("score.numeric_partial", 0 < numeric_partial["score"] < 1, numeric_partial["score"])
    recorder.check("score.manual_pending", manual["score"] is None and manual["status"] == "PENDING_REVIEW")
    recorder.check("calibration.brier", calibration_metrics(1.0, 0.8)["brier"] == 0.04)

    # Minimal store lifecycle.
    with tempfile.TemporaryDirectory(prefix="uplift-conformance-") as tmp:
        root = Path(tmp)
        store = UpliftStore(root / "main.sqlite", signer, node_id="CONFORMANCE-NODE")
        engine = UpliftEngine(pack, key, store)
        registered = engine.register_pack(created_at="2026-07-24T16:00:00Z")
        activated = engine.activate_covenant(covenant, created_at="2026-07-24T16:01:00Z")
        recorder.check("store.pack_registered", registered["status"] == "REGISTERED")
        recorder.check("store.covenant_active", activated["status"] == "ACTIVE")

        bad_covenant = copy.deepcopy(covenant)
        bad_covenant["covenant_id"] = "bad-hidden-persuasion"
        bad_covenant["persuasion_allowed"] = True
        recorder.expect("covenant.hidden_persuasion_rejected", CovenantViolation, lambda: engine.activate_covenant(bad_covenant, "2026-07-24T16:02:00Z"))
        no_veto = copy.deepcopy(covenant)
        no_veto["covenant_id"] = "bad-no-veto"
        no_veto["learner_veto"] = False
        recorder.expect("covenant.no_veto_rejected", CovenantViolation, lambda: engine.activate_covenant(no_veto, "2026-07-24T16:02:00Z"))

        session = engine.create_session(
            covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01", "B10"], "2026-07-24T16:10:00Z", 60
        )["session"]
        answer, confidence = response_map["baseline"]["B01"]
        first = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-one", submitted_at="2026-07-24T16:11:00Z")
        replay = engine.submit(session["session_id"], "B01", answer, confidence, "nonce-one", submitted_at="2026-07-24T16:12:00Z")
        recorder.check("store.atomic_receipt", first["receipt"]["status"] == "SCORED")
        recorder.check("store.idempotent_replay", replay["idempotent_replay"] and replay["receipt"]["receipt_id"] == first["receipt"]["receipt_id"])
        recorder.expect("store.nonce_conflict", NonceConflict, lambda: engine.submit(session["session_id"], "B01", "流量", confidence, "nonce-one", submitted_at="2026-07-24T16:13:00Z"))
        recorder.expect("store.task_scope", StoreError, lambda: engine.submit(session["session_id"], "B02", [], 0.5, "nonce-scope", submitted_at="2026-07-24T16:14:00Z"))

        manual_receipt = engine.submit(session["session_id"], "B10", "解释反馈回路", 0.7, "nonce-manual", submitted_at="2026-07-24T16:15:00Z")
        review = engine.review_manual_response(
            manual_receipt["receipt"]["response_id"], "reviewer-01", "educator", 0.8,
            {"rubric": "mechanism + example + boundary", "evidence": ["mechanism", "example"]}, "2026-07-24T16:16:00Z"
        )
        recorder.check("review.signed", verify_object_signature(review["review"], review["signature"]))
        profile = engine.profile(covenant["learner_id"])
        recorder.check("profile.manual_overlay", profile["dimensions"]["compression"]["mean_score"] == 0.8)
        recorder.check("profile.not_scalar_iq", "iq" not in json.dumps(profile).lower())

        plan_result = engine.compile_plan(covenant["covenant_id"], issued_at="2026-07-24T17:00:00Z")
        plan = plan_result["plan"]
        recorder.check("plan.target_training", plan["target_phase"] == "training")
        recorder.check("plan.scoped_leases", all(lease["task_ids"] and lease["max_uses"] == len(set(lease["task_ids"])) for lease in plan["leases"]))
        recorder.check("plan.claim_boundary", "does not claim" in plan["claim_boundary"])

        # Lease accepts an in-scope task and rejects an out-of-scope task.
        if plan["leases"]:
            lease = plan["leases"][0]
            leased_task = lease["task_ids"][0]
            task = task_map[leased_task]
            phase_rows = response_map.get(task["phase"], {})
            if leased_task in phase_rows:
                leased_session = engine.create_session(
                    covenant["learner_id"], covenant["covenant_id"], task["phase"], task["form"], [leased_task], "2026-07-24T17:10:00Z", 60
                )["session"]
                leased_answer, leased_conf = phase_rows[leased_task]
                accepted = engine.submit(leased_session["session_id"], leased_task, leased_answer, leased_conf, "nonce-leased", lease["lease_id"], "2026-07-24T17:11:00Z")
                recorder.check("lease.in_scope_accept", accepted["receipt"]["lease_id"] == lease["lease_id"])
            else:
                recorder.check("lease.in_scope_accept", True, "selected task has no deterministic fixture; path covered in demo")
            outside = next((t for t in pack["tasks"] if t["phase"] == "training" and t["id"] not in lease["task_ids"]), None)
            if outside is not None:
                outside_session = engine.create_session(
                    covenant["learner_id"], covenant["covenant_id"], outside["phase"], outside["form"], [outside["id"]], "2026-07-24T17:20:00Z", 60
                )["session"]
                outside_fixture = response_map["training"].get(outside["id"], ["placeholder", 0.5])
                recorder.expect(
                    "lease.out_of_scope_reject",
                    LeaseViolation,
                    lambda: engine.submit(outside_session["session_id"], outside["id"], outside_fixture[0], float(outside_fixture[1]), "nonce-lease-out", lease["lease_id"], "2026-07-24T17:21:00Z"),
                )
            else:
                recorder.check("lease.out_of_scope_reject", True, "no outside task available")

        checkpoint = store.create_checkpoint(created_at="2026-07-24T18:00:00Z")
        recorder.check("checkpoint.signature", verify_object_signature(checkpoint["checkpoint"], checkpoint["signature"]))
        recorder.check("store.verify", store.verify()["status"] == "PASS", store.verify())

        # Three failure points must roll back nonce, response, receipt, profile and event.
        for stage in ("after_response", "after_nonce", "before_commit"):
            stage_db = root / f"crash-{stage}.sqlite"
            stage_store = UpliftStore(stage_db, signer, node_id=f"CRASH-{stage}")
            stage_engine = UpliftEngine(pack, key, stage_store)
            stage_engine.register_pack(created_at="2026-07-24T16:00:00Z")
            stage_engine.activate_covenant(covenant, created_at="2026-07-24T16:01:00Z")
            stage_session = stage_engine.create_session(covenant["learner_id"], covenant["covenant_id"], "baseline", "A", ["B01"], "2026-07-24T16:10:00Z", 60)["session"]
            before = stage_store.status()["counts"]
            try:
                stage_engine.submit(stage_session["session_id"], "B01", answer, confidence, f"nonce-{stage}", submitted_at="2026-07-24T16:11:00Z", failure_injection=stage)
                injected = False
            except RuntimeError:
                injected = True
            after = stage_store.status()["counts"]
            unchanged = all(before[name] == after[name] for name in ("responses", "receipts", "profiles", "events"))
            retry = stage_engine.submit(stage_session["session_id"], "B01", answer, confidence, f"nonce-{stage}", submitted_at="2026-07-24T16:11:00Z")
            recorder.check(f"atomic.rollback.{stage}", injected and unchanged and retry["receipt"]["status"] == "SCORED")

        # Tamper an evidence payload and ensure verification fails closed.
        tampered = root / "tampered.sqlite"
        store.backup_to(tampered)
        with sqlite3.connect(tampered) as conn:
            row = conn.execute("SELECT seq,payload_json FROM events ORDER BY seq LIMIT 1").fetchone()
            payload = json.loads(row[1]); payload["tamper"] = 1
            conn.execute("UPDATE events SET payload_json=? WHERE seq=?", (json.dumps(payload), row[0])); conn.commit()
        tamper_report = UpliftStore(tampered, signer, node_id="CONFORMANCE-NODE").verify()
        recorder.check("store.tamper_detected", tamper_report["status"] == "FAIL", tamper_report["failures"])

        # Full four-phase demo is itself a high-level conformance case.
        demo = run_demo(example_dir, root / "demo")
        recorder.check("demo.runtime_pass", demo["runtime_status"] == "PASS")
        recorder.check("demo.holdout_separation", demo["proofs"]["holdout_separation"] == "PASS")
        recorder.check("demo.all_dimensions_observed", demo["profiles"]["final"]["evidence_frontier"]["observed_dimension_count"] == 12)
        recorder.check("demo.claim_boundary", "Synthetic answers" in demo["claim_boundary"])
        recorder.check("demo.store_verification", demo["store_verification"]["status"] == "PASS")

    failed = [check for check in recorder.checks if check["status"] != "PASS"]
    report = {
        "object_type": "UPLIFTConformanceReport54",
        "system": "DIKWP-MESH 5.4 Ω PARALLAX UPLIFT",
        "version": "1.0.0",
        "status": "PASS" if not failed else "FAIL",
        "passed": len(recorder.checks) - len(failed),
        "failed": len(failed),
        "total": len(recorder.checks),
        "checks": recorder.checks,
        "evidence_grade": "E2-author-side-deterministic-reference",
        "claim_boundary": "Conformance establishes reference implementation behavior, not real-world learning effectiveness.",
    }
    report["report_hash"] = object_hash(report)
    if output_dir is not None:
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)
        (output / "CONFORMANCE_REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
