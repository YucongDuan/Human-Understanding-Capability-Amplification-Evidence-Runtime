from __future__ import annotations

import math
from typing import Any

from .canonical import bounded, object_hash


class ScoringError(ValueError):
    pass


def _as_set(value: Any) -> set[str]:
    if not isinstance(value, list):
        raise ScoringError("expected an array response")
    return {str(x) for x in value}


def _f1(predicted: set[str], expected: set[str]) -> float:
    if not predicted and not expected:
        return 1.0
    if not predicted or not expected:
        return 0.0
    tp = len(predicted & expected)
    precision = tp / len(predicted)
    recall = tp / len(expected)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def _pairwise_ranking_score(answer: list[Any], expected: list[Any]) -> float:
    if set(map(str, answer)) != set(map(str, expected)) or len(answer) != len(expected):
        return 0.0
    pos_a = {str(v): i for i, v in enumerate(answer)}
    pos_e = {str(v): i for i, v in enumerate(expected)}
    items = list(pos_e)
    if len(items) < 2:
        return 1.0
    correct = 0
    total = 0
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            a, b = items[i], items[j]
            total += 1
            correct += int((pos_a[a] < pos_a[b]) == (pos_e[a] < pos_e[b]))
    return correct / total


def _edge_set(value: Any) -> set[str]:
    if not isinstance(value, list):
        raise ScoringError("edge_set response must be an array")
    normalized: set[str] = set()
    for edge in value:
        if isinstance(edge, str):
            normalized.add(edge.strip())
        elif isinstance(edge, (list, tuple)) and len(edge) == 3:
            normalized.add("|".join(str(x).strip() for x in edge))
        elif isinstance(edge, dict):
            normalized.add("|".join(str(edge.get(k, "")).strip() for k in ("source", "relation", "target")))
        else:
            raise ScoringError("invalid edge representation")
    return normalized


def score_answer(task: dict[str, Any], key_entry: dict[str, Any], answer: Any) -> dict[str, Any]:
    response_type = task["response_type"]
    if key_entry.get("response_type") != response_type:
        raise ScoringError("task and scoring key response types differ")

    details: dict[str, Any] = {}
    status = "SCORED"
    if response_type == "single_choice":
        expected = str(key_entry["correct"])
        score = float(str(answer) == expected)
        details = {"exact_match": bool(score)}
    elif response_type == "multi_select":
        predicted = _as_set(answer)
        expected = {str(x) for x in key_entry["correct"]}
        score = _f1(predicted, expected)
        details = {
            "true_positive": sorted(predicted & expected),
            "false_positive": sorted(predicted - expected),
            "missed": sorted(expected - predicted),
        }
    elif response_type == "numeric":
        try:
            numeric = float(answer)
        except (TypeError, ValueError) as exc:
            raise ScoringError("numeric response required") from exc
        expected = float(key_entry["correct"])
        tolerance = float(key_entry.get("tolerance", 0.0))
        scale = float(key_entry.get("partial_credit_scale", max(tolerance * 3, abs(expected) * 0.25, 1.0)))
        error = abs(numeric - expected)
        score = 1.0 if error <= tolerance else bounded(1.0 - ((error - tolerance) / max(scale, 1e-12)))
        details = {"absolute_error": error, "tolerance": tolerance}
    elif response_type == "ranking":
        if not isinstance(answer, list):
            raise ScoringError("ranking response must be an array")
        expected = key_entry["correct"]
        score = _pairwise_ranking_score(answer, expected)
        details = {"pairwise_order_accuracy": score}
    elif response_type == "edge_set":
        predicted = _edge_set(answer)
        expected = _edge_set(key_entry["correct"])
        score = _f1(predicted, expected)
        details = {
            "edge_precision_recall_f1": score,
            "extra_edges": sorted(predicted - expected),
            "missing_edges": sorted(expected - predicted),
        }
    elif response_type == "classification":
        if not isinstance(answer, dict):
            raise ScoringError("classification response must be an object")
        expected = {str(k): str(v) for k, v in key_entry["correct"].items()}
        total = len(expected)
        correct = sum(1 for k, v in expected.items() if str(answer.get(k)) == v)
        score = correct / max(1, total)
        details = {
            "correct_count": correct,
            "total_count": total,
            "incorrect_items": sorted(k for k, v in expected.items() if str(answer.get(k)) != v),
        }
    elif response_type == "manual_rubric":
        status = "PENDING_REVIEW"
        score = None
        details = {
            "required_rubric_dimensions": key_entry.get("rubric_dimensions", []),
            "automatic_scoring_disabled": True,
        }
    else:
        raise ScoringError(f"unsupported response type: {response_type}")

    if score is not None:
        score = round(bounded(score), 6)
    result = {
        "status": status,
        "score": score,
        "details": details,
        "feedback_code": key_entry.get("feedback_code", "NO_FEEDBACK_CODE"),
        "misconception_codes": key_entry.get("misconception_codes", []),
    }
    result["score_hash"] = object_hash(result)
    return result


def calibration_metrics(score: float | None, confidence: float | None) -> dict[str, Any]:
    if score is None or confidence is None:
        return {
            "available": False,
            "brier": None,
            "signed_gap": None,
            "absolute_gap": None,
            "overconfidence": None,
        }
    confidence = bounded(confidence)
    score = bounded(score)
    signed_gap = confidence - score
    return {
        "available": True,
        "brier": round((confidence - score) ** 2, 6),
        "signed_gap": round(signed_gap, 6),
        "absolute_gap": round(abs(signed_gap), 6),
        "overconfidence": round(max(0.0, signed_gap), 6),
    }


def apply_manual_rubric(
    response_text: str,
    rubric_scores: dict[str, float],
    rubric_weights: dict[str, float] | None = None,
) -> dict[str, Any]:
    if not response_text.strip():
        raise ScoringError("manual rubric response text must not be empty")
    if not rubric_scores:
        raise ScoringError("rubric_scores must not be empty")
    weights = rubric_weights or {name: 1.0 for name in rubric_scores}
    if set(weights) != set(rubric_scores):
        raise ScoringError("rubric weights must match rubric score names")
    for name, value in rubric_scores.items():
        if not 0 <= float(value) <= 1:
            raise ScoringError(f"rubric score {name} outside [0,1]")
    total_weight = sum(float(v) for v in weights.values())
    if total_weight <= 0:
        raise ScoringError("rubric weights must sum to a positive value")
    score = sum(float(rubric_scores[k]) * float(weights[k]) for k in rubric_scores) / total_weight
    result = {
        "status": "SCORED_BY_ATTESTATION",
        "score": round(score, 6),
        "rubric_scores": {k: round(float(v), 6) for k, v in rubric_scores.items()},
        "rubric_weights": {k: round(float(v), 6) for k, v in weights.items()},
        "response_text_hash": object_hash(response_text),
    }
    result["score_hash"] = object_hash(result)
    return result
