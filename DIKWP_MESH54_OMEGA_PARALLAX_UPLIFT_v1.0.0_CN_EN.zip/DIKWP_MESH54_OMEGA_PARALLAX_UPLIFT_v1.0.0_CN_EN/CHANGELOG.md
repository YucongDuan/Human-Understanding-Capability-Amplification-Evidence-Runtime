# Changelog

## 1.0.0 — 2026-07-24

- Upgraded PARALLAX CLOSURE MVP into a learner-governed understanding amplification and evidence runtime.
- Added 12-dimensional evidence profiles and DIKWP resource summaries.
- Added baseline/training/hidden-transfer/delayed-retention separation.
- Added confidence calibration and residual/insufficient-information handling.
- Added signed manual-rubric review for open responses.
- Added PARALLAX curriculum closure audit.
- Added scoped intervention planning and leases.
- Added SQLite Ω atomic commit, persistent nonces, idempotency, crash rollback and WAL-consistent backup.
- Added Ed25519 receipts, hash-chained events and Merkle checkpoints.
- Added authenticated local API, learner studio, CLI, JSON Schemas, deterministic demo, conformance, tests and supply-chain metadata.
- Declared E2 author-side deterministic evidence boundary; no real-human effectiveness claim.
