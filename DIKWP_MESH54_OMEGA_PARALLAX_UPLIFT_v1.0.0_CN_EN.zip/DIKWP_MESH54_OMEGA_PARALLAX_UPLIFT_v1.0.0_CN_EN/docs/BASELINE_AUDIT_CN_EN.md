# PARALLAX CLOSURE MVP 基线审计与升级结论  
# Baseline Audit and Upgrade Decision

## 1. 审计对象

输入附件：`PARALLAX_CLOSURE_MVP(1).zip`  
SHA‑256：`466dcd50ff002f74be11cf451a0235f5a353a39ab1453eb2f7fc4e4a5f346a4d`

原始项目包含：

- `src/parallax/model.py`：有向图节点、边和案例数据结构；
- `metrics.py`：seal strength、coordination value、capture risk、generative openness；
- `worlds.py`：观察者翻转、尺度扫描、规则对象化、目标悬置、模态注入、权力重分配、未知轴；
- `interventions.py`：候选干预与 Pareto 筛选；
- `emergence.py`：替代世界的涌现候选；
- `selfaudit.py`：系统自身闭环审计；
- 5 个结构案例、2 个 JSON Schema、单文件 studio 和 6 项测试。

本次重新执行原始测试：`6 passed`。

## 2. 被保留的核心价值

### 2.1 对象而不是人的闭环诊断

PARALLAX 的重要伦理选择是分析关系结构，而不是给个人贴上“开放/封闭”标签。UPLIFT 完整保留这一边界，并进一步规定：学习者闭环诊断只能描述**已观察任务中的表现模式**，不得推断身份、心理状态、动机或稳定人格特质。

### 2.2 多种开域算子

原系统的七类世界变换适合转译为学习干预：

| PARALLAX 算子 | UPLIFT 干预 |
|---|---|
| observer flip | observer rotation / affected-party chart |
| scale sweep | micro–meso–macro scale sweep |
| rule objectification | rule-as-object / counterexample hunt |
| goal suspension | purpose recontract / goal suspension |
| modality injection | diagram, table, narrative and symbolic modality shift |
| power redistribution | affected-party veto and source plurality |
| unknown axis | UAX residual reserve and insufficient-information responses |

### 2.3 协调价值与开放价值并存

原系统不主张摧毁所有闭环，而是寻找在保留必要协调价值的同时降低捕获风险的最小可逆路径。UPLIFT 将此原则用于课程和学习计划：干预必须有范围、时间、次数、停止条件与回滚路径。

## 3. 原始 MVP 尚未覆盖的关键能力

| 缺口 | 风险 | UPLIFT 补齐方式 |
|---|---|---|
| 没有学习者会话和答题事件 | 无法形成连续训练闭环 | baseline / training / transfer / delayed 会话 |
| 没有“理解”的操作性证据定义 | 结构诊断无法说明是否真正学会 | 12 维理解向量与证据状态机 |
| 没有训练与留出迁移隔离 | 可能把熟悉题表现误报为迁移 | 预先隔离的 form A/T/B/D |
| 没有延迟复测 | 即时成功可能迅速遗忘 | delayed phase 与 retention gate |
| 没有信心校准 | 流畅感可能冒充理解 | 作答前 confidence、Brier 与 signed gap |
| 没有开放解释复核链 | 关键词评分会产生伪理解 | `PENDING_REVIEW` + signed rubric attestation |
| 没有目的契约与学习者否决 | 干预可能越权或转向说服 | Intent Field Covenant + learner veto |
| 没有 scoped capability | 计划可被无限扩张 | intervention leases with task/time/use scope |
| 没有原子持久化 | 部分失败可破坏证据链 | SQLite WAL + `BEGIN IMMEDIATE` Ω transaction |
| 没有 nonce 与幂等语义 | 重试可能重复记分或扣配额 | durable nonce and exact replay receipt |
| 没有签名透明度账本 | 事后难以定位篡改 | Ed25519 receipt, hash chain, Merkle checkpoint |
| 没有服务端评分键隔离 | 浏览器可能看到答案 | authenticated local API; public catalog only |
| 没有真实有效性研究协议 | 软件演示易被宣传成增益证明 | preregistered evaluation protocol and E2 boundary |

## 4. 关键设计决定

### 决定 A：不生成一个“理解总分”

原因：总分会掩盖机制、迁移、边界、校准、残差和目的之间的结构差异，并易被高风险决策滥用。系统只保留维度画像、DIKWP 层摘要和证据前沿。

### 决定 B：训练表现不能晋级为迁移证据

训练题用于形成能力；未见表单用于检验能力。两者在数据模型中使用不同 `phase` 与 `form`，计划器只有在训练证据达到阈值后才进入 transfer。

### 决定 C：未知是一类成功行为

当任务信息不足时，正确行为可能是保留残差、说明缺失观测和拒绝过度闭合，而不是猜一个最接近答案。

### 决定 D：开放解释不自动判定

任何基于自由文本的机制解释、teach-back 或压缩任务默认 `PENDING_REVIEW`。评分必须来自披露的 rubric attestation；该复核是新的签名证据对象，不修改原始回执。

### 决定 E：学习干预是一种受约束能力

每项干预必须来自学习者允许的集合，并由计划生成 scoped lease。契约撤销会同时撤销活跃租约。

### 决定 F：演示不能冒充真实人效

合成答案只用来验证状态机、评分、迁移门、延迟门和审计链。发行物维持 E2，不声称真实学习者已提升。

## 5. 升级后的系统边界

UPLIFT 是：

- 低风险教育和自我学习参考运行时；
- 知识包 authoring、闭环审计、适应性训练与证据管理工具；
- 可用于设计预注册人类研究的基础设施。

UPLIFT 不是：

- 神经科学或意识测量系统；
- 心理诊断工具；
- 高风险人员筛选系统；
- 自动教师替代品；
- 已被临床或监管认证的产品；
- 已证明对所有学科、年龄或语言有效的通用增智系统。

## 6. 审计结论

PARALLAX CLOSURE MVP 已经提供了一个有价值的“闭环结构与替代世界生成”内核。真正缺失的是把开放性诊断接入**学习者控制、证据分级、迁移检验、延迟保持和原子审计**的执行层。

UPLIFT 的升级不是把 PARALLAX 变成个人分类器，而是把它变成：

> 一个能够发现课程和学习证据中的闭合风险、生成最小可逆理解干预，并要求每项“提升”主张通过未见迁移和延迟保持门的 MESH5.4 Ω 运行系统。
