# 运维与恢复手册 / Operations and Recovery Runbook

## 1. 首次部署

1. 创建专用操作系统账户；
2. 使用磁盘加密；
3. 创建 Python 虚拟环境并从已验证 wheel 安装；
4. 生成 Ed25519 seed 文件和随机 API token；
5. 将 seed、token、评分键和数据库权限设置为仅服务账户可读；
6. 运行知识包审计和 conformance；
7. 注册 pack，激活 covenant；
8. 默认绑定 `127.0.0.1`；
9. 在外部暴露前增加 TLS、OIDC、速率限制和反向代理；
10. 创建初始 checkpoint 和一致性备份。

## 2. 启动前检查

```bash
uplift54 --version
uplift54 audit-pack --pack <pack.json>
uplift54 verify --db <db> --seed-file <seed>
uplift54 status --db <db> --seed-file <seed>
```

确认：

- pack/key hash 匹配；
- covenant 未过期；
- 系统时钟同步；
- 磁盘空间充足；
- 最近备份可读取；
- 评分键未出现在公开目录；
- token 不在 shell 历史或日志中。

## 3. 一致性备份

不要在服务运行时直接复制 `.sqlite` 主文件，因为 WAL 中可能有尚未 checkpoint 的事务。使用运行时的 SQLite online backup 原语，或先安全停止服务并确认 checkpoint。

建议备份集合：

- 一致性数据库快照；
- pack 和 key hash（不一定备份明文 key 到同一位置）；
- covenant；
- 签名 checkpoint；
- 软件版本、wheel hash、manifest；
- 恢复说明。

备份应加密，并定期实际恢复验证。

## 4. 崩溃恢复

1. 停止写入；
2. 保存数据库、WAL 和 SHM 文件的取证副本；
3. 在副本上运行 `uplift54 verify`；
4. 如果 integrity check 失败，恢复最近一致性备份；
5. 重放客户端请求时保留原 nonce；
6. 检查相同请求是否返回原回执；
7. 创建恢复 checkpoint；
8. 记录事件、影响和未解决残差。

不要通过删除 nonce 表来“修复”重放错误。

## 5. 密钥泄漏

当前单节点参考实现没有完整的在线密钥轮换协议。发现 seed 或私钥泄漏时：

- 停止服务；
- 保存最后可信 checkpoint；
- 撤销受影响部署的可信状态；
- 生成新密钥和新 node identity；
- 导出旧链供取证，不把新链伪装成连续旧链；
- 通知受影响学习者或研究者；
- 重新签发后续事件。

## 6. 评分键或迁移表单泄漏

- 立即暂停受影响表单；
- 将之后的结果标记为不可用于迁移主张；
- 生成新版本 pack/form/key；
- 保留泄漏事件和影响时间窗；
- 不在同一版本下静默替换；
- 对已发布结论做敏感性分析或撤回。

## 7. Covenant 撤销

学习者撤销后：

- 将 covenant 状态设为 revoked；
- 撤销所有活跃 leases；
- 拒绝新 session 和提交；
- 按同意范围执行导出/删除；
- 若依法需保留不可变审计记录，最小化内容并清楚说明保留依据。

## 8. 监控

至少监控：

- verify 状态；
- nonce 冲突；
- 回执失败；
- 人工复核积压；
- covenant/lease 过期；
- 高信心错误；
- 迁移与训练差距；
- 延迟流失；
- 某群体异常负担；
- 数据库大小和备份新鲜度。

## 9. 升级

每次升级：

1. 在副本上运行迁移；
2. 比较 schema 和 event hash 规则；
3. 运行全部测试、conformance 和 artifact validation；
4. clean-wheel 安装验证；
5. 恢复测试；
6. 生成新 SBOM、attestation、manifest 和 ZIP hash；
7. 记录 rollback 版本。

## 10. 停止条件

出现以下任何情况，暂停新主张和高影响使用：

- verify 失败；
- 私钥或评分键泄漏；
- 迁移表单泄漏；
- 撤销未生效；
- 数据丢失或无法恢复；
- 不利结果达到预注册阈值；
- 发现画像被用于禁止用途。

---

# English summary

Operate UPLIFT as a local, least-privilege service. Use encrypted storage, file permissions, validated wheels, loopback binding, external TLS/auth for any network exposure, and SQLite online backups rather than copying a live WAL database. Preserve nonces during retry, verify before and after recovery, treat scoring-key leakage as invalidating affected transfer evidence, and pause use when integrity, revocation, privacy, or adverse-outcome controls fail.
