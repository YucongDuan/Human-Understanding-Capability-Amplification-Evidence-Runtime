# UPLIFT 方法规范 / Method Specification

## 1. 目标与基本立场

UPLIFT 不把“理解”当作不可观察的单一实体，也不把一次考试分数当作理解本身。系统将理解操作化为：学习者能否在明确对象、目的、观察者、尺度、时间、来源和证据边界下，重建结构、解释机制、生成预测、处理反事实、迁移到未见情境、识别边界、校准信心、修订错误并保留未知。

该定义是一个**可证伪的工程约定**，不是关于人类心智本质的终极理论。

## 2. UPLIFT 六项约束

UPLIFT 同时表示：

1. **Uncertainty-reserving**：不把未知强行压缩为已有类别；
2. **Perspective-plural**：同一对象允许多个观察者与尺度图册并存；
3. **Learner-controlled**：训练目的、时间预算、禁止结果和退出权由学习者契约约束；
4. **Intervention-leased**：每项干预只有有限作用域、次数和有效期；
5. **Falsifiable**：每个能力结论都有反证条件和降级路径；
6. **Transfer-tested**：训练内熟练度不能冒充未见情境迁移，更不能冒充延迟保持。

## 3. 十二维理解证据向量

| 维度 | 最小可观察证据 | 常见伪阳性 | 主要反证 |
|---|---|---|---|
| Reconstruction | 脱离原文重建对象、关系和约束 | 逐句复述 | 换一种表面表达即失效 |
| Mechanism | 解释中间状态、方向和约束 | 相关性语言 | 干预预测与机制不一致 |
| Prediction | 对未见输入给出可检验结果 | 猜中单题 | 跨实例误差显著增大 |
| Counterfactual | 修改条件后重算结果 | 只说“会改变” | 无法指出改变路径 |
| Transfer | 在隐藏新领域识别深层结构 | 词汇相似匹配 | 表面改变后性能坍塌 |
| Boundary | 给出反例、适用域和停止条件 | 泛化免责声明 | 无法区分域内外实例 |
| Perspective | 切换观察者、尺度和利益位置 | 罗列观点 | 观点变化不改变模型变量 |
| Calibration | 信心与正确率相符 | 事后合理化 | 高信心错误持续出现 |
| Revision | 新证据后明确修订模型 | 擦除旧答 | 无修订原因或不可追溯 |
| Compression | 短表达保留关键因果结构 | 删除细节 | 压缩后无法支持预测 |
| Residual | 合理选择“信息不足”并说明缺口 | 回避作答 | 已有充分信息仍拒答 |
| Purpose | 说明服务对象、优化目标、代价和否决条件 | 空泛价值词 | 无法识别受损方或代理目标 |

## 4. DIKWP 资源映射

UPLIFT 使用 DIKWP 作为证据资源层，而不是人格标签：

- **Data**：观察、题面、实例、日志、时间戳；
- **Information**：对象、关系、差异、编码和来源；
- **Knowledge**：稳定约束、机制、可复用模型；
- **Wisdom**：边界、代价、冲突、长期后果与回滚；
- **Purpose**：服务谁、优化什么、谁可否决以及何时停止。

一个知识包必须覆盖至少多个资源层；单纯事实记忆包不能自动生成“综合理解”主张。

## 5. 四阶段证据隔离

### Baseline

在训练前采集任务表现、作答前信心、错误类型、未知保留和观点/尺度锁定。基线任务不能在之后被当作迁移题。

### Training

允许反馈、提示、对比案例、检索练习、反事实模拟、teach-back 等干预。训练结果只能支持 `EMERGING` 或 `PROVISIONAL`。

### Transfer

使用在训练阶段隐藏的表单、实例或领域。只有该阶段的任务能支持 `TRANSFER_SUPPORTED`。表单必须在内容、表面词汇或情境上与训练题分离，同时保留预注册的目标深层结构。

### Delayed

在预注册的真实时间间隔后复测。只有达到最短延迟要求且通过数据完整性检查的结果能支持 `RETENTION_SUPPORTED`。修改系统时钟或仅在同一会话稍后重复，不构成保持证据。

## 6. 证据状态机

```text
UNOBSERVED
   ↓ 至少一个有效观测
EMERGING
   ↓ 多项一致证据且非仅自动猜测
PROVISIONAL
   ↓ 隐藏迁移表单达到门槛
TRANSFER_SUPPORTED
   ↓ 真实延迟复测达到门槛
RETENTION_SUPPORTED
```

任何新证据都可以使状态降级。状态不是永久勋章。

## 7. 校准

回答前先记录置信度 `c ∈ [0,1]`，再揭示结果。系统使用 Brier 分数等指标衡量预测概率与结果之间的偏差。校准维度不会因为“平均信心低”而自动加分；目标是信心与实际可验证表现匹配。

## 8. 人工开放题

开放解释默认返回 `PENDING_REVIEW`。人工复核必须包含：

- reviewer ID 与角色；
- 量表条目及证据片段；
- 分数；
- 时间戳；
- Ed25519 签名；
- 原始回答哈希与任务哈希。

复核是追加事件，不覆盖原始回执。真实研究应采用盲评、双评及分歧裁决，并报告评审一致性。

## 9. 适应性计划

调度器只选择最小、可逆、范围受限的干预。优先级综合：

```text
priority = evidence_gap × transfer_value × uncertainty × learner_purpose
           × reversibility × closure_escape / burden
```

计划不是“推荐算法权威”。学习者可拒绝单项干预或撤销整个 covenant。

## 10. PARALLAX 课程闭环审计

知识包发布前检查：

- 观察者是否单一；
- 来源是否单一；
- 尺度是否单一；
- 模态是否单一；
- 是否只有一种成功定义；
- 是否缺少反例、未知选项和受影响方；
- 迁移题是否泄漏训练表面特征。

审计输出 `openness_score`、`capture_risk` 和 `seal_score`。这些是课程结构风险信号，不是学习者属性。

## 11. 原子证据提交

在一次事务中共同提交回答、nonce、租约使用、评分、画像快照、证据事件和签名回执。失败则全部回滚。相同 nonce + 相同请求返回同一回执；相同 nonce + 不同请求被拒绝。

## 12. 不允许的推断

UPLIFT 输出不能被转换为：智商、人格、精神健康、道德价值、政治倾向、就业适配度或“总体认知等级”。它只描述一个知识包中的任务证据及其边界。

---

# English summary

UPLIFT operationalizes understanding as a falsifiable, multidimensional evidence vector rather than a latent global score. It separates baseline, feedback-rich training, hidden-form transfer, and genuine delayed retention. Confidence is recorded before outcome disclosure; open responses require signed rubric review; adaptive interventions are scoped by learner-controlled covenants and leases; and all critical evidence is atomically committed. The framework makes no claim to measure intelligence, personality, mental health, or universal cognitive ability.
