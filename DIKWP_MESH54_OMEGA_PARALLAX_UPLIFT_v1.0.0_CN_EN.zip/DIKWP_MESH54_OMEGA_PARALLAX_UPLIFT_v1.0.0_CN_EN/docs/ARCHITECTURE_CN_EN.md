# UPLIFT 系统架构  
# System Architecture

## 1. 总体目标

UPLIFT 的系统目标不是最大化答题正确率，而是在学习者授权的范围内，持续产生更强的、可被推翻的理解证据。设计满足四个约束：

1. **Plural**：允许多个观察者、尺度、模态与目的；
2. **Falsifiable**：训练、迁移与保持主张有不同证据门；
3. **Reversible**：干预有 lease、expiry、quota、veto 与 rollback；
4. **Atomic**：回答、评分、画像、权限消耗和审计事件不可分割。

## 2. 逻辑分层

```text
┌──────────────────────────────────────────────────────────────┐
│ Learner Studio / CLI / Local Authenticated API               │
├──────────────────────────────────────────────────────────────┤
│ Session & Task Runtime                                       │
│ baseline │ training │ transfer │ delayed                     │
├──────────────────────────────────────────────────────────────┤
│ Understanding Evidence Engine                                │
│ scoring │ confidence calibration │ manual review overlay     │
├──────────────────────────────────────────────────────────────┤
│ 12-D Profile & Learner Closure Diagnostics                   │
│ DIKWP layer summary │ evidence frontier │ open obligations   │
├──────────────────────────────────────────────────────────────┤
│ Adaptive Intervention Compiler                               │
│ bottlenecks │ task selection │ interleaving │ scoped leases  │
├──────────────────────────────────────────────────────────────┤
│ PARALLAX Curriculum Closure Audit                            │
│ observers │ sources │ scales │ modalities │ residuals        │
├──────────────────────────────────────────────────────────────┤
│ Ω Atomic Evidence Store                                      │
│ WAL │ nonce │ lease use │ receipts │ profiles │ event chain  │
├──────────────────────────────────────────────────────────────┤
│ Transparency & Release Evidence                              │
│ Ed25519 │ Merkle checkpoint │ schemas │ conformance │ SBOM   │
└──────────────────────────────────────────────────────────────┘
```

## 3. 核心对象

### 3.1 KnowledgePack54

包含：

- concepts 与 prerequisites；
- relations；
- tasks；
- sources；
- protected relations；
- declared unknowns；
- observer chart、scale、modality 与 domain；
- phase、form、difficulty 与 intervention tags。

评分键独立保存为 `ScoringKey54`，不会通过 catalog API 返回。

### 3.2 UnderstandingCovenant54

它是学习者的 Intent Field Covenant：

```json
{
  "purpose": "voluntary study and self-audit",
  "allowed_interventions": ["causal_simulation", "analogy_transfer"],
  "prohibited_outcomes": ["covert persuasion", "general intelligence score"],
  "max_session_minutes": 40,
  "max_items_per_session": 12,
  "learner_veto": true,
  "persuasion_allowed": false,
  "expires_at": "..."
}
```

契约失效或撤销后，新会话、回答和计划全部 fail closed。

### 3.3 SessionDescriptor

每个 session 固定：

- learner、pack 与 covenant；
- phase 与 form；
- task IDs；
- start / expiry；
- metadata。

任务不能跨 session scope，也不能将 transfer task 塞入 training session。

### 3.4 UnderstandingEvidenceReceipt54

机器评分或待复核回答会生成签名回执，绑定：

- response、task、phase、form；
- score/status/confidence/calibration；
- pack hash；
- profile hash；
- nonce hash；
- lease use；
- event hash；
- state root；
- node key；
- claim boundary。

### 3.5 ManualUnderstandingReview54

开放解释题不重写原回执，而追加：

- reviewer ID / role；
- disclosed rubric evidence；
- bounded score；
- Ed25519 signature；
- new profile snapshot；
- append-only event。

### 3.6 UnderstandingProfile54

画像包含：

- 12 dimensions；
- D/I/K/W/P layer summary；
- mean / transfer / delayed score；
- Wilson interval；
- Brier 与 signed calibration gap；
- evidence states；
- verified frontier；
- open obligations。

它没有 total score、rank 或 IQ 字段。

### 3.7 LearnerClosureDiagnostics54

PARALLAX 被应用于任务表现，而不是人格：

- example lock；
- confidence lock；
- observer chart lock；
- scale lock；
- modality lock；
- unknown suppression；
- revision lock；
- purpose lock；
- verbal shell risk。

### 3.8 InterventionPlan54 与 Lease

计划器把瓶颈映射到候选干预，并在时间和题量预算内交错选择任务。每个干预获得：

- allowed task IDs；
- max uses；
- issued / expires；
- reason codes；
- reversible status。

## 4. 数据流

### 4.1 答题事务

```text
validate task/session/covenant
        ↓
validate lease (optional)
        ↓
score or mark PENDING_REVIEW
        ↓
insert response
        ↓
reserve durable nonce
        ↓
build profile from immutable receipts + reviews
        ↓
append event
        ↓
sign receipt and bind state root
        ↓
COMMIT
```

任何异常会回滚整个事务。三个故障注入点覆盖：response 后、nonce 后、commit 前。

### 4.2 计划事务

```text
active covenant
  + all prior receipts/reviews
  + current profile
  + learner closure diagnostics
        ↓
bottlenecks and evidence gaps
        ↓
phase gate: training / transfer / delayed
        ↓
interleaved task selection under budget
        ↓
leases
        ↓
plan + event COMMIT
```

新计划会将旧 active plan 和 leases 标记为 `SUPERSEDED`，防止并行计划越权。

### 4.3 透明度链

事件哈希：

```text
H_i = SHA256(canonical_json(
  seq_i,
  event_type_i,
  payload_hash_i,
  H_{i-1},
  created_at_i
))
```

checkpoint 对事件哈希列表计算 Merkle root，并签名：

```text
checkpoint = Sign(node_key,
  tree_size,
  merkle_root,
  head_hash,
  previous_checkpoint_hash,
  created_at
)
```

## 5. 存储模型

SQLite tables：

```text
packs
covenants
sessions
plans
leases
responses
nonces
receipts
reviews
profiles
events
checkpoints
meta
```

数据库设置：

```text
journal_mode = WAL
synchronous = FULL
foreign_keys = ON
busy_timeout = 30000
BEGIN IMMEDIATE for state transitions
```

取证复制使用 SQLite online backup API，保证 WAL 中的已提交状态进入一致性快照。

## 6. API 边界

公开无认证：

```text
GET /health
GET /studio
```

Bearer token 认证：

```text
GET  /v1/catalog
GET  /v1/status
GET  /v1/verify
GET  /v1/profile?learner_id=...
GET  /v1/plan?learner_id=...
POST /v1/sessions
POST /v1/responses
POST /v1/reviews
POST /v1/plans
POST /v1/checkpoints
```

安全默认：loopback、1 MiB body limit、JSON-only mutations、`no-store`、CSP、`nosniff`、frame deny、评分键不返回。

## 7. 可替换边界

以下组件刻意保持可替换：

- scoring functions；
- knowledge packs；
- intervention mappings；
- phase advancement threshold；
- review governance；
- database adapter；
- signer / key management；
- API authentication；
- research analysis pipeline。

替换组件必须保留：claim boundary、phase separation、learner veto、residual reserve、atomic receipt 和 verification semantics。

## 8. 单节点与分布式边界

当前实现提供单 SQLite 数据库内的线性化提交，不提供：

- 跨节点 consensus；
- Byzantine quorum；
- distributed nonce ownership；
- hardware-backed keys；
- trusted timestamp authority；
- multi-tenant row-level authorization。

生产部署若跨多个写节点，必须将 nonce、lease、receipt 和 event 的线性化点迁移到具备共识语义的存储层。
