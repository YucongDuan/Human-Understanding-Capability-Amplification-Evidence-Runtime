# 科学与主张边界 / Scientific and Claim Boundary

## 1. 当前能够主张什么

在确定性合成知识包和合成作答轨迹上，本实现证明：

- 可以用十二维结构表示任务级理解证据；
- 可以强制区分训练、隐藏迁移和延迟阶段；
- 可以把作答前信心纳入校准证据；
- 可以为开放题追加签名人工复核；
- 可以按学习者 covenant 编译范围受限干预；
- 可以原子提交回答、nonce、评分、画像、事件和回执；
- 可以检测重放冲突、事务中断、账本篡改和不一致备份；
- 可以对知识包进行 PARALLAX 闭环风险审计。

这属于：

```text
E2 — author-side deterministic reference implementation evidence
```

## 2. 当前不能主张什么

本版本没有证明：

- 真实人类平均理解能力提高；
- 某个干预相对于安慰剂或传统教学有因果优势；
- 十二维模型涵盖所有理解形式；
- 所有语言、文化、年龄、神经多样性或学科上公平；
- 合成迁移结果能预测现实迁移；
- 发行包随附的公开演示评分键或表单能构成真实隐藏评估；
- 一次延迟复测代表长期保持；
- 画像能测量 IQ、一般智力、人格、心理健康或人的价值；
- 软件适用于临床、招生、招聘、信贷、保险、执法或政治用途；
- 签名回执等同第三方认证或法律不可否认性；
- 哈希链等同不可篡改数据库；
- 作者侧测试等同独立复现。

## 3. “能力提升”的最小证据要求

对真实学习者声称提升，至少应同时满足：

1. 预注册目标维度、主要终点、时间窗、排除规则和分析计划；
2. 训练前基线；
3. 未见迁移表单；
4. 真实延迟复测；
5. 合理对照条件；
6. 盲评或评分自动化的独立验证；
7. 流失、缺失数据和不利事件报告；
8. 置信区间与效应量，而非只报告显著性；
9. 至少一个独立团队复现后再提升证据等级；
10. 学习者退出权、隐私和公平审计。

## 4. 失败如何处理

下列结果应导致主张降级或暂停：

- 训练提高但迁移不提高；
- 迁移提高但延迟保持消失；
- 提升只存在于泄漏表单；
- 高信心错误增加；
- 某群体负担或不利结果显著增加；
- 评审一致性不足；
- 退出者或缺失数据足以改变结论；
- 实施团队可通过修改阈值制造“成功”；
- 独立复现失败。

失败数据应作为可引用残差保留，而不是从 dashboard 删除。

## 5. 证据等级建议

| 等级 | 最低要求 |
|---|---|
| E0 | 未检验主张 |
| E1 | 有公开协议、来源和可审计知识包 |
| E2 | 作者侧可执行实现与确定性测试 |
| E3 | 作者侧真实参与者预注册试验 |
| E4 | 对抗性、泄漏和反事实挑战 |
| E5 | 独立团队复现 |
| E6 | 跨群体、语言、学科和机构验证 |
| E7 | 长期现实运行、漂移与不利事件审计 |

当前发行不得自我标记为 E3 以上。

---

# English summary

The release supports an E2 software claim: the reference runtime implements multidimensional evidence, strict phase separation, calibration, signed review, learner-scoped intervention leases, atomic persistence, and tamper detection on deterministic synthetic data. It does not demonstrate human learning gains, construct validity, fairness, general intelligence measurement, clinical utility, or independent replication. Any real-world improvement claim requires preregistration, hidden transfer forms, genuine delayed testing, controls, uncertainty reporting, adverse-event monitoring, learner rights, and independent replication.
