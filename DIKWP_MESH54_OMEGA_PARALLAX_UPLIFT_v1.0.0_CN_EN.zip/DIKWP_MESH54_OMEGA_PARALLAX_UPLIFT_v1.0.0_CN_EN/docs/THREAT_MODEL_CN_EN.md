# 威胁模型 / Threat Model

## 1. 保护对象

- 私有评分键与隐藏迁移表单；
- 学习者原始回答和信心；
- covenant、lease 与撤销状态；
- 回执、画像、人工复核和事件链；
- 训练/迁移/延迟的阶段隔离；
- 软件和发行物完整性。

## 2. 主要威胁

| 威胁 | 影响 | 现有控制 | 剩余风险 |
|---|---|---|---|
| 评分键泄漏 | 迁移结果失真 | 服务端私钥分离、catalog 过滤 | 主机被攻破仍会泄漏 |
| nonce 重放/双花 | 重复计分或证据分叉 | 持久 nonce、请求哈希、事务唯一性 | 多数据库节点需共识 |
| 部分提交 | 回执与状态不一致 | 单 SQLite 事务、故障注入测试 | 文件系统/硬件故障仍需备份 |
| WAL 复制遗漏 | 取证副本不一致 | SQLite online backup | 外部工具直接复制仍危险 |
| 账本篡改 | 伪造学习轨迹 | payload hash、链 hash、Merkle、签名 | 私钥泄漏后可签发未来事件 |
| 旧 covenant 继续执行 | 退出权失效 | 撤销状态、租约撤销 | 分布式缓存需同步 |
| 训练题冒充迁移 | 虚假能力结论 | phase/form 隔离、画像状态机 | 作者仍可能设计表面泄漏题 |
| 关键词评分开放题 | 虚假理解判定 | 强制人工复核 | 评审偏差与串通 |
| 信心反馈操控 | 过度自信或焦虑 | 只显示任务校准、无人格标签 | 不当界面仍可造成压力 |
| 课程单一视角封闭 | 价值捕获 | PARALLAX 闭环审计、未知轴 | 审计指标不是现实多元性的证明 |
| API token 被盗 | 未授权读取/提交 | 最小长度、loopback、no-store | 无 TLS/OIDC/速率限制 |
| 画像用于高风险筛选 | 歧视与越权 | 明示禁止用途、范围化回执 | 软件无法独立阻止外部滥用 |

## 3. 信任边界

### 本地单节点可信计算基

- Python 运行时；
- SQLite 与本地文件系统；
- Ed25519 私钥；
- 私有评分键；
- 操作系统账户和磁盘权限。

### 不可信或半可信输入

- 浏览器请求；
- 回答 JSON；
- 第三方知识包；
- 人工评审内容；
- 客户端 nonce；
- 系统时间；
- 上游附件中的历史结果。

## 4. 已明确不解决

当前版本不提供：

- Byzantine fault tolerance；
- 跨节点共识或全局 nonce 唯一性；
- 硬件安全模块；
- 远程证明；
- 防流量分析；
- 生产级多租户权限；
- 评审者身份真实性；
- 对组织滥用画像的技术性绝对阻止。

## 5. 安全失败策略

遇到以下情况应 fail closed：

- pack/key hash 不匹配；
- covenant 已撤销或过期；
- lease 超范围、超次数或过期；
- nonce 冲突；
- 事件链或签名验证失败；
- 训练/迁移/延迟表单不符合预注册；
- 数据库 integrity check 失败；
- 手工复核引用未知回答。

## 6. 人因与治理威胁

最大风险不一定是代码攻击，而是把范围受限的任务证据包装为人的总体价值。部署者必须保持：

- 禁止高风险自动决策；
- 学习者可见的解释、退出和申诉；
- 真实受影响方参与；
- 题目偏差、语言与可访问性审查；
- 对不利结果的暂停门；
- 独立复现与外部监督。

---

# English summary

UPLIFT protects private scoring keys, hidden forms, learner evidence, covenants, leases, receipts, and the phase separation required for valid transfer claims. The reference implementation addresses replay, partial commits, WAL-consistent backup, tamper evidence, and local API leakage. It does not provide distributed consensus, Byzantine tolerance, hardware-backed keys, production multi-tenancy, or a complete technical prevention of institutional misuse. Governance and learner rights remain part of the trusted system boundary.
