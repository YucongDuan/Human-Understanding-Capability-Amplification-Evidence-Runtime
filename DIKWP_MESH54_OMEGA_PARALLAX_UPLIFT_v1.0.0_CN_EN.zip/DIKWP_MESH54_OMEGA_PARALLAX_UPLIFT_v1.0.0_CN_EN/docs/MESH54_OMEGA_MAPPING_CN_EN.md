# DIKWP‑MESH 5.4 Ω 映射

## 1. DIKWP 资源映射

| 层 | UPLIFT 对象 | 典型证据 |
|---|---|---|
| D — Data | 原始题目、回答、信心、时间戳、来源 | response payload、raw trace |
| I — Information | 分类、边、方向、尺度、观察者标签 | edge set、classification、chart |
| K — Knowledge | 可重建模型、机制、规则与预测 | causal mechanism、prediction |
| W — Wisdom | 边界、反例、迁移、修订与风险权衡 | holdout transfer、rollback plan |
| P — Purpose | 学习目的、受影响者、禁止结果和否决条件 | Understanding Covenant |

理解不被视为从 D 到 P 的单向阶梯。任务可跨层形成局部图册，转换失败或无法投影部分进入 residual reserve。

## 2. MESH 5.4 对象

### Local causal atlas

每个 task 规定一个局部 chart：领域、观察者、尺度、模态和概念子图。系统不假设一个全局语义图能无损覆盖全部学习情境。

### Seams

训练表单 T 与留出表单 B 之间的迁移是 seam 检验。只有结构保持而不是词面重现，才能支持 transfer evidence。

### Holonomy

当一个解释经过多个观察者或尺度转换后回到起点，出现的差异被视为 perspective/scale residual，而不是自动归零。

### UAX residual

信息不足、口径不一致、边界外变量和未知机制被显式保存。系统允许“暂不能识别”成为正确回答。

### Intent Field Covenant

学习者声明目的、允许干预、禁止结果、时间预算、数据边界和否决权。该对象是所有 session 与 lease 的授权根。

### Constitutional closure

课程审计检查观察者垄断、来源集中、尺度锁定、模态锁定、迁移覆盖、反例覆盖、未知覆盖和目的覆盖。`HOLD` 课程不能激活契约。

## 3. Ω 原子提交

Ω 将以下对象绑定为一个宪约事实：

```text
answer
+ confidence forecast
+ score or pending-review state
+ durable nonce
+ lease consumption
+ profile snapshot
+ signed receipt
+ evidence event
```

没有部分成功。精确重试返回同一回执；不同请求复用 nonce 被拒绝。

## 4. 证据等级

UPLIFT 使用范围受限的等级：

| 等级 | 含义 |
|---|---|
| E0 | 未验证断言 |
| E1 | 有公开定义或来源 |
| E2 | 作者侧可运行、可重复的软件证据 |
| E3 | 同一团队重复研究或多样本内部验证 |
| E4 | 对抗、反事实、红队或强负对照 |
| E5 | 独立团队复现 |
| E6 | 跨机构、跨群体、跨学科验证 |
| E7 | 长期现实运行、漂移和公平性审计 |

当前发行是 E2。合成迁移和延迟轨迹只验证证据状态机，不把发行提升为 E5。

## 5. 宪约优先级

发生冲突时：

```text
learner veto
  > prohibited outcomes
  > covenant scope
  > intervention lease
  > adaptive plan
  > task convenience
  > optimization target
```

正确率优化不得绕过学习者的目的、边界或停止条件。
