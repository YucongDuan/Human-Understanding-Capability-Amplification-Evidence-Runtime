# 本地 API 参考 / Local API Reference

## 1. 定位

该 API 是单用户或受控研究环境的参考控制面。默认绑定 `127.0.0.1`，使用 bearer token，不提供 TLS、OIDC、多租户隔离或生产级速率限制。

除 `/health` 与 `/studio` 外，所有接口需要：

```http
Authorization: Bearer <token>
```

所有修改请求还需要：

```http
Content-Type: application/json
```

请求体上限为 1 MiB。响应设置 `Cache-Control: no-store`、`X-Content-Type-Options: nosniff` 和 frame deny。

## 2. 公共接口

### `GET /health`

返回服务状态与版本，不泄漏评分键或数据库细节。

### `GET /studio`

返回单文件学习工作台。token 只保存在当前页面内存，不写入 localStorage。

## 3. 认证读取接口

### `GET /v1/catalog?phase=<phase>&form=<form>`

返回公开题面与元数据。明确不返回答案、容差或人工量表私钥。

### `GET /v1/status`

返回持久表计数、事件头和当前 runtime 状态。

### `GET /v1/verify`

验证哈希链、签名、nonce、租约、画像引用和 checkpoint。

### `GET /v1/profile?learner_id=<id>`

返回该学习者最新十二维证据画像。

### `GET /v1/plan?learner_id=<id>`

返回已存在的最新计划（若实现版本提供）。生成计划使用 POST。

## 4. 修改接口

### `POST /v1/sessions`

```json
{
  "learner_id": "learner-001",
  "covenant_id": "covenant-001",
  "phase": "baseline",
  "form": "A",
  "task_ids": ["task-001"],
  "duration_minutes": 90
}
```

### `POST /v1/responses`

```json
{
  "session_id": "session-...",
  "task_id": "task-001",
  "answer": "example",
  "confidence": 0.65,
  "nonce": "globally-unique-client-nonce",
  "lease_id": null
}
```

同一 nonce 和完全相同请求返回原回执；同一 nonce 与不同请求返回冲突。

### `POST /v1/reviews`

```json
{
  "response_id": "response-...",
  "reviewer_id": "reviewer-001",
  "reviewer_role": "blind-rubric-reviewer",
  "score": 0.75,
  "rubric_evidence": {
    "mechanism": "identified mediating state",
    "boundary": "one boundary omitted"
  }
}
```

### `POST /v1/plans`

```json
{"covenant_id": "covenant-001"}
```

生成并原子提交下一轮计划及 scoped leases。

### `POST /v1/checkpoints`

生成签名 Merkle checkpoint。

## 5. 错误模型

错误使用 JSON 返回：

```json
{
  "status": "ERROR",
  "error_type": "ValueError",
  "message": "scope-limited diagnostic message"
}
```

调用方不得仅凭 HTTP 200 推断学习结论；必须读取回执的 `status`、`score`、`claim_boundary` 和签名。

## 6. 数据最小化

API 不要求姓名、邮箱、年龄或身份号码。`learner_id` 应使用研究内部假名。不要在回答正文中收集不必要的个人敏感信息。

---

# English summary

The API is a loopback-first reference control plane. Public endpoints are limited to health and the single-file studio. All evidence endpoints require bearer authentication; mutating requests require JSON and are capped at 1 MiB. The public catalog excludes scoring keys. Responses are atomically committed and returned as signed, scope-limited receipts. Production deployments require an external TLS/authentication layer, rate limiting, tenant isolation, backup policy, and privacy review.
