# UPLIFT 系统卡 / System Card

## 系统

**DIKWP-MESH 5.4 Ω PARALLAX UPLIFT 1.0.0** 通过知识包、理解契约、四阶段任务、十二维画像、适应性租约和原子证据仓，支持范围受限的人类理解训练与评估。

## 预期用户

- 自主学习者；
- 教师和课程设计者；
- 学习科学研究者；
- 需要可审计训练证据的受控实验团队。

## 预期用途

- 在一个明确知识域中诊断证据缺口；
- 选择最小可逆训练活动；
- 区分训练、迁移和延迟保持；
- 审计课程是否存在单一观察者、尺度、来源或成功定义；
- 生成可验证的回答与画像回执。

## 禁止用途

IQ、人格、心理健康、临床诊断、招生、招聘、信贷、保险、执法、政治定向、隐蔽说服、儿童无同意画像、自动高风险决策。

## 输入

- 版本化知识包；
- 私有评分键；
- 学习者 covenant；
- 回答、作答前信心和可选 lease；
- 人工复核证据。

## 输出

- 任务级签名回执；
- 十二维证据画像；
- 瓶颈和干预计划；
- scoped intervention leases；
- 哈希链事件和 Merkle checkpoint；
- dashboard 与机器可读报告。

## 关键限制

- 输出依赖知识包质量；
- 自动评分只适合结构化答案；
- 开放题评审可能有偏差；
- 合成演示不是人类有效性证据；
- 单节点 SQLite 不等同分布式共识；
- 本地 API 不等同生产安全服务；
- 任务证据不能泛化为人的总体能力。

## 当前验证

- 自建单元、集成、安全、崩溃、CLI、API 和制品测试；
- 自包含 conformance；
- JSON Schema；
- 合成四阶段生命周期；
- clean-wheel 与归档复验（以 `VALIDATION_REPORT.json` 为准）。

## 证据等级

`E2 — author-side deterministic reference implementation`。

## 责任分配

课程作者负责内容有效性与公平性；部署者负责同意、隐私、安全和禁止用途；评审者负责量表证据；研究团队负责预注册和统计；学习者保有拒绝与退出权。

---

# English summary

UPLIFT is a domain-scoped understanding-training and evidence runtime. It is intended for voluntary learning and controlled research, not for intelligence scoring or consequential decisions. Outputs are task-bound evidence receipts, multidimensional profiles, scoped plans, and tamper-evident provenance. The current release is an E2 deterministic reference implementation with no human-effectiveness or independent-replication claim.
