# 知识包编写指南 / Knowledge-Pack Authoring Guide

## 1. 先写主张边界

作者应在写题前明确：

- 要训练的可观察结构是什么；
- 不声称测量什么；
- 适用对象、背景知识和语言；
- 训练与评估的时间跨度；
- 成功门槛、失败门槛和停止条件；
- 受影响方和禁止用途。

## 2. 概念与因果图

每个概念应有稳定 ID、双语标题（如适用）、DIKWP 层、来源和先修关系。因果边必须区分：

- 促进/抑制；
- 必要/充分/调节；
- 时间滞后；
- 观察者和尺度；
- 已知/假设/争议状态。

不要把相关性边写成因果边。

## 3. 任务设计

每个任务必须声明：

- `dimension`；
- `dikwp_layer`；
- `phase` 与 `form`；
- `response_type`；
- 难度；
- 观察者、尺度、模态、领域；
- 是否允许“信息不足”；
- 评分键或人工量表；
- 结论边界。

### 推荐任务族

- Reconstruction：关系重建、排序、边集合；
- Mechanism：中间状态、因果链、机制对比；
- Prediction：新参数或新初始状态；
- Counterfactual：删边、加边、反转、干预；
- Transfer：新领域、不同词汇、同一深层结构；
- Boundary：反例分类、适用域判断；
- Perspective：观察者或尺度切换；
- Calibration：所有可判定题的作答前信心；
- Revision：先答、给新证据、再修订；
- Compression：最小充分解释；
- Residual：信息不足与缺失变量；
- Purpose：受益者、代价、代理指标和否决权。

## 4. 迁移表单隔离

迁移任务必须在训练前冻结并隐藏。至少隔离以下一项，最好多项：

- 表面词汇；
- 领域；
- 实例；
- 图形布局；
- 观察者；
- 尺度；
- 模态。

同时必须预先说明保持不变的深层结构。不能在看到失败后修改“什么算迁移”。

## 5. 延迟表单

延迟任务不应只是训练题的原样重复。应平衡记忆保持与结构再生，记录真实时间戳，并设置最短间隔。对于短期试验，可使用 24–72 小时；长期主张需要更长间隔。具体间隔属于研究设计，不能由软件默认值替代。

## 6. 评分键

私有评分键与公开知识包分离。**本发行包中的示例 key 为公开的合成复现材料，不可用于真实隐藏评估。** 自动评分只用于答案空间明确的类型：

- single choice；
- multi-select；
- numeric tolerance；
- ranking；
- edge set；
- explicit classification。

开放解释不得通过关键词计数直接判定理解。应采用量表、盲评和证据片段。

## 7. 质量门

发布前至少完成：

```bash
uplift54 audit-pack --pack knowledge_pack.json
uplift54 artifacts-validate --root .
uplift54 conformance --example-dir <your-example-dir>
```

并人工检查：

- 题目是否可被语言捷径解决；
- 训练与迁移是否泄漏；
- 是否存在文化或无障碍障碍；
- “信息不足”是否真的可用；
- 观点与目的是否多元；
- 受影响方是否被遗漏。

## 8. Versioning

修改任何会影响得分、任务含义或证据边界的内容时，应提升知识包版本并重新生成 hash。不得在相同版本下静默替换评分键。

---

# English checklist

1. Define scope, non-claims, population, prerequisites, outcomes, kill criteria, and prohibited uses before authoring tasks.
2. Represent causal assumptions explicitly and distinguish causal, correlational, and contested edges.
3. Tag each task by dimension, DIKWP layer, phase, form, observer, scale, modality, domain, and scoring method.
4. Freeze and hide transfer forms before training; preregister which deep structure is shared.
5. Keep private keys separate from public prompts.
6. Use human rubric review for open explanations; do not equate keyword overlap with understanding.
7. Run closure audit, schema validation, conformance tests, accessibility review, and leakage review before release.
