# 研究基础与设计映射 / Research Basis and Design Mapping

## 1. 说明

UPLIFT 借鉴学习科学中的若干可重复研究方向，但不声称这些文献自动验证本软件。每个设计原则仍需在本实现、目标知识域和目标人群中单独检验。

## 2. 设计映射

| 研究方向 | UPLIFT 中的实现 | 防止的误解 |
|---|---|---|
| Retrieval practice | 训练计划要求在反馈前主动重建与预测 | “重复阅读即理解” |
| Active/constructive learning | 机制解释、图重建、teach-back、反事实 | “看过内容即掌握” |
| Distributed practice | 独立 delayed 阶段与真实时间戳 | “同一会话重复即长期保持” |
| Calibration / judgments of learning | 作答前信心、Brier 误差、高信心错误 | “感觉流畅即会迁移” |
| Transfer | 隐藏表单、新领域与深层结构预注册 | “训练题熟练即普遍能力” |
| Self-explanation | 中间机制、边界和修订理由 | “正确答案等于正确模型” |
| Desirable difficulties | 有限提示、间隔、表面变化 | “越容易越有效” |
| Metacognitive regulation | 瓶颈诊断、学习者 covenant、计划再编译 | “系统可替代学习者目的” |

## 3. 核心参考文献

1. Karpicke, J. D., & Blunt, J. R. (2011). Retrieval practice produces more learning than elaborative studying with concept mapping. *Science, 331*(6018), 772–775. https://doi.org/10.1126/science.1199327
2. Roediger, H. L., & Karpicke, J. D. (2006). Test-enhanced learning. *Psychological Science, 17*(3), 249–255. https://doi.org/10.1111/j.1467-9280.2006.01693.x
3. Freeman, S., et al. (2014). Active learning increases student performance in science, engineering, and mathematics. *PNAS, 111*(23), 8410–8415. https://doi.org/10.1073/pnas.1319030111
4. Chi, M. T. H. (2009). Active-constructive-interactive. *Topics in Cognitive Science, 1*(1), 73–105. https://doi.org/10.1111/j.1756-8765.2008.01005.x
5. Cepeda, N. J., et al. (2006). Distributed practice in verbal recall tasks. *Psychological Bulletin, 132*(3), 354–380. https://doi.org/10.1037/0033-2909.132.3.354
6. Koriat, A. (1997). Monitoring one’s own knowledge during study. *Journal of Experimental Psychology: General, 126*(4), 349–370. https://doi.org/10.1037/0096-3445.126.4.349
7. Dunlosky, J., et al. (2013). Improving students’ learning with effective learning techniques. *Psychological Science in the Public Interest, 14*(1), 4–58. https://doi.org/10.1177/1529100612453266
8. Barnett, S. M., & Ceci, S. J. (2002). When and where do we apply what we learn? *Psychological Bulletin, 128*(4), 612–637. https://doi.org/10.1037/0033-2909.128.4.612
9. National Academies of Sciences, Engineering, and Medicine. (2018). *How People Learn II*. https://doi.org/10.17226/24783

## 4. 与 MESH5.4 Ω 的差异化贡献

学习科学通常关注干预效果；UPLIFT 额外关注证据工程和治理：

- 训练/迁移/延迟表单的机器可验证隔离；
- 学习者目的与禁止结果 covenant；
- 每项干预的 scoped lease；
- 原子提交和持久幂等；
- 人工量表签名与追加式修订；
- 残差和失败保留；
- 课程闭环的观察者/尺度/来源审计。

这些机制是否改善真实学习或研究可信度，仍需按 `EVALUATION_PROTOCOL_CN_EN.md` 验证。

---

# English boundary

The cited literature motivates retrieval, active construction, spacing, calibration, self-explanation, and transfer testing. It does not validate UPLIFT as a product or prove that its twelve-dimensional representation is complete. The runtime’s distinctive contribution is evidence separation, learner-governed intervention scope, atomic provenance, and explicit falsification boundaries; these require independent empirical evaluation.
